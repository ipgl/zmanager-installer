"""
Sistema de aplicação automática de cotas mensais para PaperCut Manager
Executa no primeiro dia de cada mês para aplicar as cotas configuradas
"""

import os
import sys
import logging
import schedule
import time
from datetime import datetime, timedelta
import threading
from threading import Thread
from papercut_api import PaperCutAPI
from models import Department, QuotaHistory, get_db_session, create_tables
from config import Config


# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('monthly_quota_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MonthlyQuotaScheduler:
    def __init__(self):
        self.api = PaperCutAPI(Config.PAPERCUT_SERVER_URL, Config.PAPERCUT_AUTH_TOKEN)
        self.thread = None
        self.running = False
        create_tables()  # Garantir que as tabelas existem

    def apply_monthly_quotas(self):
        """Aplica cotas mensais para todos os departamentos (CORRIGIDO)"""
        try:
            logger.info("=== INICIANDO APLICAÇÃO DE COTAS MENSAS ===")
            current_month = datetime.now().strftime('%Y-%m')
            
            # ✅ VERIFICAÇÃO DE BLOQUEIO PARA EVITAR DUPLICAÇÃO
            lock_file = f"monthly_quota_lock_{current_month}.lock"
            if os.path.exists(lock_file):
                logger.info(f" Aplicação de cotas para {current_month} já está em andamento. Abortando.")
                return {
                    'status': 'skipped',
                    'message': f'Aplicação para {current_month} já está em andamento'
                }
            
            # Criar arquivo de lock
            with open(lock_file, 'w') as f:
                f.write(str(datetime.now()))
            
            try:
                db = get_db_session()
                results = []
                
                try:
                    # Buscar departamentos ativos com cotas mensais configuradas
                    departments = db.query(Department).filter_by(is_active=True).all()
                    logger.info(f"Encontrados {len(departments)} departamentos para processar")
                    
                    for dept in departments:
                        # ✅ VERIFICAÇÃO MELHORADA: Usar mês/ano exato
                        if dept.last_quota_applied:
                            last_month = dept.last_quota_applied.strftime('%Y-%m')
                            if last_month == current_month:
                                logger.info(f" {dept.name}: Já aplicado este mês ({last_month})")
                                results.append({
                                    'department': dept.name,
                                    'status': 'skipped',
                                    'message': 'Já aplicado este mês'
                                })
                                continue
                        
                        # Aplicar cota se configurada
                        if dept.monthly_color_quota > 0 or dept.monthly_mono_quota > 0:
                            try:
                                logger.info(f" Processando {dept.name}: Color R$ {dept.monthly_color_quota}, Mono R$ {dept.monthly_mono_quota}")
                                
                                # ✅ CORREÇÃO: Buscar saldo atual primeiro
                                current_color = self.api.get_script_property(f"{dept.name}\\color")
                                current_mono = self.api.get_script_property(f"{dept.name}\\mono")
                                
                                logger.info(f" Saldos atuais {dept.name}: Color R$ {current_color}, Mono R$ {current_mono}")
                                
                                # ✅ CORREÇÃO: DEFINIR valor absoluto, não adicionar
                                # Zerar saldo existente e aplicar cota mensal
                                logger.info(f" Zerando saldos e aplicando cota mensal para {dept.name}: R$ {dept.monthly_color_quota} color, R$ {dept.monthly_mono_quota} mono")
                                
                                api_result = self.api.set_department_script_quotas(
                                    dept.name, 
                                    dept.monthly_color_quota,  # Valor absoluto
                                    dept.monthly_mono_quota    # Valor absoluto
                                )
                                
                                if api_result['success']:
                                    # ✅ VERIFICAR SALDO FINAL
                                    final_color = self.api.get_script_property(f"{dept.name}\\color")
                                    final_mono = self.api.get_script_property(f"{dept.name}\\mono")
                                    logger.info(f" Saldos finais {dept.name}: Color R$ {final_color}, Mono R$ {final_mono}")
                                    
                                    # ✅ ATUALIZAR CACHE no banco de dados
                                    dept.cached_color_balance = final_color
                                    dept.cached_mono_balance = final_mono
                                    dept.cache_updated_at = datetime.utcnow()
                                    dept.last_quota_applied = datetime.utcnow()
                                    
                                    # Registrar no histórico
                                    history = QuotaHistory(
                                        department_name=dept.name,
                                        color_quota_applied=dept.monthly_color_quota,
                                        mono_quota_applied=dept.monthly_mono_quota,
                                        applied_month=current_month,
                                        success=True
                                    )
                                    db.add(history)
                                    
                                    results.append({
                                        'department': dept.name,
                                        'status': 'success',
                                        'message': f'Cota aplicada: R$ {dept.monthly_color_quota} color, R$ {dept.monthly_mono_quota} mono',
                                        'data': {
                                            'color_applied': dept.monthly_color_quota,
                                            'mono_applied': dept.monthly_mono_quota,
                                            'previous_color': current_color,
                                            'previous_mono': current_mono,
                                            'final_color': final_color,
                                            'final_mono': final_mono
                                        }
                                    })
                                    
                                    logger.info(f" {dept.name}: Cota aplicada com sucesso")
                                    
                                else:
                                    # Registrar erro no histórico
                                    history = QuotaHistory(
                                        department_name=dept.name,
                                        color_quota_applied=dept.monthly_color_quota,
                                        mono_quota_applied=dept.monthly_mono_quota,
                                        applied_month=current_month,
                                        success=False,
                                        error_message=api_result.get('error', 'Erro desconhecido')
                                    )
                                    db.add(history)
                                    
                                    results.append({
                                        'department': dept.name,
                                        'status': 'error',
                                        'message': f'Erro: {api_result.get("error", "Falha na aplicação")}'
                                    })
                                    logger.error(f" {dept.name}: Erro na aplicação")
                            
                            except Exception as dept_error:
                                logger.error(f" Erro ao aplicar cota para {dept.name}: {dept_error}")
                                results.append({
                                    'department': dept.name,
                                    'status': 'error',
                                    'message': f'Erro: {str(dept_error)}'
                                })
                        else:
                            results.append({
                                'department': dept.name,
                                'status': 'skipped',
                                'message': 'Nenhuma cota mensal configurada'
                            })
                    
                    db.commit()
                    logger.info(" Aplicação de cotas mensais concluída")
                    
                    # ✅ ENVIAR NOTIFICAÇÃO PARA TODOS OS USUÁRIOS
                    self.send_quota_applied_notification(results, current_month)
                    
                    return {
                        'status': 'success',
                        'message': f'Cotas aplicadas para {len([r for r in results if r["status"] == "success"])} departamentos',
                        'data': {
                            'results': results,
                            'summary': {
                                'total': len(results),
                                'success': len([r for r in results if r['status'] == 'success']),
                                'errors': len([r for r in results if r['status'] == 'error']),
                                'skipped': len([r for r in results if r['status'] == 'skipped'])
                            },
                            'applied_month': current_month
                        }
                    }
                
                finally:
                    db.close()
                    
            finally:
                # ✅ REMOVER ARQUIVO DE LOCK
                try:
                    if os.path.exists(lock_file):
                        os.remove(lock_file)
                except:
                    pass
                    
        except Exception as e:
            logger.error(f" Erro geral na aplicação de cotas mensais: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }

    def send_quota_applied_notification(self, results, current_month):
        """Envia notificação para todos os usuários sobre a aplicação de cotas"""
        try:
            success_count = len([r for r in results if r['status'] == 'success'])
            total_count = len(results)
            
            notification_message = (
                f" **Atualização de Cotas Mensais - {current_month}**\n\n"
                f" **{success_count} de {total_count}** departamentos atualizados\n\n"
                f" **Resumo:**\n"
                f"  > Sucessos: {success_count}\n"
                f"  > Erros: {len([r for r in results if r['status'] == 'error'])}\n"
                f"  > Ignorados: {len([r for r in results if r['status'] == 'skipped'])}\n\n"
                f"Os saldos foram zerados e as cotas mensais aplicadas com sucesso."
            )
            
            logger.info(f" Notificação de cotas: {notification_message}")
            
            # ✅ ATUALIZAR CACHE PARA TODOS OS USUÁRIOS
            self.update_all_users_cache(results)
            
        except Exception as e:
            logger.error(f"Erro ao enviar notificação: {e}")

    def update_all_users_cache(self, results):
        """Atualiza o cache para todos os departamentos processados"""
        try:
            db = get_db_session()
            
            for result in results:
                if result['status'] == 'success':
                    dept_name = result['department']
                    dept_config = db.query(Department).filter_by(name=dept_name).first()
                    
                    if dept_config:
                        # Atualizar dados do cache
                        dept_config.cached_color_balance = result['data'].get('final_color', result['data']['color_applied'])
                        dept_config.cached_mono_balance = result['data'].get('final_mono', result['data']['mono_applied'])
                        dept_config.cache_updated_at = datetime.utcnow()
                        dept_config.last_quota_applied = datetime.utcnow()
            
            db.commit()
            logger.info(" Cache atualizado para todos os departamentos processados")
            
        except Exception as e:
            logger.error(f"Erro ao atualizar cache: {e}")
            db.rollback()
        finally:
            db.close()

    def schedule_monthly_quotas(self):
        """Agenda a aplicação de cotas para o primeiro dia do mês às 00:05"""
        # Executar todo dia 1 às 00:05
        schedule.every().day.at("00:05").do(self.check_and_apply_monthly_quotas)
        logger.info(" Agendamento configurado: verificação diária às 00:05 para primeiro dia do mês")

    def check_and_apply_monthly_quotas(self):
        """Verifica se é o primeiro dia do mês e aplica as cotas (CORRIGIDO)"""
        today = datetime.now()
        
        # ✅ VERIFICAÇÃO MAIS PRECISA: Primeiro dia do mês entre 00:00 e 00:30
        if today.day == 1 and today.hour == 0 and today.minute <= 30:
            current_month = today.strftime('%Y-%m')
            lock_file = f"monthly_quota_lock_{current_month}.lock"
            
            # ✅ EVITAR EXECUÇÃO MÚLTIPLA
            if not os.path.exists(lock_file):
                logger.info(f" Primeiro dia do mês detectado ({current_month}), aplicando cotas...")
                result = self.apply_monthly_quotas()
                logger.info(f" Resultado da aplicação: {result['message']}")
            else:
                logger.info(f" Aplicação para {current_month} já está em andamento")
        else:
            logger.info(f" Fora do período de renovação ({today.day}/{today.month} {today.hour:02d}:{today.minute:02d})")

    def start(self):
        """Inicia o scheduler em background"""
        if self.running:
            logger.warning("Scheduler já está rodando")
            return self.thread

        self.running = True
        self.schedule_monthly_quotas()
        
        def run_scheduler():
            logger.info(" Scheduler de cotas mensais iniciado")
            while self.running:
                try:
                    schedule.run_pending()
                except Exception as e:
                    logger.error(f"Erro no scheduler: {e}")
                time.sleep(60)  # Verificar a cada minuto
        
        self.thread = threading.Thread(target=run_scheduler, daemon=True)
        self.thread.start()
        logger.info(" Scheduler iniciado em background")
        return self.thread

    def stop(self):
        """Para o scheduler"""
        self.running = False
        logger.info(" Scheduler parado")

    def is_running(self):
        """Verifica se o scheduler está rodando"""
        return self.running and self.thread and self.thread.is_alive()

def main():
    """Executa o agendador como processo independente"""
    logger.info("=== PaperCut Manager - Monthly Quota Scheduler ===")
    
    scheduler = MonthlyQuotaScheduler()
    
    try:
        # Verificar conexão com PaperCut
        connection_test = scheduler.api.test_connection(force=True)
        if connection_test['status'] != 'success':
            logger.warning(f"Problema na conexão com PaperCut: {connection_test['message']}")
            logger.info("Agendador continuará executando e tentará aplicar cotas quando a conexão for restabelecida")
        
        # Iniciar agendador
        scheduler.start()
        
        # Manter o processo rodando
        while scheduler.is_running():
            time.sleep(60)
            
    except KeyboardInterrupt:
        logger.info("Parando agendador...")
        scheduler.stop()
    except Exception as e:
        logger.error(f"Erro fatal no agendador: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()