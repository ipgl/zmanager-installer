#!/usr/bin/env python3
"""
Sistema de aplicação automática de cotas mensais para PaperCut Manager
Executa no primeiro dia de cada mês para aplicar as cotas configuradas
"""

import os
import sys
import logging
import schedule
import time
from datetime import datetime, timedelta
from threading import Thread
from papercut_api import PaperCutAPI
from models import Department, QuotaHistory, get_db_session
from config import Config

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('monthly_quota_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MonthlyQuotaScheduler:
    def __init__(self):
        self.api = PaperCutAPI(Config.PAPERCUT_SERVER_URL, Config.PAPERCUT_AUTH_TOKEN)
        self.running = True
        self.thread = None
        
    def apply_monthly_quotas(self):
        """Aplica cotas mensais para todos os departamentos configurados"""
        logger.info("Iniciando aplicação de cotas mensais automática")
        current_month = datetime.now().strftime('%Y-%m')
        current_date = datetime.now()
        
        db = get_db_session()
        results = []
        
        try:
            departments = db.query(Department).filter_by(is_active=True).all()
            logger.info(f"Encontrados {len(departments)} departamentos ativos")
            
            for dept in departments:
                # Verificar se já foi aplicado este mês - apenas se last_quota_applied não for None
                if dept.last_quota_applied:
                    last_month = dept.last_quota_applied.strftime('%Y-%m')
                    if last_month == current_month:
                        logger.info(f"Cota para {dept.name} já aplicada este mês ({current_month})")
                        results.append({
                            'department': dept.name,
                            'status': 'skipped',
                            'message': 'Já aplicado este mês'
                        })
                        continue
                
                # Aplicar cota se configurada
                if dept.monthly_color_quota > 0 or dept.monthly_mono_quota > 0:
                    try:
                        # Obter saldos atuais das chaves script.user-defined
                        current_data = self.api.get_department_script_balances(dept.name)
                        
                        current_color = float(current_data.get('color_balance', 0))
                        current_mono = float(current_data.get('mono_balance', 0))
                        
                        logger.info(f"Saldos atuais {dept.name}: Color R$ {current_color:.2f}, Mono R$ {current_mono:.2f}")
                        logger.info(f"Aplicando cota mensal para {dept.name}: +R$ {dept.monthly_color_quota:.2f} color, +R$ {dept.monthly_mono_quota:.2f} mono")
                        
                        # Aplicar ajustes às chaves script.user-defined
                        results_applied = []
                        all_success = True
                        
                        # Aplicar cota color se configurada
                        if dept.monthly_color_quota > 0:
                            color_key = f"{dept.name}\\color"
                            color_result = self.api.adjust_script_property_balance(
                                color_key,
                                dept.monthly_color_quota,
                                f"Cota mensal automática {current_month}: +R$ {dept.monthly_color_quota:.2f}"
                            )
                            results_applied.append({
                                'type': 'color',
                                'old_balance': current_color,
                                'quota_added': dept.monthly_color_quota,
                                'new_balance': color_result.get('new_value', 0),
                                'success': color_result['success']
                            })
                            if not color_result['success']:
                                all_success = False
                        
                        # Aplicar cota mono se configurada
                        if dept.monthly_mono_quota > 0:
                            mono_key = f"{dept.name}\\mono"
                            mono_result = self.api.adjust_script_property_balance(
                                mono_key,
                                dept.monthly_mono_quota,
                                f"Cota mensal automática {current_month}: +R$ {dept.monthly_mono_quota:.2f}"
                            )
                            results_applied.append({
                                'type': 'mono',
                                'old_balance': current_mono,
                                'quota_added': dept.monthly_mono_quota,
                                'new_balance': mono_result.get('new_value', 0),
                                'success': mono_result['success']
                            })
                            if not mono_result['success']:
                                all_success = False
                        
                        # Simular estrutura de resultado da API para compatibilidade
                        api_result = {
                            'success': all_success,
                            'department': dept.name,
                            'script_results': results_applied
                        }
                        
                        if api_result['success']:
                            # Atualizar data de aplicação
                            dept.last_quota_applied = datetime.utcnow()
                            
                            # Registrar no histórico
                            history = QuotaHistory(
                                department_name=dept.name,
                                color_quota_applied=dept.monthly_color_quota,
                                mono_quota_applied=dept.monthly_mono_quota,
                                applied_month=current_month,
                                success=True
                            )
                            db.add(history)
                            
                            # Criar mensagem detalhada dos resultados
                            success_details = []
                            for result in results_applied:
                                if result['success']:
                                    success_details.append(f"{result['type']}: R$ {result['quota_added']:.2f} (novo saldo: R$ {result['new_balance']:.2f})")
                            
                            results.append({
                                'department': dept.name,
                                'status': 'success',
                                'message': f'Adicionado às chaves script: {", ".join(success_details)}',
                                'source': 'script.user-defined'
                            })
                            
                            logger.info(f"Cota script aplicada com sucesso para {dept.name}: {', '.join(success_details)}")
                        else:
                            error_msg = api_result.get('error', 'Erro desconhecido')
                            logger.error(f"Erro ao aplicar cota para {dept.name}: {error_msg}")
                            
                            # Registrar erro no histórico
                            history = QuotaHistory(
                                department_name=dept.name,
                                color_quota_applied=dept.monthly_color_quota,
                                mono_quota_applied=dept.monthly_mono_quota,
                                applied_month=current_month,
                                success=False,
                                error_message=error_msg
                            )
                            db.add(history)
                            
                            results.append({
                                'department': dept.name,
                                'status': 'error',
                                'message': f'Erro: {error_msg}'
                            })
                    
                    except Exception as dept_error:
                        logger.error(f"Erro ao processar departamento {dept.name}: {dept_error}")
                        results.append({
                            'department': dept.name,
                            'status': 'error',
                            'message': f'Erro: {str(dept_error)}'
                        })
                else:
                    logger.info(f"Departamento {dept.name} não possui cota mensal configurada")
                    results.append({
                        'department': dept.name,
                        'status': 'skipped',
                        'message': 'Nenhuma cota mensal configurada'
                    })
            
            db.commit()
            
            success_count = len([r for r in results if r['status'] == 'success'])
            error_count = len([r for r in results if r['status'] == 'error'])
            
            logger.info(f"Aplicação de cotas concluída: {success_count} sucessos, {error_count} erros")
            
            return {
                'status': 'success',
                'total': len(results),
                'success': success_count,
                'errors': error_count,
                'results': results
            }
        
        except Exception as e:
            logger.error(f"Erro geral na aplicação de cotas: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            db.close()
    
    def check_first_day_of_month(self):
        """Verifica se é o primeiro dia do mês e executa as cotas se for"""
        today = datetime.now()
        if today.day == 1:
            logger.info("Primeiro dia do mês detectado - aplicando cotas mensais")
            self.apply_monthly_quotas()
        else:
            logger.debug(f"Dia {today.day} - não é o primeiro dia do mês")
    
    def run_scheduler(self):
        """Executa o agendador de tarefas"""
        logger.info("Iniciando agendador de cotas mensais")
        
        # Verificar diariamente às 08:00 se é o primeiro dia do mês
        schedule.every().day.at("00:05").do(self.check_first_day_of_month)
        
        # Para testes, também agendar a cada hora (comentar em produção)
        # schedule.every().hour.do(self.check_first_day_of_month)
        
        logger.info("Agendamento configurado: verificação diária às 00:05 para primeiro dia do mês")
        
        while self.running:
            schedule.run_pending()
            time.sleep(60)  # Verificar a cada minuto
        
        logger.info("Agendador parado")
    
    def start(self):
        """Inicia o agendador em thread separada"""
        if self.thread and self.thread.is_alive():
            logger.warning("Scheduler já está em execução")
            return self.thread
        
        self.running = True
        self.thread = Thread(target=self.run_scheduler, daemon=True)
        self.thread.start()
        logger.info("Agendador iniciado em background")
        return self.thread
    
    def stop(self):
        """Para o agendador"""
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5.0)
            logger.info("Agendador parado")
    
    def is_running(self):
        """Verifica se o scheduler está em execução"""
        return self.thread and self.thread.is_alive() and self.running
    
    def get_status(self):
        """Retorna status do scheduler"""
        return {
            'running': self.is_running(),
            'thread_alive': self.thread.is_alive() if self.thread else False,
            'last_check': getattr(self, 'last_check_time', None)
        }

def main():
    """Executa o agendador como processo independente"""
    logger.info("=== PaperCut Manager - Monthly Quota Scheduler ===")
    
    scheduler = MonthlyQuotaScheduler()
    
    try:
        # Verificar conexão com PaperCut
        connection_test = scheduler.api.test_connection(force=True)
        if connection_test['status'] != 'success':
            logger.warning(f"Problema na conexão com PaperCut: {connection_test['message']}")
            logger.info("Agendador continuará executando e tentará aplicar cotas quando a conexão for restabelecida")
        
        # Iniciar agendador
        scheduler.run_scheduler()
        
    except KeyboardInterrupt:
        logger.info("Parando agendador...")
        scheduler.stop()
    except Exception as e:
        logger.error(f"Erro fatal no agendador: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()