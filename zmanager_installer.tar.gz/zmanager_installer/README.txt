# Z Manager - Sistema de Instalação

## Instalação Rápida (arquivo local):
```bash
sudo bash install_quick.sh
```

## Instalação Remota (via URL):
```bash
sudo bash remote_install.sh
```

## Instalação Manual:
1. Extrair: tar -xzf zmanager_installer.tar.gz
2. Entrar: cd zmanager_installer
3. Instalar: sudo bash install.sh

## Comandos Úteis:
- systemctl status zmanager
- journalctl -u zmanager -f
- /opt/zmanager/zmanager-control restart
- /opt/zmanager/uninstall.sh

## Acesso:
- http://localhost:5666

## Para distribuição:
1. Hospede o arquivo zmanager_installer.tar.gz em um servidor web
2. Atualize a URL no remote_install.sh
3. Distribua o remote_install.sh para clientes