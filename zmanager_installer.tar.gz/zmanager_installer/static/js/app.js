// PaperCut Manager - Main JavaScript Application

class PaperCutManager {
    constructor() {
        this.departments = [];
        this.connectionStatus = 'checking';
        this.currentEditingDepartment = null;
        
        // Initialize on DOM ready
        document.addEventListener('DOMContentLoaded', () => {
            this.init();
        });
    }

    async init() {
        console.log('Initializing PaperCut Manager...');
        
        // Check connection first
        await this.checkConnection();
        
        // Load departments
        await this.loadDepartments();
        
        // Não usar atualizações automáticas - apenas manual
        
        console.log('PaperCut Manager initialized');
    }

    async checkConnection(force = false) {
        try {
            const url = `/api/connection${force ? '?force=true' : ''}`;
            const response = await fetch(url);
            const data = await response.json();
            
            this.updateConnectionStatus(data.status, data.message);
            return data.status === 'success';
        } catch (error) {
            console.error('Connection check failed:', error);
            this.updateConnectionStatus('error', 'Erro na verificação de conectividade');
            return false;
        }
    }

    updateConnectionStatus(status, message) {
        const statusElement = document.getElementById('connection-status');
        const alertElement = document.getElementById('connection-alert');
        const messageElement = document.getElementById('connection-message');
        
        if (!statusElement) return;
        
        // Update navbar status
        statusElement.className = 'badge';
        switch (status) {
            case 'success':
                statusElement.classList.add('bg-success');
                statusElement.innerHTML = '<i class="bi bi-wifi me-1"></i>Conectado';
                alertElement.classList.add('d-none');
                break;
            case 'error':
                statusElement.classList.add('bg-danger');
                statusElement.innerHTML = '<i class="bi bi-wifi-off me-1"></i>Desconectado';
                alertElement.classList.remove('d-none');
                alertElement.className = 'alert alert-danger';
                messageElement.textContent = message;
                break;
            default:
                statusElement.classList.add('bg-warning');
                statusElement.innerHTML = '<i class="bi bi-wifi-2 me-1"></i>Verificando...';
                break;
        }
        
        this.connectionStatus = status;
    }

    async loadDepartments() {
        if (this.connectionStatus !== 'success') {
            console.log('Skipping department load - not connected');
            return;
        }

        try {
            this.showLoading(true);
            
            // Usar endpoint híbrido: nomes tradicionais com valores das chaves script
            const response = await fetch('/api/accounts-hybrid');
            const data = await response.json();
            
            if (data.status === 'success') {
                this.departments = data.data.departments || [];
                this.renderDepartments();
                this.updateStatistics();
                this.showToast('success', 'Dados atualizados com sucesso');
            } else {
                throw new Error(data.message || 'Erro ao carregar departamentos');
            }
        } catch (error) {
            console.error('Failed to load departments:', error);
            this.showToast('error', 'Erro ao carregar departamentos: ' + error.message);
            this.showEmptyState();
        } finally {
            this.showLoading(false);
        }
    }

    renderDepartments() {
        const tbody = document.getElementById('departments-tbody');
        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (!tbody) return;
        
        if (this.departments.length === 0) {
            this.showEmptyState();
            return;
        }
        
        // Show table, hide empty state
        tableContainer.classList.remove('d-none');
        emptyState.classList.add('d-none');
        
        tbody.innerHTML = this.departments.map(dept => `
            <tr>
                <td>
                    <strong>${this.escapeHtml(dept.name)}</strong>
                    <br>
                    <small class="text-muted">
                        <i class="bi bi-palette me-1"></i>${this.escapeHtml(dept.color_account)}
                        <br>
                        <i class="bi bi-circle me-1"></i>${this.escapeHtml(dept.mono_account)}
                    </small>
                </td>
                <td class="text-center">
                    <span class="badge badge-quota ${dept.color_balance > 0 ? 'bg-success' : 'bg-danger'}">
                        ${this.formatNumber(dept.color_balance)}
                    </span>
                </td>
                <td class="text-center">
                    <span class="badge badge-quota ${dept.mono_balance > 0 ? 'bg-info' : 'bg-danger'}">
                        ${this.formatNumber(dept.mono_balance)}
                    </span>
                </td>
                <td class="text-center">
                    <span class="badge badge-quota ${dept.total_balance > 0 ? 'bg-primary' : 'bg-secondary'}">
                        ${this.formatNumber(dept.total_balance)}
                    </span>
                </td>
                <td class="text-center">
                    <button class="btn btn-sm btn-outline-primary me-1" 
                            onclick="app.editDepartmentQuotas('${this.escapeHtml(dept.name)}')"
                            title="Editar cotas">
                        <i class="bi bi-pencil"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    showEmptyState() {
        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (tableContainer && emptyState) {
            tableContainer.classList.add('d-none');
            emptyState.classList.remove('d-none');
        }
    }

    updateStatistics() {
        const totalDepartments = this.departments.length;
        const totalColor = this.departments.reduce((sum, dept) => sum + (dept.color_balance || 0), 0);
        const totalMono = this.departments.reduce((sum, dept) => sum + (dept.mono_balance || 0), 0);
        const totalPages = totalColor + totalMono;
        
        document.getElementById('total-departments').textContent = totalDepartments;
        document.getElementById('total-color').textContent = this.formatNumber(totalColor);
        document.getElementById('total-mono').textContent = this.formatNumber(totalMono);
        document.getElementById('total-pages').textContent = this.formatNumber(totalPages);
    }


    showLoading(show) {
        const spinner = document.getElementById('loading-spinner');
        const tableContainer = document.getElementById('departments-table-container');
        
        if (show) {
            spinner?.classList.remove('d-none');
            tableContainer?.classList.add('d-none');
        } else {
            spinner?.classList.add('d-none');
        }
    }

    editDepartmentQuotas(departmentName) {
        const department = this.departments.find(d => d.name === departmentName);
        if (!department) {
            this.showToast('error', 'Departamento não encontrado');
            return;
        }
        
        this.currentEditingDepartment = departmentName;
        
        // Populate modal
        document.getElementById('edit-department-name').textContent = departmentName;
        document.getElementById('edit-color-quota').value = Math.max(0, department.color_balance);
        document.getElementById('edit-mono-quota').value = Math.max(0, department.mono_balance);
        document.getElementById('current-color-balance').textContent = this.formatNumber(department.color_balance);
        document.getElementById('current-mono-balance').textContent = this.formatNumber(department.mono_balance);
        
        // Populate monthly quota fields
        document.getElementById('monthly-color-quota').value = department.monthly_color_quota || 0;
        document.getElementById('monthly-mono-quota').value = department.monthly_mono_quota || 0;
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('editQuotasModal'));
        modal.show();
    }

    async saveQuotas() {
        if (!this.currentEditingDepartment) return;
        
        const colorQuota = parseFloat(document.getElementById('edit-color-quota').value) || 0;
        const monoQuota = parseFloat(document.getElementById('edit-mono-quota').value) || 0;
        const monthlyColorQuota = parseFloat(document.getElementById('monthly-color-quota').value) || 0;
        const monthlyMonoQuota = parseFloat(document.getElementById('monthly-mono-quota').value) || 0;
        
        if (colorQuota < 0 || monoQuota < 0 || monthlyColorQuota < 0 || monthlyMonoQuota < 0) {
            this.showToast('error', 'As cotas não podem ser negativas');
            return;
        }
        
        try {
            // ATUALIZADO: usar endpoint correto para salvar cotas
            const response = await fetch(`/api/departments/${encodeURIComponent(this.currentEditingDepartment)}/quotas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    color: colorQuota,
                    mono: monoQuota,
                    monthly_color: monthlyColorQuota,
                    monthly_mono: monthlyMonoQuota
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showToast('success', data.message);
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('editQuotasModal'));
                modal?.hide();
                
                // Refresh data
                await this.loadDepartments();
            } else {
                throw new Error(data.message || 'Erro ao atualizar cotas');
            }
        } catch (error) {
            console.error('Failed to save quotas:', error);
            this.showToast('error', 'Erro ao salvar cotas: ' + error.message);
        }
    }


    async loadConnectionConfig() {
        try {
            const response = await fetch('/api/connection/config');
            const data = await response.json();
            
            if (data.status === 'success') {
                document.getElementById('current-server-url').textContent = data.data.server_url;
                
                // Parse URL to populate form
                const url = new URL(data.data.server_url);
                document.getElementById('server-host').value = url.hostname || 'localhost';
                document.getElementById('server-port').value = url.port || '9191';
                document.getElementById('use-ssl').checked = url.protocol === 'https:';
            }
        } catch (error) {
            console.error('Failed to load connection config:', error);
            this.showToast('error', 'Erro ao carregar configuração');
        }
    }

    async saveConnection() {
        const host = document.getElementById('server-host').value.trim();
        const port = parseInt(document.getElementById('server-port').value) || 9191;
        const ssl = document.getElementById('use-ssl').checked;
        const authToken = document.getElementById('auth-token').value.trim();
        
        if (!host) {
            this.showToast('error', 'Host é obrigatório');
            return;
        }
        
        try {
            const response = await fetch('/api/connection/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    host: host,
                    port: port,
                    ssl: ssl,
                    auth_token: authToken
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showToast('success', data.message);
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('connectionModal'));
                modal?.hide();
                
                // Refresh connection status and data
                await this.checkConnection(true);
                await this.loadDepartments();
            } else {
                throw new Error(data.message || 'Erro ao salvar configuração');
            }
        } catch (error) {
            console.error('Failed to save connection:', error);
            this.showToast('error', 'Erro ao salvar configuração: ' + error.message);
        }
    }

    async testConnectionOnly() {
        const host = document.getElementById('server-host').value.trim();
        const port = parseInt(document.getElementById('server-port').value) || 9191;
        const ssl = document.getElementById('use-ssl').checked;
        
        if (!host) {
            this.showToast('error', 'Host é obrigatório');
            return;
        }
        
        // Just test, don't save
        const protocol = ssl ? 'https' : 'http';
        const testUrl = `${protocol}://${host}:${port}/rpc/api/xmlrpc`;
        
        this.showToast('info', `Testando conexão com ${testUrl}...`);
        
        try {
            const isConnected = await this.checkConnection(true);
            if (isConnected) {
                this.showToast('success', 'Conexão bem-sucedida!');
            } else {
                this.showToast('error', 'Falha na conexão');
            }
        } catch (error) {
            this.showToast('error', 'Erro no teste: ' + error.message);
        }
    }

    showToast(type, message) {
        const toast = document.getElementById('status-toast');
        const toastBody = toast.querySelector('.toast-body');
        const toastHeader = toast.querySelector('.toast-header');
        
        // Update content
        toastBody.textContent = message;
        
        // Update style based on type
        toast.className = `toast ${type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info'} text-white`;
        
        // Show toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }

    formatNumber(num) {
        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(num || 0);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async applyMonthlyQuotas(force = false) {
        const confirmMessage = force ? 
            'Tem certeza que deseja aplicar as cotas mensais mesmo se já foram aplicadas este mês?' :
            'Tem certeza que deseja aplicar as cotas mensais para todos os departamentos?';
        
        if (!confirm(confirmMessage)) return;
        
        try {
            this.showToast('info', 'Aplicando cotas mensais via script.user-defined...');
            
            // Sempre usar endpoint de chaves script
            const response = await fetch('/api/script-quotas/apply-monthly', { method: 'POST' });
            const data = await response.json();
            
            if (data.status === 'success') {
                const summary = data.data.summary || data.data;
                const message = summary.success !== undefined ? 
                    `Cotas aplicadas: ${summary.success} sucessos, ${summary.errors} erros, ${summary.skipped || 0} ignorados` :
                    data.message;
                this.showToast('success', message);
                
                // Show detailed results if available
                if (data.data.results) {
                    this.showQuotaResults(data.data.results);
                }
                
                // Refresh data
                await this.loadDepartments();
            } else {
                throw new Error(data.message || 'Erro ao aplicar cotas mensais');
            }
        } catch (error) {
            console.error('Failed to apply monthly quotas:', error);
            this.showToast('error', 'Erro ao aplicar cotas: ' + error.message);
        }
    }

    showQuotaResults(results) {
        // Create a simple modal to show results
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="bi bi-calendar-check me-2"></i>
                            Resultado da Aplicação de Cotas
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="list-group">
                            ${results.map(result => `
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">${this.escapeHtml(result.department)}</h6>
                                            <p class="mb-1">${this.escapeHtml(result.message)}</p>
                                        </div>
                                        <span class="badge ${
                                            result.status === 'success' ? 'bg-success' :
                                            result.status === 'error' ? 'bg-danger' : 'bg-secondary'
                                        }">
                                            ${result.status === 'success' ? 'Sucesso' :
                                              result.status === 'error' ? 'Erro' : 'Ignorado'}
                                        </span>
                                    </div>
                                    ${result.data ? `
                                        <small class="text-muted">
                                            Color: ${this.formatNumber(result.data.previous_color)} → ${this.formatNumber(result.data.new_color)} |
                                            Mono: ${this.formatNumber(result.data.previous_mono)} → ${this.formatNumber(result.data.new_mono)}
                                        </small>
                                    ` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        // Remove modal from DOM after hide
        modal.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modal);
        });
    }
}

// Global functions for onclick handlers
async function refreshData() {
    await app.checkConnection(true);
    await app.loadDepartments();
}


async function saveQuotas() {
    await app.saveQuotas();
}

async function saveConnection() {
    await app.saveConnection();
}

async function testConnection() {
    await app.testConnectionOnly();
}

async function applyMonthlyQuotas(force = false) {
    await app.applyMonthlyQuotas(force);
}

// Load connection config when modal is shown
document.addEventListener('DOMContentLoaded', () => {
    const connectionModal = document.getElementById('connectionModal');
    if (connectionModal) {
        connectionModal.addEventListener('show.bs.modal', () => {
            app.loadConnectionConfig();
        });
    }
});

// Initialize application
const app = new PaperCutManager();
