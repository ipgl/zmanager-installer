// PaperCut Manager - Versão com Sistema Avançado de Bloqueio de Requisições

class PaperCutManager {
    constructor() {
        this.departments = [];
        this.connectionStatus = 'checking';
        this.currentEditingDepartment = null;
        this.loadedDepartments = 0;
        this.totalDepartments = 0;
        this.isLoading = false;
        this.isUpdatingFromPaperCut = false;
        
        // ✅ SISTEMA AVANÇADO DE BLOQUEIO DE REQUISIÇÕES
        this.pendingRequests = new Map(); // Map para rastrear operações específicas
        this.globalRequestLock = false; // Lock global
        this.operationTimeouts = new Map(); // Timeouts para operações travadas
        
        // ✅ NOVO: Sistema de fila de operações
        this.operationQueue = [];
        this.processingQueue = false;
        
        // ✅ NOVO: Tipos de operações que devem ser bloqueadas mutuamente
        this.blockingOperationTypes = [
            'load-departments',
            'load-from-papercut', 
            'refresh-all-papercut',
            'apply-monthly-quotas',
            'clear-cache'
        ];
        
        // ✅ NOVO: Operações que podem ser executadas em paralelo (mas limitadas)
        this.limitedParallelOperations = [
            'reload-department',
            'test-connection',
            'save-quotas'
        ];
        
        // Limite máximo de operações paralelas
        this.maxParallelOperations = 3;

        // ✅ CORREÇÃO: Verificar se estamos na página correta antes de inicializar
        if (this.shouldInitialize()) {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => {
                    console.log('🚀 DOM Carregado - Iniciando App no accounts.html');
                    this.init();
                });
            } else {
                console.log('🚀 DOM Já Carregado - Iniciando App no accounts.html');
                setTimeout(() => this.init(), 100);
            }
        } else {
            console.log('📄 Página diferente de accounts.html - App não inicializado');
        }
    }

    // ✅ SISTEMA AVANÇADO DE BLOQUEIO DE REQUISIÇÕES
    async withRequestLock(operationName, operation, options = {}) {
        const {
            timeout = 30000, // 30 segundos timeout padrão
            showUserMessage = true,
            allowParallel = false,
            maxParallel = this.maxParallelOperations
        } = options;

        // Verificar se a operação já está em andamento
        if (this.pendingRequests.has(operationName)) {
            const existingOperation = this.pendingRequests.get(operationName);
            const message = `⏸️ Operação "${operationName}" já está em andamento desde ${new Date(existingOperation.startedAt).toLocaleTimeString()}`;
            
            console.log(message);
            if (showUserMessage) {
                this.showMessage('warning', `Já existe uma operação de ${this.getFriendlyOperationName(operationName)} em andamento. Aguarde a conclusão.`);
            }
            return { blocked: true, reason: 'already_running', message };
        }

        // Verificar se é uma operação bloqueadora e se há outra operação bloqueadora em andamento
        if (this.isBlockingOperation(operationName) && this.hasBlockingOperationRunning()) {
            const blockingOps = this.getRunningBlockingOperations();
            const message = `⏸️ Não é possível executar "${operationName}" porque há operações bloqueadoras em andamento: ${blockingOps.join(', ')}`;
            
            console.log(message);
            if (showUserMessage) {
                this.showMessage('warning', `Não é possível ${this.getFriendlyOperationName(operationName)} enquanto ${blockingOps.map(op => this.getFriendlyOperationName(op)).join(' ou ')} está em andamento.`);
            }
            return { blocked: true, reason: 'blocking_operation_running', message };
        }

        // Verificar limite de operações paralelas
        if (!allowParallel && this.getRunningOperationsCount() >= maxParallel) {
            const message = `⏸️ Limite de operações simultâneas atingido (${this.getRunningOperationsCount()}/${maxParallel}). Operação "${operationName}" bloqueada.`;
            
            console.log(message);
            if (showUserMessage) {
                this.showMessage('warning', 'Muitas operações em andamento. Aguarde algumas operações terminarem.');
            }
            return { blocked: true, reason: 'max_parallel_reached', message };
        }

        // Verificar lock global (para operações críticas)
        if (this.globalRequestLock && !allowParallel) {
            console.log(`🔒 Sistema ocupado. Bloqueando operação: ${operationName}`);
            if (showUserMessage) {
                this.showMessage('warning', 'Sistema ocupado. Aguarde a operação atual terminar.');
            }
            return { blocked: true, reason: 'system_busy', message: 'Sistema ocupado' };
        }

        // Criar ID único para esta instância da operação
        const operationId = `${operationName}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        try {
            // Registrar operação
            this.pendingRequests.set(operationName, {
                id: operationId,
                startedAt: new Date(),
                type: operationName
            });

            // Aplicar lock global se for operação bloqueadora
            if (this.isBlockingOperation(operationName)) {
                this.globalRequestLock = true;
                console.log(`🔐 Aplicando LOCK GLOBAL para operação bloqueadora: ${operationName}`);
            }

            console.log(`🔐 Iniciando operação: ${operationName} (ID: ${operationId})`);
            
            // Configurar timeout
            const timeoutPromise = new Promise((_, reject) => {
                const timeoutId = setTimeout(() => {
                    reject(new Error(`Operação "${operationName}" excedeu o tempo limite de ${timeout/1000} segundos`));
                }, timeout);
                
                this.operationTimeouts.set(operationId, timeoutId);
            });

            // Executar operação com timeout
            const operationPromise = operation();
            const result = await Promise.race([operationPromise, timeoutPromise]);
            
            console.log(`✅ Operação concluída: ${operationName} (ID: ${operationId})`);
            return { blocked: false, result, operationId };
            
        } catch (error) {
            console.error(`❌ Erro na operação ${operationName} (ID: ${operationId}):`, error);
            
            // Mostrar mensagem de erro específica para timeouts
            if (error.message.includes('excedeu o tempo limite')) {
                this.showMessage('error', `Operação ${this.getFriendlyOperationName(operationName)} demorou muito e foi cancelada. Tente novamente.`);
            } else {
                if (showUserMessage) {
                    this.showMessage('error', `Erro na operação ${this.getFriendlyOperationName(operationName)}: ${error.message}`);
                }
            }
            
            throw error;
        } finally {
            // Sempre limpar recursos
            this.cleanupOperation(operationName, operationId);
        }
    }

    // ✅ NOVO: Limpar recursos da operação
    cleanupOperation(operationName, operationId) {
        // Remover da lista de operações pendentes
        const currentOp = this.pendingRequests.get(operationName);
        if (currentOp && currentOp.id === operationId) {
            this.pendingRequests.delete(operationName);
        }

        // Limpar timeout
        const timeoutId = this.operationTimeouts.get(operationId);
        if (timeoutId) {
            clearTimeout(timeoutId);
            this.operationTimeouts.delete(operationId);
        }

        // Liberar lock global se não há mais operações bloqueadoras
        if (this.globalRequestLock && !this.hasBlockingOperationRunning()) {
            this.globalRequestLock = false;
            console.log('🔓 Liberando LOCK GLOBAL - nenhuma operação bloqueadora em andamento');
        }

        console.log(`🔓 Limpeza concluída para operação: ${operationName} (ID: ${operationId})`);
    }

    // ✅ NOVO: Verificar se é uma operação bloqueadora
    isBlockingOperation(operationName) {
        return this.blockingOperationTypes.includes(operationName);
    }

    // ✅ NOVO: Verificar se há operação bloqueadora em andamento
    hasBlockingOperationRunning() {
        return Array.from(this.pendingRequests.keys()).some(op => 
            this.isBlockingOperation(op)
        );
    }

    // ✅ NOVO: Obter operações bloqueadoras em andamento
    getRunningBlockingOperations() {
        return Array.from(this.pendingRequests.keys()).filter(op => 
            this.isBlockingOperation(op)
        );
    }

    // ✅ NOVO: Contar operações em andamento
    getRunningOperationsCount() {
        return this.pendingRequests.size;
    }

    // ✅ NOVO: Obter nome amigável para operação
    getFriendlyOperationName(operationName) {
        const names = {
            'load-departments': 'carregamento de departamentos',
            'load-from-papercut': 'carregamento do PaperCut',
            'refresh-all-papercut': 'atualização completa do PaperCut',
            'apply-monthly-quotas': 'aplicação de cotas mensais',
            'clear-cache': 'limpeza de cache',
            'reload-department': 'atualização de departamento',
            'test-connection': 'teste de conexão',
            'save-quotas': 'salvamento de cotas'
        };
        
        return names[operationName] || operationName;
    }

    // ✅ NOVO: Verificar se pode executar operação (para uso em botões)
    canExecuteOperation(operationName) {
        if (this.pendingRequests.has(operationName)) {
            console.log(`⏸️ Operação "${operationName}" já está em andamento`);
            return false;
        }
        
        if (this.isBlockingOperation(operationName) && this.hasBlockingOperationRunning()) {
            console.log(`⏸️ Operação bloqueadora "${operationName}" não pode executar enquanto há outras operações bloqueadoras`);
            return false;
        }
        
        if (this.globalRequestLock && !this.limitedParallelOperations.includes(operationName)) {
            console.log(`🔒 Sistema ocupado. Não pode executar: ${operationName}`);
            return false;
        }
        
        return true;
    }

    // ✅ NOVO: Obter status das operações (para debug)
    getOperationsStatus() {
        const status = {
            globalLock: this.globalRequestLock,
            pendingOperations: Array.from(this.pendingRequests.entries()).map(([name, info]) => ({
                name,
                startedAt: info.startedAt,
                duration: Date.now() - info.startedAt.getTime()
            })),
            queueLength: this.operationQueue.length,
            processingQueue: this.processingQueue
        };
        
        console.log('📊 Status das Operações:', status);
        return status;
    }

    // ✅ NOVO: Verificar se deve inicializar o app
    shouldInitialize() {
        // Verificar se estamos na página accounts.html
        const isAccountsPage = window.location.pathname === '/' || 
                              window.location.pathname.includes('accounts') ||
                              document.getElementById('departments-tbody') !== null;
        
        // Verificar elementos específicos da página accounts
        const hasAccountsElements = document.getElementById('departments-tbody') && 
                                   document.getElementById('departments-table-container');
        
        return isAccountsPage && hasAccountsElements;
    }

    async init() {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            console.log('❌ App não deve inicializar nesta página. Abortando.');
            return;
        }

        console.log('=== INICIANDO PAPERCUT MANAGER NO ACCOUNTS.HTML ===');
        
        try {
            // Verificar renovação mensal primeiro
            await this.checkMonthlyRenewalStatus();
            
            // 1. Teste de conexão
            const connected = await this.testConnectionSimple();
            
            if (connected) {
                // 2. Carregar departamentos
                await this.loadDepartmentsSimple();
            }
        } catch (error) {
            console.error('💥 Erro no init:', error);
            this.showError('Erro ao inicializar: ' + error.message);
        }
    }

    // ✅ VERIFICAR STATUS DE RENOVAÇÃO MENSAL
    async checkMonthlyRenewalStatus() {
        try {
            const response = await fetch('/api/monthly-renewal-status');
            const data = await response.json();
            
            if (data.status === 'success' && data.data.is_applying) {
                this.showRenewalNotification();
            }
        } catch (error) {
            console.log('Não foi possível verificar status de renovação:', error);
        }
    }

    // ✅ MOSTRAR NOTIFICAÇÃO DE RENOVAÇÃO
    showRenewalNotification() {
        // Remover notificação existente
        const existingNotification = document.getElementById('renewal-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        const renewalAlert = document.createElement('div');
        renewalAlert.id = 'renewal-notification';
        renewalAlert.className = 'alert alert-info alert-dismissible fade show mb-0 rounded-0';
        renewalAlert.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1060;
            border-radius: 0;
            text-align: center;
            font-weight: bold;
        `;
        renewalAlert.innerHTML = `
            <div class="container">
                <i class="bi bi-arrow-repeat me-2"></i>
                <strong>ATENÇÃO:</strong> Renovação mensal de cotas em andamento. 
                Os saldos estão sendo atualizados. Por favor, aguarde o término da renovação.
                <button type="button" class="btn-close ms-2" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        document.body.prepend(renewalAlert);
    }

    // ✅ MÉTODOS PARA POPUP DE CARREGAMENTO GLOBAL
    showGlobalLoading(message = 'Carregando...') {
        // Remover loading existente
        this.hideGlobalLoading();
        
        const loadingOverlay = document.createElement('div');
        loadingOverlay.id = 'global-loading-overlay';
        loadingOverlay.className = 'loading-overlay';
        loadingOverlay.innerHTML = `
            <div class="loading-content">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
                <h4 class="mt-3">${message}</h4>
                <p class="text-muted">Por favor, aguarde...</p>
            </div>
        `;
        
        document.body.appendChild(loadingOverlay);
        
        // Bloquear interação com a página
        document.body.style.overflow = 'hidden';
        this.isLoading = true;
    }

    hideGlobalLoading() {
        const loadingOverlay = document.getElementById('global-loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.remove();
        }
        document.body.style.overflow = '';
        this.isLoading = false;
    }

    // ✅ NOVO: MENSAGEM FIXA DE ATUALIZAÇÃO
    showUpdateNotification(message = 'Atualizando dados do PaperCut...') {
        // Remover notificação existente
        this.hideUpdateNotification();
        
        const updateNotification = document.createElement('div');
        updateNotification.id = 'update-notification';
        updateNotification.className = 'alert alert-warning alert-dismissible fade show mb-0 rounded-0';
        updateNotification.style.cssText = `
            position: fixed;
            top: 60px; /* Abaixo do navbar */
            left: 0;
            width: 100%;
            z-index: 1059;
            border-radius: 0;
            text-align: center;
            font-weight: bold;
            border-left: 5px solid #ffc107;
            animation: slideInDown 0.5s ease-out;
        `;
        updateNotification.innerHTML = `
            <div class="container">
                <div class="d-flex align-items-center justify-content-center">
                    <div class="spinner-border spinner-border-sm text-warning me-2" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    <strong>🔄 ${message}</strong>
                    <div class="ms-3">
                        <span class="badge bg-warning text-dark">ATUALIZANDO</span>
                    </div>
                </div>
            </div>
        `;
        
        document.body.prepend(updateNotification);
        this.isUpdatingFromPaperCut = true;
    }

    hideUpdateNotification() {
        const updateNotification = document.getElementById('update-notification');
        if (updateNotification) {
            // Adicionar animação de saída
            updateNotification.style.animation = 'slideOutUp 0.5s ease-out';
            setTimeout(() => {
                if (updateNotification.parentNode) {
                    updateNotification.remove();
                }
            }, 500);
        }
        this.isUpdatingFromPaperCut = false;
    }

    // ✅ NOVO: ATUALIZAR MENSAGEM DE PROGRESSO
    updateProgressMessage(message) {
        const updateNotification = document.getElementById('update-notification');
        if (updateNotification) {
            const strongElement = updateNotification.querySelector('strong');
            if (strongElement) {
                strongElement.innerHTML = `🔄 ${message}`;
            }
        }
    }

    async testConnectionSimple() {
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock('test-connection', async () => {
            try {
                this.updateConnectionStatus('checking', 'Verificando conexão...');
                
                const response = await fetch('/api/test-connection-simple');
                const data = await response.json();
                
                if (data.status === 'success') {
                    this.updateConnectionStatus('success', 'Conectado');
                    this.connectionStatus = 'success';
                    return true;
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                console.error('❌ Falha na conexão:', error);
                this.updateConnectionStatus('error', 'Desconectado');
                this.connectionStatus = 'error';
                return false;
            }
        }, {
            allowParallel: true,
            showUserMessage: false
        });

        if (lockResult.blocked) {
            return false;
        }
        
        return lockResult.result;
    }

    async loadDepartmentsSimple() {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            console.log('❌ Não é página de accounts. Abortando carregamento.');
            return;
        }

        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock('load-departments', async () => {
            this.showGlobalLoading('Carregando departamentos...');
            
            try {
                this.showLoading(true);
                
                // ✅ ESTRATÉGIA: Sempre tentar cache primeiro
                console.log('🔄 Tentando carregar do cache compartilhado...');
                let response = await fetch('/api/departments-with-cache');
                let data = await response.json();
                
                console.log('📦 Resposta do cache:', data);
                
                if (data.status === 'success') {
                    this.departments = data.data.departments || [];
                    this.totalDepartments = this.departments.length;
                    
                    if (this.departments.length > 0) {
                        // ✅ SUCESSO: Temos dados no cache
                        console.log(`🎯 ${this.departments.length} departamentos carregados do CACHE COMPARTILHADO`);
                        
                        this.renderDepartments();
                        this.updateStatistics();
                        
                        // Verificar se o cache está válido
                        const cacheValid = data.data.cache_info?.cache_valid;
                        const cacheAge = data.data.departments[0]?.cache_age_minutes;
                        
                        if (cacheValid) {
                            this.showMessage('success', `Dados carregados do cache`);
                        } else {
                            this.showMessage('warning', `Dados do cache podem estar desatualizados`);
                        }
                        
                    } else {
                        // ✅ CACHE VAZIO: Precisamos carregar do PaperCut
                        console.log('📝 Cache vazio, carregando do PaperCut...');
                        await this.loadFromPaperCutAndPopulateCache();
                    }
                    
                } else {
                    // ❌ ERRO NO CACHE: Tentar método tradicional
                    console.log('❌ Erro no cache, usando método tradicional...');
                    await this.loadFromPaperCutAndPopulateCache();
                }
                
            } catch (error) {
                console.error('💥 Erro ao carregar departamentos:', error);
                this.showError('Erro ao carregar departamentos: ' + error.message);
            } finally {
                this.showLoading(false);
                this.hideGlobalLoading();
            }
        });

        if (lockResult.blocked) {
            console.log('⏸️ Carregamento de departamentos bloqueado - já existe uma operação em andamento');
        }
    }

    // ✅ MÉTODO: Carregar do PaperCut e popular cache (COM MENSAGEM FIXA)
    async loadFromPaperCutAndPopulateCache() {
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock('load-from-papercut', async () => {
            try {
                console.log('🔄 Carregando dados do PaperCut...');
                
                // ✅ MOSTRAR MENSAGEM FIXA DE ATUALIZAÇÃO
                this.showUpdateNotification('Atualizando todos os departamentos do PaperCut...');
                
                const response = await fetch('/api/departments-with-balances');
                const data = await response.json();
                
                if (data.status === 'success') {
                    this.departments = data.data.departments || [];
                    this.totalDepartments = this.departments.length;
                    
                    console.log(`🎯 ${this.departments.length} departamentos carregados do PAPERCUT`);
                    
                    this.renderDepartments();
                    this.updateStatistics();
                    
                    this.showMessage('info', 'Dados carregados diretamente do PaperCut');
                    
                    // ✅ POPULAR O CACHE para próximos usuários
                    await this.populateCache();
                    
                } else {
                    throw new Error(data.message || 'Erro ao carregar do PaperCut');
                }
            } catch (error) {
                console.error('💥 Erro ao carregar do PaperCut:', error);
                this.showError('Erro ao carregar do PaperCut: ' + error.message);
                throw error;
            } finally {
                // ✅ SEMPRE ESCONDER A MENSAGEM FIXA
                this.hideUpdateNotification();
            }
        });

        if (lockResult.blocked) {
            console.log('⏸️ Carregamento do PaperCut bloqueado - já existe uma operação em andamento');
        } else {
            return lockResult.result;
        }
    }

    // ✅ MÉTODO PARA POPULAR CACHE
    async populateCache() {
        try {
            console.log('🔄 Populando cache compartilhado...');
            // Esta função pode ser implementada se necessário para forçar atualização do cache
        } catch (error) {
            console.error('Erro ao popular cache:', error);
        }
    }

    // ✅ NOVO: MÉTODO PARA ATUALIZAR TODOS DO PAPERCUT (COM PROGRESSO)
    async refreshAllFromPaperCutWithProgress() {
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock('refresh-all-papercut', async () => {
            if (this.isLoading || this.isUpdatingFromPaperCut) {
                this.showMessage('warning', 'Já existe uma atualização em andamento');
                return;
            }

            if (!confirm('Isso irá atualizar TODOS os departamentos diretamente do PaperCut. Pode demorar alguns minutos. Continuar?')) {
                return;
            }
            
            try {
                // ✅ MOSTRAR MENSAGEM FIXA COM PROGRESSO
                this.showUpdateNotification('Conectando ao PaperCut...');
                
                // Simular etapas para mostrar progresso
                this.updateProgressMessage('Conectando ao servidor PaperCut...');
                await this.delay(1000);
                
                this.updateProgressMessage('Buscando lista de departamentos...');
                await this.delay(1000);
                
                this.updateProgressMessage('Carregando saldos dos departamentos...');
                
                // Fazer a atualização real
                await this.loadFromPaperCutAndPopulateCache();
                
                this.showMessage('success', 'Todos os departamentos foram atualizados do PaperCut!');
                
            } catch (error) {
                console.error('Erro ao atualizar todos:', error);
                this.showError('Erro ao atualizar: ' + error.message);
            } finally {
                // Garantir que a mensagem seja removida mesmo em caso de erro
                this.hideUpdateNotification();
            }
        });

        if (lockResult.blocked) {
            console.log('⏸️ Atualização completa bloqueada - já existe uma operação em andamento');
        }
    }

    renderDepartments() {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            console.log('❌ Não é página de accounts. Abortando renderização.');
            return;
        }

        const tbody = document.getElementById('departments-tbody');
        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (!tbody) {
            console.error('❌ tbody não encontrado');
            return;
        }
        
        if (this.departments.length === 0) {
            this.showEmptyState();
            return;
        }
        
        if (tableContainer) tableContainer.classList.remove('d-none');
        if (emptyState) emptyState.classList.add('d-none');
        
        tbody.innerHTML = this.departments.map(dept => `
            <tr data-department="${this.escapeHtml(dept.name)}" class="department-row">
                ${this.getDepartmentRowHTML(dept)}
            </tr>
        `).join('');
        
        console.log(`✅ ${this.departments.length} departamentos renderizados`);
    }

    getDepartmentRowHTML(dept) {
        const colorDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.color_balance > 0 ? 'bg-success' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.color_balance)}</span>`;
        
        const monoDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.mono_balance > 0 ? 'bg-info' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.mono_balance)}</span>`;
        
        const totalDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.total_balance > 0 ? 'bg-primary' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.total_balance)}</span>`;

        const errorBadge = dept.loadError ? '<br><small class="text-danger fs-6">⚠️ Erro</small>' : '';
        
        // ✅ INDICADOR DE FONTE MELHORADO
        let sourceBadge = '';
        if (dept.source === 'cache') {
            if (dept.cache_valid) {
                sourceBadge = '';
            } else {
                sourceBadge = '';
            }
        } else if (dept.source === 'papercut') {
            sourceBadge = '<br><small class="text-info fs-6">🔄 Live</small>';
        }

        return `
            <td class="align-middle">
                <strong class="fs-5 fw-bold">${this.escapeHtml(dept.name)}</strong>
                ${errorBadge}
                ${sourceBadge}
            </td>
            <td class="text-center align-middle">${colorDisplay}</td>
            <td class="text-center align-middle">${monoDisplay}</td>
            <td class="text-center align-middle">${totalDisplay}</td>
            <td class="text-center align-middle">
                <button class="btn btn-outline-primary me-1" 
                        onclick="app.editDepartment('${this.escapeHtml(dept.name)}')"
                        ${dept.isLoading ? 'disabled' : ''}
                        title="Editar cotas">
                    <i class="bi bi-pencil fs-5"></i>
                </button>
                <button class="btn btn-outline-warning" 
                        onclick="app.reloadDepartment('${this.escapeHtml(dept.name)}')"
                        ${dept.isLoading ? 'disabled' : ''}
                        title="Atualizar deste departamento do PaperCut">
                    <i class="bi bi-arrow-clockwise fs-5"></i>
                </button>
            </td>
        `;
    }

    // Status de conexão no navbar
    updateConnectionStatus(status, message) {
        const statusElement = document.getElementById('connection-status');
        if (!statusElement) return;
        
        statusElement.className = 'badge me-3';
        
        switch (status) {
            case 'success':
                statusElement.classList.add('bg-success');
                statusElement.innerHTML = '<i class="bi bi-wifi me-1"></i>Conectado';
                break;
            case 'error':
                statusElement.classList.add('bg-danger');
                statusElement.innerHTML = '<i class="bi bi-wifi-off me-1"></i>Desconectado';
                break;
            case 'checking':
                statusElement.classList.add('bg-warning');
                statusElement.innerHTML = '<i class="bi bi-wifi-2 me-1"></i>Verificando...';
                break;
        }
        
        this.connectionStatus = status;
    }

    // Botão de recarregar individual
    async reloadDepartment(departmentName) {
        const operationName = `reload-${departmentName}`;
        
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock(operationName, async () => {
            if (this.isLoading) {
                this.showMessage('warning', 'Aguarde o carregamento atual terminar');
                return;
            }

            const deptIndex = this.departments.findIndex(d => d.name === departmentName);
            if (deptIndex === -1) return;
            
            this.departments[deptIndex].isLoading = true;
            this.renderSingleDepartment(departmentName);
            
            try {
                // ✅ USAR NOVA ROTA: Atualiza no PaperCut E no cache
                const response = await fetch(`/api/department/${encodeURIComponent(departmentName)}/refresh-balance`, {
                    method: 'POST'
                });
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    // Atualizar apenas este departamento
                    this.updateDepartmentBalance(
                        departmentName,
                        data.data.color_balance,
                        data.data.mono_balance,
                        false
                    );
                    
                    this.showMessage('success', `Saldo de ${departmentName} atualizado do PaperCut`);
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                console.error(`❌ Erro ao atualizar ${departmentName}:`, error);
                this.showMessage('error', `Erro ao atualizar ${departmentName}`);
                
                // Restaurar estado de carregamento
                this.departments[deptIndex].isLoading = false;
                this.renderSingleDepartment(departmentName);
            }
        }, {
            allowParallel: true, // Permitir múltiplas atualizações de departamentos
            maxParallel: 5 // Até 5 departamentos simultaneamente
        });

        if (lockResult.blocked) {
            console.log(`⏸️ Recarregamento de ${departmentName} bloqueado - já existe uma operação em andamento`);
        }
    }

    updateDepartmentBalance(departmentName, colorBalance, monoBalance, isError = false) {
        const deptIndex = this.departments.findIndex(d => d.name === departmentName);
        if (deptIndex !== -1) {
            this.departments[deptIndex] = {
                ...this.departments[deptIndex],
                color_balance: colorBalance,
                mono_balance: monoBalance,
                total_balance: colorBalance + monoBalance,
                isLoading: false,
                loadError: isError
            };
            
            this.renderSingleDepartment(departmentName);
            this.updateStatistics();
        }
    }

    renderSingleDepartment(departmentName) {
        const dept = this.departments.find(d => d.name === departmentName);
        if (!dept) return;
        
        const row = document.querySelector(`tr[data-department="${this.escapeHtml(departmentName)}"]`);
        if (row) {
            row.innerHTML = this.getDepartmentRowHTML(dept);
        }
    }

    // Editar departamento
    editDepartment(departmentName) {
        const department = this.departments.find(d => d.name === departmentName);
        if (!department) {
            this.showMessage('error', 'Departamento não encontrado');
            return;
        }
        
        this.currentEditingDepartment = departmentName;
        
        // Preencher modal com valores atuais
        document.getElementById('edit-department-name').textContent = departmentName;
        document.getElementById('edit-color-quota').value = department.color_balance;
        document.getElementById('edit-mono-quota').value = department.mono_balance;
        document.getElementById('current-color-balance').textContent = this.formatNumber(department.color_balance);
        document.getElementById('current-mono-balance').textContent = this.formatNumber(department.mono_balance);
        
        // Buscar valores mensais do servidor
        this.loadMonthlyQuotas(departmentName);
        
        // Mostrar modal
        const modal = new bootstrap.Modal(document.getElementById('editQuotasModal'));
        modal.show();
    }

    // Método para carregar cotas mensais do servidor
    async loadMonthlyQuotas(departmentName) {
        try {
            const response = await fetch(`/api/department-monthly-quotas/${encodeURIComponent(departmentName)}`);
            const data = await response.json();
            
            if (data.status === 'success') {
                document.getElementById('monthly-color-quota').value = data.data.monthly_color_quota || 0;
                document.getElementById('monthly-mono-quota').value = data.data.monthly_mono_quota || 0;
            } else {
                document.getElementById('monthly-color-quota').value = 0;
                document.getElementById('monthly-mono-quota').value = 0;
            }
        } catch (error) {
            console.error(`❌ Erro ao carregar cotas mensais: ${error}`);
            document.getElementById('monthly-color-quota').value = 0;
            document.getElementById('monthly-mono-quota').value = 0;
        }
    }

    async saveQuotas() {
        if (!this.currentEditingDepartment) {
            this.showMessage('error', 'Nenhum departamento selecionado');
            return;
        }
        
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock(`save-quotas-${this.currentEditingDepartment}`, async () => {
            const colorQuota = parseFloat(document.getElementById('edit-color-quota').value) || 0;
            const monoQuota = parseFloat(document.getElementById('edit-mono-quota').value) || 0;
            const monthlyColorQuota = parseFloat(document.getElementById('monthly-color-quota').value) || 0;
            const monthlyMonoQuota = parseFloat(document.getElementById('monthly-mono-quota').value) || 0;
            
            if (colorQuota < 0 || monoQuota < 0 || monthlyColorQuota < 0 || monthlyMonoQuota < 0) {
                this.showMessage('error', 'As cotas não podem ser negativas');
                return;
            }
            
            try {
                const deptIndex = this.departments.findIndex(d => d.name === this.currentEditingDepartment);
                if (deptIndex !== -1) {
                    this.departments[deptIndex].isLoading = true;
                    this.renderSingleDepartment(this.currentEditingDepartment);
                }
                
                const response = await fetch(`/api/departments/${encodeURIComponent(this.currentEditingDepartment)}/quotas`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        color: colorQuota,
                        mono: monoQuota,
                        monthly_color: monthlyColorQuota,
                        monthly_mono: monthlyMonoQuota
                    })
                });
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    this.showMessage('success', data.message);
                    
                    // Fechar modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('editQuotasModal'));
                    modal?.hide();
                    
                    // Atualizar APENAS este departamento
                    await this.updateSingleDepartmentAfterSave(this.currentEditingDepartment);
                    
                } else {
                    throw new Error(data.message || 'Erro ao atualizar cotas');
                }
            } catch (error) {
                console.error('💥 Falha ao salvar cotas:', error);
                this.showMessage('error', 'Erro ao salvar cotas: ' + error.message);
                
                const deptIndex = this.departments.findIndex(d => d.name === this.currentEditingDepartment);
                if (deptIndex !== -1) {
                    this.departments[deptIndex].isLoading = false;
                    this.renderSingleDepartment(this.currentEditingDepartment);
                }
            }
        }, {
            allowParallel: true
        });

        if (lockResult.blocked) {
            console.log(`⏸️ Salvamento de cotas bloqueado - já existe uma operação em andamento`);
        }
    }

    // Método para atualizar apenas um departamento após salvar
    async updateSingleDepartmentAfterSave(departmentName) {
        try {
            // Buscar dados atualizados apenas deste departamento
            const response = await fetch(`/api/department-simple/${encodeURIComponent(departmentName)}/balance`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateDepartmentBalance(
                    departmentName,
                    data.data.color_balance,
                    data.data.mono_balance,
                    false
                );
            } else {
                throw new Error('Erro ao buscar dados atualizados');
            }
        } catch (error) {
            console.error(`❌ Erro ao atualizar ${departmentName}:`, error);
            await this.reloadDepartment(departmentName);
        }
    }

    // ✅ MÉTODO: Aplicar cotas mensais
    async applyMonthlyQuotas(force = false) {
        // ✅ USAR SISTEMA DE LOCK
        const lockResult = await this.withRequestLock('apply-monthly-quotas', async () => {
            if (this.isLoading) {
                this.showMessage('warning', 'Aguarde o carregamento atual terminar');
                return;
            }

            const confirmMessage = force ? 
                'Tem certeza que deseja aplicar as cotas mensais mesmo se já foram aplicadas este mês?' :
                'Tem certeza que deseja aplicar as cotas mensais para todos os departamentos?';
            
            if (!confirm(confirmMessage)) return;
            
            try {
                this.showGlobalLoading('Aplicando cotas mensais...');
                
                const response = await fetch('/api/script-quotas/apply-monthly', { 
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        force: force
                    })
                });
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    const summary = data.data.summary || data.data;
                    const message = summary.success !== undefined ? 
                        `Cotas aplicadas: ${summary.success} sucessos, ${summary.errors} erros, ${summary.skipped || 0} ignorados` :
                        data.message;
                    
                    this.showMessage('success', message);
                    
                    // Recarregar os dados após aplicar as cotas
                    await this.loadDepartmentsSimple();
                    
                } else {
                    throw new Error(data.message || 'Erro ao aplicar cotas mensais');
                }
            } catch (error) {
                console.error('Failed to apply monthly quotas:', error);
                this.showMessage('error', 'Erro ao aplicar cotas: ' + error.message);
            } finally {
                this.hideGlobalLoading();
            }
        });

        if (lockResult.blocked) {
            console.log('⏸️ Aplicação de cotas mensais bloqueada - já existe uma operação em andamento');
        }
    }

    // Métodos auxiliares
    updateStatistics() {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            return;
        }

        if (this.departments.length === 0) return;
        
        const totalDepartments = this.departments.length;
        const totalColor = this.departments.reduce((sum, dept) => sum + dept.color_balance, 0);
        const totalMono = this.departments.reduce((sum, dept) => sum + dept.mono_balance, 0);
        const totalPages = totalColor + totalMono;
        
        document.getElementById('total-departments').textContent = totalDepartments;
        document.getElementById('total-color').textContent = this.formatNumber(totalColor);
        document.getElementById('total-mono').textContent = this.formatNumber(totalMono);
        document.getElementById('total-pages').textContent = this.formatNumber(totalPages);
    }

    showLoading(show) {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            return;
        }

        const spinner = document.getElementById('loading-spinner');
        const tableContainer = document.getElementById('departments-table-container');
        
        if (spinner) {
            if (show) {
                spinner.classList.remove('d-none');
            } else {
                spinner.classList.add('d-none');
            }
        }
        
        if (tableContainer && this.departments.length > 0) {
            tableContainer.classList.remove('d-none');
        }
    }

    showEmptyState() {
        // ✅ VERIFICAÇÃO EXTRA: Confirmar que estamos na página correta
        if (!this.shouldInitialize()) {
            return;
        }

        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (tableContainer && emptyState) {
            tableContainer.classList.add('d-none');
            emptyState.classList.remove('d-none');
        }
    }

    showMessage(type, message) {
        const toastContainer = document.getElementById('toast-container') || (() => {
            const container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(container);
            return container;
        })();
        
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.id = toastId;
        toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : type === 'warning' ? 'warning' : 'danger'} border-0`;
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body fs-5">
                    <i class="bi ${type === 'success' ? 'bi-check-circle' : type === 'warning' ? 'bi-exclamation-triangle' : 'bi-exclamation-triangle'} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, { delay: 4000 });
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', () => {
            if (document.body.contains(toast)) {
                toast.remove();
            }
        });
    }

    showError(message) {
        this.showMessage('error', message);
    }

    formatNumber(num) {
        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(num || 0);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// ========== FUNÇÕES GLOBAIS CORRIGIDAS ==========

// ✅ FUNÇÃO: Verificar se estamos na página accounts
function isAccountsPage() {
    return window.location.pathname === '/' || 
           window.location.pathname.includes('accounts') ||
           document.getElementById('departments-tbody') !== null;
}

// ✅ FUNÇÃO: Verificar se pode executar operação
function canExecuteOperation(operationName) {
    if (!window.app || !window.app.canExecuteOperation) {
        return true; // Fallback se app não estiver disponível
    }
    return window.app.canExecuteOperation(operationName);
}

async function refreshData() {
    if (!isAccountsPage()) {
        console.log('❌ Função refreshData chamada fora da página accounts. Ignorando.');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    if (!canExecuteOperation('load-departments')) {
        if (window.app) {
            window.app.showMessage('warning', 'Já existe um carregamento em andamento. Aguarde a conclusão.');
        }
        return;
    }
    
    await app.testConnectionSimple();
    await app.loadDepartmentsSimple();
}

async function reloadDepartment(departmentName) {
    if (!isAccountsPage()) {
        console.log('❌ Função reloadDepartment chamada fora da página accounts. Ignorando.');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    const operationName = `reload-${departmentName}`;
    if (!canExecuteOperation(operationName)) {
        if (window.app) {
            window.app.showMessage('warning', `Já existe uma atualização em andamento para ${departmentName}. Aguarde a conclusão.`);
        }
        return;
    }
    
    await app.reloadDepartment(departmentName);
}

function editDepartment(departmentName) {
    if (!isAccountsPage()) {
        console.log('❌ Função editDepartment chamada fora da página accounts. Ignorando.');
        return;
    }
    app.editDepartment(departmentName);
}

async function saveQuotas() {
    if (!isAccountsPage()) {
        console.log('❌ Função saveQuotas chamada fora da página accounts. Ignorando.');
        return;
    }
    
    if (!app.currentEditingDepartment) {
        app.showMessage('error', 'Nenhum departamento selecionado');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    const operationName = `save-quotas-${app.currentEditingDepartment}`;
    if (!canExecuteOperation(operationName)) {
        app.showMessage('warning', 'Já existe uma operação de salvamento em andamento. Aguarde a conclusão.');
        return;
    }
    
    await app.saveQuotas();
}

// ✅ CORREÇÃO: Funções para aplicar cotas mensais
async function applyMonthlyQuotas(force = false) {
    if (!isAccountsPage()) {
        console.log('❌ Função applyMonthlyQuotas chamada fora da página accounts. Ignorando.');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    if (!canExecuteOperation('apply-monthly-quotas')) {
        if (window.app) {
            window.app.showMessage('warning', 'Já existe uma aplicação de cotas mensais em andamento. Aguarde a conclusão.');
        }
        return;
    }
    
    await app.applyMonthlyQuotas(force);
}

// ✅ CORREÇÃO: Função para testar conexão
async function testConnection() {
    if (!isAccountsPage()) {
        console.log('❌ Função testConnection chamada fora da página accounts. Ignorando.');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    if (!canExecuteOperation('test-connection')) {
        if (window.app) {
            window.app.showMessage('warning', 'Já existe um teste de conexão em andamento. Aguarde a conclusão.');
        }
        return;
    }
    
    await app.testConnectionSimple();
}

// ✅ FUNÇÃO: Atualizar todos os departamentos do PaperCut (COM MENSAGEM FIXA)
async function refreshAllFromPaperCut() {
    if (!isAccountsPage()) {
        console.log('❌ Função refreshAllFromPaperCut chamada fora da página accounts. Ignorando.');
        return;
    }
    
    // ✅ VERIFICAR SE PODE EXECUTAR
    if (!canExecuteOperation('refresh-all-papercut')) {
        if (window.app) {
            window.app.showMessage('warning', 'Já existe uma atualização completa em andamento. Aguarde a conclusão.');
        }
        return;
    }
    
    await app.refreshAllFromPaperCutWithProgress();
}

// ✅ FUNÇÃO: Limpar cache
async function clearCache() {
    if (!isAccountsPage()) {
        console.log('❌ Função clearCache chamada fora da página accounts. Ignorando.');
        return;
    }

    // ✅ VERIFICAR SE PODE EXECUTAR
    if (!canExecuteOperation('clear-cache')) {
        if (window.app) {
            window.app.showMessage('warning', 'Já existe uma operação de limpeza de cache em andamento. Aguarde a conclusão.');
        }
        return;
    }

    if (!confirm('Isso irá limpar todo o cache. Os próximos usuários precisarão carregar os dados do PaperCut novamente. Continuar?')) {
        return;
    }
    
    try {
        const response = await fetch('/api/clear-cache', { method: 'POST' });
        const data = await response.json();
        
        if (data.status === 'success') {
            app.showMessage('success', data.message);
            // Recarregar os dados (que agora virão do PaperCut)
            await refreshData();
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        console.error('Erro ao limpar cache:', error);
        app.showMessage('error', 'Erro ao limpar cache: ' + error.message);
    }
}

// ✅ NOVA FUNÇÃO: Verificar status das operações (para debug)
function showOperationsStatus() {
    if (app && app.getOperationsStatus) {
        app.getOperationsStatus();
    } else {
        console.log('App não inicializado ou função não disponível');
    }
}

// ✅ INICIALIZAÇÃO SEGURA
console.log('📦 Carregando PaperCut Manager...');

// Inicializar app globalmente apenas se for a página accounts
if (window.location.pathname === '/' || 
    window.location.pathname.includes('accounts') ||
    document.getElementById('departments-tbody') !== null) {
    console.log('✅ Inicializando App na página accounts.html');
    window.app = new PaperCutManager();
} else {
    console.log('❌ Não é página accounts. App não inicializado.');
    // Criar um objeto app vazio para evitar erros
    window.app = {
        isLoading: false,
        showMessage: function(type, message) {
            console.log(`[${type}] ${message}`);
        },
        showError: function(message) {
            console.log(`[error] ${message}`);
        },
        canExecuteOperation: function() {
            return true; // Sempre permitir operações se app não estiver inicializado
        }
    };
}