// PaperCut Manager - Versão com Funções Corrigidas

class PaperCutManager {
    constructor() {
        this.departments = [];
        this.connectionStatus = 'checking';
        this.currentEditingDepartment = null;
        this.loadedDepartments = 0;
        this.totalDepartments = 0;
        
        document.addEventListener('DOMContentLoaded', () => {
            console.log('🚀 DOM Carregado - Iniciando App');
            this.init();
        });
    }

    async init() {
        console.log('=== INICIANDO PAPERCUT MANAGER ===');
        
        // 1. Teste de conexão
        const connected = await this.testConnectionSimple();
        
        if (connected) {
            // 2. Carregar departamentos
            await this.loadDepartmentsSimple();
        }
    }

    async testConnectionSimple() {
        try {
            this.updateConnectionStatus('checking', 'Verificando conexão...');
            
            const response = await fetch('/api/test-connection-simple');
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateConnectionStatus('success', 'Conectado');
                this.connectionStatus = 'success';
                return true;
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('❌ Falha na conexão:', error);
            this.updateConnectionStatus('error', 'Desconectado');
            this.connectionStatus = 'error';
            return false;
        }
    }

    async loadDepartmentsSimple() {
        try {
            this.showLoading(true);
            
            // ✅ ESTRATÉGIA: Sempre tentar cache primeiro
            console.log('🔄 Tentando carregar do cache compartilhado...');
            let response = await fetch('/api/departments-with-cache');
            let data = await response.json();
            
            console.log('📦 Resposta do cache:', data);
            
            if (data.status === 'success') {
                this.departments = data.data.departments || [];
                this.totalDepartments = this.departments.length;
                
                if (this.departments.length > 0) {
                    // ✅ SUCESSO: Temos dados no cache
                    console.log(`🎯 ${this.departments.length} departamentos carregados do CACHE COMPARTILHADO`);
                    
                    this.renderDepartments();
                    this.updateStatistics();
                    
                    // Verificar se o cache está válido
                    const cacheValid = data.data.cache_info?.cache_valid;
                    const cacheAge = data.data.departments[0]?.cache_age_minutes;
                    
                    if (cacheValid) {
                        this.showMessage('success', `Dados carregados do cache`);
                    } else {
                        this.showMessage('warning', `Dados do cache podem estar desatualizados`);
                    }
                    
                } else {
                    // ✅ CACHE VAZIO: Precisamos carregar do PaperCut
                    console.log('📝 Cache vazio, carregando do PaperCut...');
                    await this.loadFromPaperCutAndPopulateCache();
                }
                
            } else {
                // ❌ ERNO NO CACHE: Tentar método tradicional
                console.log('❌ Erro no cache, usando método tradicional...');
                await this.loadFromPaperCutAndPopulateCache();
            }
            
        } catch (error) {
            console.error('💥 Erro ao carregar departamentos:', error);
            this.showError('Erro ao carregar departamentos: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }

    // ✅ NOVO MÉTODO: Carregar do PaperCut e popular cache
    async loadFromPaperCutAndPopulateCache() {
        try {
            console.log('🔄 Carregando dados do PaperCut...');
            
            const response = await fetch('/api/departments-with-balances');
            const data = await response.json();
            
            if (data.status === 'success') {
                this.departments = data.data.departments || [];
                this.totalDepartments = this.departments.length;
                
                console.log(`🎯 ${this.departments.length} departamentos carregados do PAPERCUT`);
                
                this.renderDepartments();
                this.updateStatistics();
                
                this.showMessage('info', 'Dados carregados diretamente do PaperCut');
                
                // ✅ POPULAR O CACHE para próximos usuários
                await this.populateCache();
                
            } else {
                throw new Error(data.message || 'Erro ao carregar do PaperCut');
            }
        } catch (error) {
            console.error('💥 Erro ao carregar do PaperCut:', error);
            throw error;
        }
    }

    async loadBalancesOneByOne() {
        if (!this.departments.length) return;
        
        console.log(`🔄 Carregando saldos para ${this.departments.length} departamentos`);
        
        // 1. ✅ Mostrar barra de progresso na tabela
        this.showTableProgressBar();
        
        for (let i = 0; i < this.departments.length; i++) {
            const dept = this.departments[i];
            await this.loadSingleDepartmentBalance(dept.name, i);
            await this.delay(100); // Pausa reduzida para ser mais rápido
            
            // 2. ✅ Atualizar progresso a cada departamento
            this.loadedDepartments++;
            const progress = Math.round((this.loadedDepartments / this.totalDepartments) * 100);
            this.updateTableProgress(progress);
        }
        
        // Esconder barra de progresso quando terminar
        this.hideTableProgressBar();
        this.showMessage('success', 'Todos os departamentos carregados!');
    }

    async loadSingleDepartmentBalance(departmentName, index) {
        try {
            const response = await fetch(`/api/department-simple/${encodeURIComponent(departmentName)}/balance`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateDepartmentBalance(
                    departmentName,
                    data.data.color_balance,
                    data.data.mono_balance
                );
            } else {
                this.updateDepartmentBalance(departmentName, 0, 0, true);
            }
        } catch (error) {
            console.error(`❌ Erro em ${departmentName}:`, error);
            this.updateDepartmentBalance(departmentName, 0, 0, true);
        }
    }

    updateDepartmentBalance(departmentName, colorBalance, monoBalance, isError = false) {
        const deptIndex = this.departments.findIndex(d => d.name === departmentName);
        if (deptIndex !== -1) {
            this.departments[deptIndex] = {
                ...this.departments[deptIndex],
                color_balance: colorBalance,
                mono_balance: monoBalance,
                total_balance: colorBalance + monoBalance,
                isLoading: false,
                loadError: isError
            };
            
            this.renderSingleDepartment(departmentName);
            this.updateStatistics();
        }
    }

    renderSingleDepartment(departmentName) {
        const dept = this.departments.find(d => d.name === departmentName);
        if (!dept) return;
        
        const row = document.querySelector(`tr[data-department="${this.escapeHtml(departmentName)}"]`);
        if (row) {
            row.innerHTML = this.getDepartmentRowHTML(dept);
        }
    }

    getDepartmentRowHTML(dept) {
        const colorDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.color_balance > 0 ? 'bg-success' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.color_balance)}</span>`;
        
        const monoDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.mono_balance > 0 ? 'bg-info' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.mono_balance)}</span>`;
        
        const totalDisplay = dept.isLoading ? 
            '<div class="spinner-border text-primary" style="width: 1.8rem; height: 1.8rem;" title="Carregando..."></div>' :
            `<span class="badge ${dept.total_balance > 0 ? 'bg-primary' : 'bg-secondary'} fs-5 px-3 py-2">${this.formatNumber(dept.total_balance)}</span>`;

        const errorBadge = dept.loadError ? '<br><small class="text-danger fs-6">⚠️ Erro</small>' : '';
        
        // ✅ INDICADOR DE FONTE MELHORADO
        let sourceBadge = '';
        if (dept.source === 'cache') {
            if (dept.cache_valid) {
                sourceBadge = '';
            } else {
                sourceBadge = '';
            }
        } else if (dept.source === 'papercut') {
            sourceBadge = '<br><small class="text-info fs-6">🔄 Live</small>';
        }

        return `
            <td class="align-middle">
                <strong class="fs-5 fw-bold">${this.escapeHtml(dept.name)}</strong>
                ${errorBadge}
                ${sourceBadge}
            </td>
            <td class="text-center align-middle">${colorDisplay}</td>
            <td class="text-center align-middle">${monoDisplay}</td>
            <td class="text-center align-middle">${totalDisplay}</td>
            <td class="text-center align-middle">
                <button class="btn btn-outline-primary me-1" 
                        onclick="app.editDepartment('${this.escapeHtml(dept.name)}')"
                        ${dept.isLoading ? 'disabled' : ''}
                        title="Editar cotas">
                    <i class="bi bi-pencil fs-5"></i>
                </button>
                <button class="btn btn-outline-warning" 
                        onclick="app.reloadDepartment('${this.escapeHtml(dept.name)}')"
                        ${dept.isLoading ? 'disabled' : ''}
                        title="Atualizar deste departamento do PaperCut">
                    <i class="bi bi-arrow-clockwise fs-5"></i>
                </button>
            </td>
        `;
    }

    renderDepartments() {
        const tbody = document.getElementById('departments-tbody');
        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (!tbody) return;
        
        if (this.departments.length === 0) {
            this.showEmptyState();
            return;
        }
        
        tableContainer.classList.remove('d-none');
        emptyState.classList.add('d-none');
        
        tbody.innerHTML = this.departments.map(dept => `
            <tr data-department="${this.escapeHtml(dept.name)}" class="department-row">
                ${this.getDepartmentRowHTML(dept)}
            </tr>
        `).join('');
    }

    // 1. ✅ Barra de progresso na tabela
    showTableProgressBar() {
        const tbody = document.getElementById('departments-tbody');
        if (!tbody) return;
        
        // Criar linha de progresso
        const progressRow = document.createElement('tr');
        progressRow.id = 'table-progress-row';
        progressRow.innerHTML = `
            <td colspan="5" class="text-center py-4">
                <div class="d-flex align-items-center justify-content-center">
                    <div class="me-3">
                        <div class="spinner-border text-primary" style="width: 2.5rem; height: 2.5rem;" role="status">
                            <span class="visually-hidden">Carregando...</span>
                        </div>
                    </div>
                    <div class="flex-grow-1">
                        <div class="progress" style="height: 16px;">
                            <div id="table-progress-bar" 
                                 class="progress-bar progress-bar-striped progress-bar-animated bg-success" 
                                 role="progressbar" 
                                 style="width: 0%" 
                                 aria-valuenow="0" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100">
                            </div>
                        </div>
                        <div id="table-progress-text" class="text-muted mt-2 fs-6 fw-semibold">Carregando saldos... 0%</div>
                    </div>
                </div>
            </td>
        `;
        
        tbody.appendChild(progressRow);
    }

    // 2. ✅ Atualizar barra de progresso na tabela
    updateTableProgress(percent) {
        const progressBar = document.getElementById('table-progress-bar');
        const progressText = document.getElementById('table-progress-text');
        
        if (progressBar && progressText) {
            progressBar.style.width = `${percent}%`;
            progressBar.setAttribute('aria-valuenow', percent);
            
            const remaining = 100 - percent;
            progressText.textContent = `Carregando saldos... ${percent}% (${this.loadedDepartments}/${this.totalDepartments})`;
            
            // Mudar cor conforme progresso
            if (percent < 30) {
                progressBar.className = 'progress-bar progress-bar-striped progress-bar-animated bg-warning';
            } else if (percent < 70) {
                progressBar.className = 'progress-bar progress-bar-striped progress-bar-animated bg-info';
            } else {
                progressBar.className = 'progress-bar progress-bar-striped progress-bar-animated bg-success';
            }
        }
    }

    hideTableProgressBar() {
        const progressRow = document.getElementById('table-progress-row');
        if (progressRow) {
            progressRow.remove();
        }
    }

    // Status de conexão no navbar
    updateConnectionStatus(status, message) {
        const statusElement = document.getElementById('connection-status');
        if (!statusElement) return;
        
        statusElement.className = 'badge me-3';
        
        switch (status) {
            case 'success':
                statusElement.classList.add('bg-success');
                statusElement.innerHTML = '<i class="bi bi-wifi me-1"></i>Conectado';
                break;
            case 'error':
                statusElement.classList.add('bg-danger');
                statusElement.innerHTML = '<i class="bi bi-wifi-off me-1"></i>Desconectado';
                break;
            case 'checking':
                statusElement.classList.add('bg-warning');
                statusElement.innerHTML = '<i class="bi bi-wifi-2 me-1"></i>Verificando...';
                break;
        }
        
        this.connectionStatus = status;
    }

    // Botão de recarregar individual
    async reloadDepartment(departmentName) {
        const deptIndex = this.departments.findIndex(d => d.name === departmentName);
        if (deptIndex === -1) return;
        
        this.departments[deptIndex].isLoading = true;
        this.renderSingleDepartment(departmentName);
        
        try {
            // ✅ USAR NOVA ROTA: Atualiza no PaperCut E no cache
            const response = await fetch(`/api/department/${encodeURIComponent(departmentName)}/refresh-balance`, {
                method: 'POST'
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                // Atualizar apenas este departamento
                this.updateDepartmentBalance(
                    departmentName,
                    data.data.color_balance,
                    data.data.mono_balance,
                    false
                );
                
                this.showMessage('success', `Saldo de ${departmentName} atualizado do PaperCut`);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error(`❌ Erro ao atualizar ${departmentName}:`, error);
            this.showMessage('error', `Erro ao atualizar ${departmentName}`);
            
            // Restaurar estado de carregamento
            this.departments[deptIndex].isLoading = false;
            this.renderSingleDepartment(departmentName);
        }
    }

    // Editar departamento
    editDepartment(departmentName) {
        const department = this.departments.find(d => d.name === departmentName);
        if (!department) {
            this.showMessage('error', 'Departamento não encontrado');
            return;
        }
        
        this.currentEditingDepartment = departmentName;
        
        // Preencher modal com valores atuais
        document.getElementById('edit-department-name').textContent = departmentName;
        document.getElementById('edit-color-quota').value = department.color_balance;
        document.getElementById('edit-mono-quota').value = department.mono_balance;
        document.getElementById('current-color-balance').textContent = this.formatNumber(department.color_balance);
        document.getElementById('current-mono-balance').textContent = this.formatNumber(department.mono_balance);
        
        // Buscar valores mensais do servidor
        this.loadMonthlyQuotas(departmentName);
        
        // Mostrar modal
        const modal = new bootstrap.Modal(document.getElementById('editQuotasModal'));
        modal.show();
    }

    // Método para carregar cotas mensais do servidor
    async loadMonthlyQuotas(departmentName) {
        try {
            const response = await fetch(`/api/department-monthly-quotas/${encodeURIComponent(departmentName)}`);
            const data = await response.json();
            
            if (data.status === 'success') {
                document.getElementById('monthly-color-quota').value = data.data.monthly_color_quota || 0;
                document.getElementById('monthly-mono-quota').value = data.data.monthly_mono_quota || 0;
            } else {
                document.getElementById('monthly-color-quota').value = 0;
                document.getElementById('monthly-mono-quota').value = 0;
            }
        } catch (error) {
            console.error(`❌ Erro ao carregar cotas mensais: ${error}`);
            document.getElementById('monthly-color-quota').value = 0;
            document.getElementById('monthly-mono-quota').value = 0;
        }
    }

    async saveQuotas() {
        if (!this.currentEditingDepartment) {
            this.showMessage('error', 'Nenhum departamento selecionado');
            return;
        }
        
        const colorQuota = parseFloat(document.getElementById('edit-color-quota').value) || 0;
        const monoQuota = parseFloat(document.getElementById('edit-mono-quota').value) || 0;
        const monthlyColorQuota = parseFloat(document.getElementById('monthly-color-quota').value) || 0;
        const monthlyMonoQuota = parseFloat(document.getElementById('monthly-mono-quota').value) || 0;
        
        console.log(`💾 Salvando cotas para ${this.currentEditingDepartment}:`);
        console.log(`   Color: ${colorQuota} páginas, Mono: ${monoQuota} páginas`);
        console.log(`   Monthly Color: ${monthlyColorQuota} páginas, Monthly Mono: ${monthlyMonoQuota} páginas`);
        
        if (colorQuota < 0 || monoQuota < 0 || monthlyColorQuota < 0 || monthlyMonoQuota < 0) {
            this.showMessage('error', 'As cotas não podem ser negativas');
            return;
        }
        
        try {
            const deptIndex = this.departments.findIndex(d => d.name === this.currentEditingDepartment);
            if (deptIndex !== -1) {
                this.departments[deptIndex].isLoading = true;
                this.renderSingleDepartment(this.currentEditingDepartment);
            }
            
            const response = await fetch(`/api/departments/${encodeURIComponent(this.currentEditingDepartment)}/quotas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    color: colorQuota,
                    mono: monoQuota,
                    monthly_color: monthlyColorQuota,
                    monthly_mono: monthlyMonoQuota
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showMessage('success', data.message);
                
                // Fechar modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('editQuotasModal'));
                modal?.hide();
                
                // Atualizar APENAS este departamento
                await this.updateSingleDepartmentAfterSave(this.currentEditingDepartment);
                
            } else {
                throw new Error(data.message || 'Erro ao atualizar cotas');
            }
        } catch (error) {
            console.error('💥 Falha ao salvar cotas:', error);
            this.showMessage('error', 'Erro ao salvar cotas: ' + error.message);
            
            const deptIndex = this.departments.findIndex(d => d.name === this.currentEditingDepartment);
            if (deptIndex !== -1) {
                this.departments[deptIndex].isLoading = false;
                this.renderSingleDepartment(this.currentEditingDepartment);
            }
        }
    }

    // Método para atualizar apenas um departamento após salvar
    async updateSingleDepartmentAfterSave(departmentName) {
        try {
            // Buscar dados atualizados apenas deste departamento
            const response = await fetch(`/api/department-simple/${encodeURIComponent(departmentName)}/balance`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateDepartmentBalance(
                    departmentName,
                    data.data.color_balance,
                    data.data.mono_balance,
                    false
                );
            } else {
                throw new Error('Erro ao buscar dados atualizados');
            }
        } catch (error) {
            console.error(`❌ Erro ao atualizar ${departmentName}:`, error);
            await this.reloadDepartment(departmentName);
        }
    }

    // ✅ NOVO MÉTODO: Aplicar cotas mensais
    async applyMonthlyQuotas(force = false) {
        const confirmMessage = force ? 
            'Tem certeza que deseja aplicar as cotas mensais mesmo se já foram aplicadas este mês?' :
            'Tem certeza que deseja aplicar as cotas mensais para todos os departamentos?';
        
        if (!confirm(confirmMessage)) return;
        
        try {
            this.showMessage('info', 'Aplicando cotas mensais...');
            
            const response = await fetch('/api/script-quotas/apply-monthly', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    force: force
                })
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                const summary = data.data.summary || data.data;
                const message = summary.success !== undefined ? 
                    `Cotas aplicadas: ${summary.success} sucessos, ${summary.errors} erros, ${summary.skipped || 0} ignorados` :
                    data.message;
                
                this.showMessage('success', message);
                
                // Recarregar os dados após aplicar as cotas
                await this.loadDepartmentsSimple();
                
            } else {
                throw new Error(data.message || 'Erro ao aplicar cotas mensais');
            }
        } catch (error) {
            console.error('Failed to apply monthly quotas:', error);
            this.showMessage('error', 'Erro ao aplicar cotas: ' + error.message);
        }
    }

    // Métodos auxiliares
    updateStatistics() {
        if (this.departments.length === 0) return;
        
        const totalDepartments = this.departments.length;
        const totalColor = this.departments.reduce((sum, dept) => sum + dept.color_balance, 0);
        const totalMono = this.departments.reduce((sum, dept) => sum + dept.mono_balance, 0);
        const totalPages = totalColor + totalMono;
        
        document.getElementById('total-departments').textContent = totalDepartments;
        document.getElementById('total-color').textContent = this.formatNumber(totalColor);
        document.getElementById('total-mono').textContent = this.formatNumber(totalMono);
        document.getElementById('total-pages').textContent = this.formatNumber(totalPages);
    }

    showLoading(show) {
        const spinner = document.getElementById('loading-spinner');
        const tableContainer = document.getElementById('departments-table-container');
        
        if (spinner) {
            if (show) {
                spinner.classList.remove('d-none');
            } else {
                spinner.classList.add('d-none');
            }
        }
        
        if (tableContainer && this.departments.length > 0) {
            tableContainer.classList.remove('d-none');
        }
    }

    showEmptyState() {
        const tableContainer = document.getElementById('departments-table-container');
        const emptyState = document.getElementById('empty-state');
        
        if (tableContainer && emptyState) {
            tableContainer.classList.add('d-none');
            emptyState.classList.remove('d-none');
        }
    }

    showMessage(type, message) {
        // Toast Bootstrap melhorado
        const toastContainer = document.getElementById('toast-container') || (() => {
            const container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(container);
            return container;
        })();
        
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.id = toastId;
        toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body fs-5">
                    <i class="bi ${type === 'success' ? 'bi-check-circle' : 'bi-exclamation-triangle'} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, { delay: 4000 });
        bsToast.show();
        
        // Remover após fechar
        toast.addEventListener('hidden.bs.toast', () => {
            if (document.body.contains(toast)) {
                toast.remove();
            }
        });
    }

    showError(message) {
        this.showMessage('error', message);
    }

    formatNumber(num) {
        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(num || 0);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    
}

// ========== FUNÇÕES GLOBAIS CORRIGIDAS ==========

async function refreshData() {
    await app.testConnectionSimple();
    await app.loadDepartmentsSimple();
}

async function reloadDepartment(departmentName) {
    await app.reloadDepartment(departmentName);
}

function editDepartment(departmentName) {
    app.editDepartment(departmentName);
}

async function saveQuotas() {
    await app.saveQuotas();
}

// ✅ CORREÇÃO: Funções para aplicar cotas mensais
async function applyMonthlyQuotas(force = false) {
    await app.applyMonthlyQuotas(force);
}

// ✅ CORREÇÃO: Função para testar conexão
async function testConnection() {
    await app.testConnectionSimple();
}

// ✅ CORREÇÃO: Função para salvar conexão (se necessário)
async function saveConnection() {
    // Implementação se necessário
    console.log('Salvar conexão - função placeholder');
}

// ✅ FUNÇÃO: Atualizar todos os departamentos do PaperCut
async function refreshAllFromPaperCut() {
    if (!confirm('Isso irá atualizar TODOS os departamentos diretamente do PaperCut. Pode demorar alguns minutos. Continuar?')) {
        return;
    }
    
    try {
        app.showMessage('info', 'Atualizando todos os departamentos do PaperCut...');
        await app.loadFromPaperCutAndPopulateCache();
    } catch (error) {
        console.error('Erro ao atualizar todos:', error);
        app.showMessage('error', 'Erro ao atualizar: ' + error.message);
    }
}

// ✅ FUNÇÃO: Limpar cache
async function clearCache() {
    if (!confirm('Isso irá limpar todo o cache. Os próximos usuários precisarão carregar os dados do PaperCut novamente. Continuar?')) {
        return;
    }
    
    try {
        const response = await fetch('/api/clear-cache', { method: 'POST' });
        const data = await response.json();
        
        if (data.status === 'success') {
            app.showMessage('success', data.message);
            // Recarregar os dados (que agora virão do PaperCut)
            await refreshData();
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        console.error('Erro ao limpar cache:', error);
        app.showMessage('error', 'Erro ao limpar cache: ' + error.message);
    }
}




// Inicializar
const app = new PaperCutManager();