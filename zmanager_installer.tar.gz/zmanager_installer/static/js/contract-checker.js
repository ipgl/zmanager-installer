// Função para verificar o contrato
async function checkContract() {
    if (window.disableContractCheck) {
        return true; // Não verificar nesta página
    }
    
    try {
        const response = await fetch('/api/check_contract');
        const data = await response.json();
        
        if (!data.active) {
            window.location.href = '/contrato_expirado';
            return false;
        }
        return true;
    } catch (error) {
        console.error('Erro ao verificar contrato:', error);
        return true;
    }
}

// Só inicializar se não estiver desativado
if (!window.disableContractCheck) {
    // Verificar contrato ao carregar a página
    document.addEventListener('DOMContentLoaded', function() {
        checkContract();
    });

    // Verificação periódica a cada minuto
    setInterval(() => {
        checkContract();
    }, 60000);

    // Verificar também quando a página ganha foco
    window.addEventListener('focus', checkContract);

    // Interceptar todos os cliques em links
    document.addEventListener('click', function(e) {
        const target = e.target.closest('a');
        if (target && target.href && !target.hasAttribute('data-no-check')) {
            const isExternal = target.hostname !== window.location.hostname;
            const isSamePage = target.hash || target.href === window.location.href;
            
            if (!isExternal && !isSamePage) {
                e.preventDefault();
                
                checkContract().then(isActive => {
                    if (isActive) {
                        window.location.href = target.href;
                    }
                });
            }
        }
    });

    // Interceptar submissões de formulário
    document.addEventListener('submit', function(e) {
        const form = e.target;
        
        checkContract().then(isActive => {
            if (!isActive) {
                e.preventDefault();
            }
        });
    });
}

// Função para redirecionamento seguro
function safeRedirect(url) {
    checkContract().then(isActive => {
        if (isActive) {
            window.location.href = url;
        }
    });
}
