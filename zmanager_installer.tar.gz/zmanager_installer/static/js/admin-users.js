// [file name]: static/js/admin-users.js
// Adicionar estas funções no início do admin-users.js (antes da classe UserManager)
const DateUtils = {
    formatDateTime(dateString) {
        if (!dateString) return 'Nunca';
        
        try {
            const date = new Date(dateString);
            
            if (isNaN(date.getTime())) {
                return 'Data inválida';
            }
            
            // Formato: DD/MM/YYYY, HH:MM:SS
            const day = date.getDate().toString().padStart(2, '0');
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');
            
            return `${day}/${month}/${year}, ${hours}:${minutes}:${seconds}`;
        } catch (error) {
            console.error('Erro ao formatar data:', error);
            return 'Erro na data';
        }
    },

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        
        try {
            const date = new Date(dateString);
            
            if (isNaN(date.getTime())) {
                return 'Data inválida';
            }
            
            const day = date.getDate().toString().padStart(2, '0');
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            
            return `${day}/${month}/${year}`;
        } catch (error) {
            console.error('Erro ao formatar data:', error);
            return 'Erro na data';
        }
    }
};

class UserManager {
    constructor() {
        this.users = [];
        this.currentUserId = null;
        this.init();
    }

    init() {
        this.loadUsers();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Recarregar usuários quando modal for fechado (sem jQuery)
        const createUserModal = document.getElementById('createUserModal');
        if (createUserModal) {
            createUserModal.addEventListener('hidden.bs.modal', () => {
                const form = document.getElementById('create-user-form');
                if (form) form.reset();
            });
        }

        // Event delegation para todos os botões de ação
        const tableBody = document.getElementById('users-table-body');
        if (tableBody) {
            tableBody.addEventListener('click', (e) => {
                const target = e.target;
                
                // Encontrar o botão clicado (pode ser o ícone ou o botão)
                const button = target.closest('.toggle-admin-btn, .reset-password-btn, .toggle-active-btn, .delete-user-btn');
                
                if (button) {
                    const userId = parseInt(button.getAttribute('data-user-id'));
                    
                    if (button.classList.contains('toggle-admin-btn')) {
                        this.toggleAdmin(userId);
                    } else if (button.classList.contains('reset-password-btn')) {
                        this.showResetPasswordModal(userId);
                    } else if (button.classList.contains('toggle-active-btn')) {
                        this.toggleActive(userId);
                    } else if (button.classList.contains('delete-user-btn')) {
                        this.showDeleteModal(userId);
                    }
                }
            });
        }
    }

    async loadUsers() {
        try {
            this.showLoading('Carregando usuários...');
            
            const response = await fetch('/admin/users', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.users = data.data;
                this.renderUsersTable();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao carregar usuários:', error);
            this.showAlert('error', `Erro ao carregar usuários: ${error.message}`);
        } finally {
            this.hideLoading();
        }
    }

    renderUsersTable() {
        const tbody = document.getElementById('users-table-body');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        if (this.users.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">
                        <i class="bi bi-people display-4 d-block mb-2"></i>
                        Nenhum usuário encontrado
                    </td>
                </tr>
            `;
            return;
        }

        this.users.forEach(user => {
            const row = this.createUserRow(user);
            tbody.appendChild(row);
        });
    }

    createUserRow(user) {
        const row = document.createElement('tr');
        
        // Estilo para usuário inativo
        if (!user.is_active) {
            row.classList.add('table-secondary');
        }

        row.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <i class="bi bi-person-circle me-2"></i>
                    <strong>${this.escapeHtml(user.username)}</strong>
                    ${user.requires_password_change ? '<span class="badge bg-warning ms-2" title="Precisa trocar senha"><i class="bi bi-key"></i></span>' : ''}
                </div>
            </td>
            <td>${this.escapeHtml(user.email)}</td>
            <td>
                <span class="badge ${user.is_admin ? 'bg-primary' : 'bg-secondary'}">
                    ${user.is_admin ? 'Admin' : 'Usuário'}
                </span>
            </td>
            <td>
                <span class="badge ${user.is_active ? 'bg-success' : 'bg-danger'}">
                    ${user.is_active ? 'Ativo' : 'Inativo'}
                </span>
            </td>
            <td>
                ${user.last_login ? new Date(user.last_login).toLocaleString('pt-BR') : 'Nunca'}
            </td>
            <td>${new Date(user.created_at).toLocaleDateString('pt-BR')}</td>
            <td>
                <div class="btn-group btn-group-sm">
                    ${user.id !== 1 ? `
                    <button class="btn btn-outline-primary toggle-admin-btn" data-user-id="${user.id}" 
                            title="${user.is_admin ? 'Remover Admin' : 'Tornar Admin'}">
                        <i class="bi bi-${user.is_admin ? 'person-dash' : 'person-check'}"></i>
                    </button>
                    <button class="btn btn-outline-warning reset-password-btn" data-user-id="${user.id}" 
                            title="Resetar Senha">
                        <i class="bi bi-key"></i>
                    </button>
                    <button class="btn btn-outline-${user.is_active ? 'secondary' : 'success'} toggle-active-btn" 
                            data-user-id="${user.id}"
                            title="${user.is_active ? 'Desativar' : 'Ativar'}">
                        <i class="bi bi-${user.is_active ? 'person-x' : 'person-check'}"></i>
                    </button>
                    ${user.id !== currentUser.id ? `
                    <button class="btn btn-outline-danger delete-user-btn" data-user-id="${user.id}" 
                            title="Excluir Usuário">
                        <i class="bi bi-trash"></i>
                    </button>
                    ` : ''}
                    ` : `
                    <span class="badge bg-info">Admin Padrão</span>
                    `}
                </div>
            </td>
        `;

        return row;
    }

    async toggleAdmin(userId) {
        try {
            const response = await fetch(`/admin/users/${userId}/toggle-admin`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.showAlert('success', data.message);
                await this.loadUsers();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao alternar admin:', error);
            this.showAlert('error', `Erro: ${error.message}`);
        }
    }

    async toggleActive(userId) {
        try {
            const response = await fetch(`/admin/users/${userId}/toggle-active`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.showAlert('success', data.message);
                await this.loadUsers();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao alternar status ativo:', error);
            this.showAlert('error', `Erro: ${error.message}`);
        }
    }

    showResetPasswordModal(userId) {
        const user = this.users.find(u => u.id === userId);
        if (!user) return;

        this.currentUserId = userId;
        
        const message = document.getElementById('reset-password-message');
        if (!message) return;
        
        message.innerHTML = `Tem certeza que deseja resetar a senha do usuário <strong>${this.escapeHtml(user.username)}</strong>?<br>
                           O usuário será obrigado a trocar a senha no próximo login.`;
        
        // Esconder alerta de senha temporária
        const tempPasswordAlert = document.getElementById('temp-password-alert');
        if (tempPasswordAlert) {
            tempPasswordAlert.classList.add('d-none');
        }
        
        const modalElement = document.getElementById('resetPasswordModal');
        if (modalElement) {
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
        }
    }

    async confirmResetPassword() {
        if (!this.currentUserId) return;

        try {
            const response = await fetch(`/admin/users/${this.currentUserId}/reset-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                // Mostrar senha temporária
                const tempPasswordAlert = document.getElementById('temp-password-alert');
                const tempPasswordSpan = document.getElementById('temp-password');
                
                if (tempPasswordAlert && tempPasswordSpan) {
                    tempPasswordSpan.textContent = data.data.temporary_password;
                    tempPasswordAlert.classList.remove('d-none');
                }
                
                this.showAlert('success', 'Senha resetada com sucesso. Anote a senha temporária.');
                await this.loadUsers();
                
                // Fechar modal após 5 segundos
                setTimeout(() => {
                    const modalElement = document.getElementById('resetPasswordModal');
                    if (modalElement) {
                        const modal = bootstrap.Modal.getInstance(modalElement);
                        if (modal) modal.hide();
                    }
                }, 5000);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao resetar senha:', error);
            this.showAlert('error', `Erro: ${error.message}`);
            const modalElement = document.getElementById('resetPasswordModal');
            if (modalElement) {
                const modal = bootstrap.Modal.getInstance(modalElement);
                if (modal) modal.hide();
            }
        }
    }

    showDeleteModal(userId) {
        const user = this.users.find(u => u.id === userId);
        if (!user) return;

        this.currentUserId = userId;
        
        const message = document.getElementById('delete-user-message');
        if (!message) return;
        
        message.innerHTML = `Tem certeza que deseja excluir o usuário <strong>${this.escapeHtml(user.username)}</strong>?`;
        
        const modalElement = document.getElementById('deleteUserModal');
        if (modalElement) {
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
        }
    }

    async confirmDeleteUser() {
        if (!this.currentUserId) return;

        try {
            const response = await fetch(`/admin/users/${this.currentUserId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.showAlert('success', data.message);
                const modalElement = document.getElementById('deleteUserModal');
                if (modalElement) {
                    const modal = bootstrap.Modal.getInstance(modalElement);
                    if (modal) modal.hide();
                }
                await this.loadUsers();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao excluir usuário:', error);
            this.showAlert('error', `Erro: ${error.message}`);
            const modalElement = document.getElementById('deleteUserModal');
            if (modalElement) {
                const modal = bootstrap.Modal.getInstance(modalElement);
                if (modal) modal.hide();
            }
        }
    }

    async createUser() {
        const form = document.getElementById('create-user-form');
        if (!form) return;

        const formData = new FormData(form);
        
        const userData = {
            username: formData.get('username'),
            email: formData.get('email'),
            password: formData.get('password'),
            is_admin: document.getElementById('is_admin').checked
        };

        // Validação básica
        if (!userData.username || !userData.email || !userData.password) {
            this.showAlert('error', 'Todos os campos são obrigatórios');
            return;
        }

        if (userData.password.length < 6) {
            this.showAlert('error', 'A senha deve ter pelo menos 6 caracteres');
            return;
        }

        try {
            const response = await fetch('/admin/users/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.showAlert('success', data.message);
                const modalElement = document.getElementById('createUserModal');
                if (modalElement) {
                    const modal = bootstrap.Modal.getInstance(modalElement);
                    if (modal) modal.hide();
                }
                await this.loadUsers();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Erro ao criar usuário:', error);
            this.showAlert('error', `Erro: ${error.message}`);
        }
    }

    // Métodos utilitários
    escapeHtml(unsafe) {
        if (!unsafe) return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    showAlert(type, message) {
        const alertContainer = document.getElementById('alert-container');
        if (!alertContainer) {
            console.warn('Container de alertas não encontrado');
            return;
        }
        
        // Remover alertas antigos
        const oldAlerts = alertContainer.querySelectorAll('.alert');
        oldAlerts.forEach(alert => alert.remove());
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alert);
        
        // Auto-remover após 5 segundos
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    }

    showLoading(message = 'Carregando...') {
        // Você pode implementar um spinner de loading aqui
        console.log('Loading:', message);
    }

    hideLoading() {
        // Você pode implementar o hide do spinner aqui
        console.log('Hide loading');
    }
}

// Tornar userManager global
let userManager;

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    userManager = new UserManager();
});

// Funções globais para compatibilidade com modais
function createUser() {
    if (userManager) {
        userManager.createUser();
    } else {
        console.error('UserManager não inicializado');
    }
}

function confirmResetPassword() {
    if (userManager) {
        userManager.confirmResetPassword();
    } else {
        console.error('UserManager não inicializado');
    }
}

function confirmDeleteUser() {
    if (userManager) {
        userManager.confirmDeleteUser();
    } else {
        console.error('UserManager não inicializado');
    }
}