"""
Rotas de autenticação para o PaperCut Manager
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, get_db_session
from datetime import datetime
import logging

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')
logger = logging.getLogger(__name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = bool(request.form.get('remember'))
        
        if not username or not password:
            flash('Por favor, preencha todos os campos', 'error')
            return render_template('login.html')
        
        db = get_db_session()
        try:
            user = db.query(User).filter_by(username=username).first()
            
            if user and check_password_hash(user.password_hash, password):
                login_user(user, remember=remember)
                # Atualizar último login
                user.last_login = datetime.utcnow()
                db.commit()
                
                flash(f'Bem-vindo, {username}!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page or url_for('index'))
            else:
                flash('Usuário ou senha inválidos', 'error')
        except Exception as e:
            logger.error(f"Erro no login: {e}")
            flash('Erro interno do sistema', 'error')
        finally:
            db.close()
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validações básicas
        if not username or not email or not password:
            flash('Todos os campos são obrigatórios', 'error')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('As senhas não coincidem', 'error')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('A senha deve ter pelo menos 6 caracteres', 'error')
            return render_template('register.html')
        
        db = get_db_session()
        try:
            # Verificar se usuário já existe
            existing_user = db.query(User).filter(
                (User.username == username) | (User.email == email)
            ).first()
            
            if existing_user:
                flash('Usuário ou email já existem', 'error')
                return render_template('register.html')
            
            # Criar novo usuário
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password)
            )
            
            db.add(new_user)
            db.commit()
            
            flash('Conta criada com sucesso! Faça login.', 'success')
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro no registro: {e}")
            flash('Erro ao criar conta', 'error')
        finally:
            db.close()
    
    return render_template('register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    username = current_user.username
    logout_user()
    flash(f'Até logo, {username}! Você foi desconectado.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile')
@login_required
def profile():
    return render_template('profile.html', user=current_user)

@auth_bp.route('/api/user')
@login_required
def get_user_info():
    return jsonify({
        'username': current_user.username,
        'email': current_user.email,
        'created_at': current_user.created_at.isoformat(),
        'last_login': current_user.last_login.isoformat() if current_user.last_login else None,
        'is_admin': current_user.is_admin
    })

@auth_bp.route('/api/user/public')
def get_user_info_public():
    """API pública para obter informações básicas do usuário"""
    if current_user.is_authenticated:
        return jsonify({
            'username': current_user.username,
            'email': current_user.email,
            'is_authenticated': True
        })
    else:
        return jsonify({
            'is_authenticated': False,
            'message': 'Usuário não autenticado'
        })

@auth_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'Dados não fornecidos'}), 400
        
        db = get_db_session()
        try:
            user = db.query(User).get(current_user.id)
            
            if 'email' in data:
                # Verificar se email já existe (exceto para o usuário atual)
                existing_user = db.query(User).filter(
                    User.email == data['email'],
                    User.id != current_user.id
                ).first()
                
                if existing_user:
                    return jsonify({'success': False, 'message': 'Email já está em uso'}), 400
                
                user.email = data['email']
            
            if 'password' in data and data['password']:
                if len(data['password']) < 6:
                    return jsonify({'success': False, 'message': 'A senha deve ter pelo menos 6 caracteres'}), 400
                
                user.password_hash = generate_password_hash(data['password'])
            
            db.commit()
            
            return jsonify({
                'success': True,
                'message': 'Perfil atualizado com sucesso'
            })
            
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao atualizar perfil: {e}")
        return jsonify({'success': False, 'message': 'Erro interno do sistema'}), 500