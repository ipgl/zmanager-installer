"""
Rotas Flask otimizadas para o PaperCut Manager
"""

from flask import Blueprint, jsonify, request
from papercut_api import PaperCutAPI
from config import Config
from models import Department, QuotaHistory, get_db_session, create_tables
from datetime import datetime, timedelta
import logging
from flask_login import login_required, current_user




bp = Blueprint('papercut', __name__)
logger = logging.getLogger(__name__)

# Initialize API client
api = PaperCutAPI(Config.PAPERCUT_SERVER_URL, Config.PAPERCUT_AUTH_TOKEN)

# Initialize database tables
create_tables()

@bp.route('/api/connection', methods=['GET'])
@login_required
def test_connection():
    """Endpoint para testar conexão"""
    try:
        force = request.args.get('force', 'false').lower() == 'true'
        result = api.test_connection(force=force)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Erro no teste de conexão: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/connection/config', methods=['GET', 'POST'])
@login_required
def connection_config():
    """Endpoint para configurar conexão com PaperCut"""
    global api
    
    if request.method == 'GET':
        return jsonify({
            'status': 'success',
            'data': {
                'server_url': api.server_url,
                'connected': api._connection_status.get('status') == 'success' if api._connection_status else False
            }
        })
    
    elif request.method == 'POST':
        try:
            data = request.get_json()
            if not data:
                return jsonify({
                    'status': 'error',
                    'message': 'Dados não fornecidos'
                }), 400
            
            # Validar dados
            host = data.get('host', 'localhost').strip()
            port = int(data.get('port', 9191))
            ssl = data.get('ssl', False)
            auth_token = data.get('auth_token', '').strip()
            
            if not host:
                return jsonify({
                    'status': 'error',
                    'message': 'Host é obrigatório'
                }), 400
            
            if not (1 <= port <= 65535):
                return jsonify({
                    'status': 'error',
                    'message': 'Porta deve estar entre 1 e 65535'
                }), 400
            
            # Construir nova URL
            from config import Config
            new_url = Config.build_papercut_url(host, port, ssl)
            
            # Atualizar configuração do API
            api.server_url = new_url
            if auth_token:
                api.auth_token = auth_token
            
            # Limpar conexão anterior
            api._proxy = None
            api._connection_status = None
            api._last_connection_test = None
            
            # Testar nova conexão
            connection_result = api.test_connection(force=True)
            
            return jsonify({
                'status': 'success',
                'message': 'Configuração atualizada com sucesso',
                'data': {
                    'server_url': new_url,
                    'connection_test': connection_result
                }
            })
            
        except ValueError as e:
            return jsonify({
                'status': 'error',
                'message': 'Porta deve ser um número válido'
            }), 400
        except Exception as e:
            logger.error(f"Erro ao configurar conexão: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500

@bp.route('/api/accounts', methods=['GET'])
@login_required
def get_accounts():
    """Endpoint para listar contas compartilhadas organizadas"""
    try:
        accounts_data = api.get_structured_accounts()
        
        # Organizar dados para o frontend incluindo cotas mensais
        departments = []
        db = get_db_session()
        try:
            for dept_name, dept_data in accounts_data['departments'].items():
                # Buscar configuração de cota mensal
                dept_config = db.query(Department).filter_by(name=dept_name).first()
                
                departments.append({
                    'name': dept_name,
                    'color_account': dept_data.get('color_account', f"{dept_name}\\Color"),
                    'mono_account': dept_data.get('mono_account', f"{dept_name}\\Mono"),
                    'color_balance': float(dept_data.get('color_balance', 0)),
                    'mono_balance': float(dept_data.get('mono_balance', 0)),
                    'total_balance': float(dept_data.get('color_balance', 0)) + float(dept_data.get('mono_balance', 0)),
                    'monthly_color_quota': float(dept_config.monthly_color_quota) if dept_config else 0,
                    'monthly_mono_quota': float(dept_config.monthly_mono_quota) if dept_config else 0,
                    'last_quota_applied': dept_config.last_quota_applied.isoformat() if dept_config and dept_config.last_quota_applied else None
                })
        finally:
            db.close()
        
        return jsonify({
            'status': 'success',
            'data': {
                'departments': departments,
                'other_accounts': accounts_data.get('other_accounts', [])
            }
        })
    except Exception as e:
        logger.error(f"Erro ao obter contas: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/departments/<department>/quotas', methods=['POST'])
@login_required
def set_department_quotas(department):
    """Define cotas atuais e mensais para um departamento"""
    try:
        data = request.get_json()
        if not data or 'color' not in data or 'mono' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Dados inválidos. Forneça quotas de color e mono.'
            }), 400
        
        try:
            color = float(data['color'])
            mono = float(data['mono'])
            monthly_color = float(data.get('monthly_color', 0))
            monthly_mono = float(data.get('monthly_mono', 0))
        except (ValueError, TypeError):
            return jsonify({
                'status': 'error',
                'message': 'Valores devem ser números válidos'
            }), 400
        
        if color < 0 or mono < 0 or monthly_color < 0 or monthly_mono < 0:
            return jsonify({
                'status': 'error',
                'message': 'As cotas não podem ser negativas'
            }), 400
        
        # Atualizar saldos nas chaves script.user-defined (sistema híbrido)
        result = api.set_department_script_quotas(department, color, mono)
        
        if result['success']:
            # Salvar/atualizar configuração de cota mensal no banco
            db = get_db_session()
            try:
                dept_config = db.query(Department).filter_by(name=department).first()
                if dept_config:
                    dept_config.monthly_color_quota = monthly_color
                    dept_config.monthly_mono_quota = monthly_mono
                    dept_config.updated_at = datetime.utcnow()
                else:
                    dept_config = Department(
                        name=department,
                        monthly_color_quota=monthly_color,
                        monthly_mono_quota=monthly_mono
                    )
                    db.add(dept_config)
                
                db.commit()
                
                return jsonify({
                    'status': 'success',
                    'message': f'Cotas atualizadas para {department}',
                    'data': {
                        **result,
                        'monthly_config_saved': True,
                        'monthly_color_quota': monthly_color,
                        'monthly_mono_quota': monthly_mono
                    }
                })
            finally:
                db.close()
        else:
            return jsonify({
                'status': 'error',
                'message': result.get('error', 'Falha ao atualizar cotas'),
                'data': result
            }), 500
            
    except Exception as e:
        logger.error(f"Erro ao definir cotas: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/users/<username>/department', methods=['GET', 'PUT'])
@login_required
def user_department(username):
    """Gerencia o departamento de um usuário"""
    try:
        if request.method == 'GET':
            department = api.get_user_department(username)
            if department is None:
                return jsonify({
                    'status': 'error',
                    'message': 'Usuário não encontrado ou sem departamento'
                }), 404
            
            return jsonify({
                'status': 'success',
                'data': {
                    'username': username,
                    'department': department
                }
            })
            
        elif request.method == 'PUT':
            data = request.get_json()
            if not data or 'department' not in data:
                return jsonify({
                    'status': 'error',
                    'message': 'Departamento não fornecido'
                }), 400
                
            success = api.set_user_department(username, data['department'])
            if success:
                return jsonify({
                    'status': 'success',
                    'message': f'Departamento do usuário {username} atualizado'
                })
            else:
                return jsonify({
                    'status': 'error',
                    'message': 'Falha ao atualizar departamento'
                }), 500
                
    except Exception as e:
        logger.error(f"Erro ao gerenciar departamento do usuário: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/monthly-quotas', methods=['GET'])
@login_required
def get_monthly_quotas():
    """Lista todas as configurações de cotas mensais"""
    try:
        db = get_db_session()
        try:
            departments = db.query(Department).filter_by(is_active=True).all()
            
            quotas = []
            for dept in departments:
                quotas.append({
                    'name': dept.name,
                    'monthly_color_quota': float(dept.monthly_color_quota),
                    'monthly_mono_quota': float(dept.monthly_mono_quota),
                    'last_quota_applied': dept.last_quota_applied.isoformat() if dept.last_quota_applied else None,
                    'created_at': dept.created_at.isoformat(),
                    'updated_at': dept.updated_at.isoformat()
                })
            
            return jsonify({
                'status': 'success',
                'data': quotas
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao buscar cotas mensais: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/apply-monthly-quotas', methods=['POST'])
@login_required
def apply_monthly_quotas():
    """Aplica manualmente as cotas mensais para todos os departamentos"""
    try:
        force = request.args.get('force', 'false').lower() == 'true'
        current_month = datetime.now().strftime('%Y-%m')
        
        db = get_db_session()
        results = []
        
        try:
            departments = db.query(Department).filter_by(is_active=True).all()
            
            for dept in departments:
                # Verificar se já foi aplicado este mês (a menos que force=true)
                if not force and dept.last_quota_applied:
                    last_month = dept.last_quota_applied.strftime('%Y-%m')
                    if last_month == current_month:
                        results.append({
                            'department': dept.name,
                            'status': 'skipped',
                            'message': 'Já aplicado este mês'
                        })
                        continue
                
                # Aplicar cota se configurada
                if dept.monthly_color_quota > 0 or dept.monthly_mono_quota > 0:
                    try:
                        # Obter saldos atuais
                        current_data = api.get_structured_accounts()
                        current_dept = current_data['departments'].get(dept.name, {})
                        
                        current_color = float(current_dept.get('color_balance', 0))
                        current_mono = float(current_dept.get('mono_balance', 0))
                        
                        # Adicionar cota mensal
                        new_color = current_color + dept.monthly_color_quota
                        new_mono = current_mono + dept.monthly_mono_quota
                        
                        # Aplicar no PaperCut usando chaves script
                        api_result = api.set_department_script_quotas(dept.name, new_color, new_mono)
                        
                        if api_result['success']:
                            # Atualizar data de aplicação
                            dept.last_quota_applied = datetime.utcnow()
                            
                            # Registrar no histórico
                            history = QuotaHistory(
                                department_name=dept.name,
                                color_quota_applied=dept.monthly_color_quota,
                                mono_quota_applied=dept.monthly_mono_quota,
                                applied_month=current_month,
                                success=True
                            )
                            db.add(history)
                            
                            results.append({
                                'department': dept.name,
                                'status': 'success',
                                'message': f'Adicionado: {dept.monthly_color_quota} color, {dept.monthly_mono_quota} mono',
                                'data': {
                                    'previous_color': current_color,
                                    'previous_mono': current_mono,
                                    'new_color': new_color,
                                    'new_mono': new_mono
                                }
                            })
                        else:
                            # Registrar erro no histórico
                            history = QuotaHistory(
                                department_name=dept.name,
                                color_quota_applied=dept.monthly_color_quota,
                                mono_quota_applied=dept.monthly_mono_quota,
                                applied_month=current_month,
                                success=False,
                                error_message=api_result.get('error', 'Erro desconhecido')
                            )
                            db.add(history)
                            
                            results.append({
                                'department': dept.name,
                                'status': 'error',
                                'message': f'Erro: {api_result.get("error", "Falha na aplicação")}'
                            })
                    
                    except Exception as dept_error:
                        logger.error(f"Erro ao aplicar cota para {dept.name}: {dept_error}")
                        results.append({
                            'department': dept.name,
                            'status': 'error',
                            'message': f'Erro: {str(dept_error)}'
                        })
                else:
                    results.append({
                        'department': dept.name,
                        'status': 'skipped',
                        'message': 'Nenhuma cota mensal configurada'
                    })
            
            db.commit()
            
            success_count = len([r for r in results if r['status'] == 'success'])
            error_count = len([r for r in results if r['status'] == 'error'])
            
            return jsonify({
                'status': 'success',
                'message': f'Processamento concluído: {success_count} sucessos, {error_count} erros',
                'data': {
                    'results': results,
                    'summary': {
                        'total': len(results),
                        'success': success_count,
                        'errors': error_count,
                        'skipped': len(results) - success_count - error_count
                    }
                }
            })
        
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao aplicar cotas mensais: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/quota-history', methods=['GET'])
@login_required
def get_quota_history():
    """Lista o histórico de aplicações de cotas mensais"""
    try:
        limit = int(request.args.get('limit', 50))
        department = request.args.get('department', None)
        
        db = get_db_session()
        try:
            query = db.query(QuotaHistory)
            
            if department:
                query = query.filter_by(department_name=department)
            
            history = query.order_by(QuotaHistory.applied_at.desc()).limit(limit).all()
            
            result = []
            for entry in history:
                result.append({
                    'id': entry.id,
                    'department_name': entry.department_name,
                    'color_quota_applied': float(entry.color_quota_applied),
                    'mono_quota_applied': float(entry.mono_quota_applied),
                    'applied_at': entry.applied_at.isoformat(),
                    'applied_month': entry.applied_month,
                    'success': entry.success,
                    'error_message': entry.error_message
                })
            
            return jsonify({
                'status': 'success',
                'data': result
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao buscar histórico: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/print-authorization', methods=['POST'])
@login_required
def check_print_authorization():
    """Endpoint para verificar autorização de impressão e debitar automaticamente"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'authorized': False,
                'reason': 'dados_invalidos',
                'message': 'Dados não fornecidos'
            }), 400
        
        # Validar dados obrigatórios
        department = data.get('department', '').strip()
        color_pages = int(data.get('color_pages', 0))
        mono_pages = int(data.get('mono_pages', 0))
        
        if not department:
            return jsonify({
                'authorized': False,
                'reason': 'dados_invalidos',
                'message': 'Departamento é obrigatório'
            }), 400
        
        if color_pages < 0 or mono_pages < 0:
            return jsonify({
                'authorized': False,
                'reason': 'dados_invalidos', 
                'message': 'Número de páginas não pode ser negativo'
            }), 400
        
        if color_pages == 0 and mono_pages == 0:
            return jsonify({
                'authorized': True,
                'reason': 'sem_custo',
                'message': 'Nenhuma página para imprimir'
            })
        
        # Verificar autorização via API
        authorization = api.check_print_authorization(department, color_pages, mono_pages)
        
        # Preparar resposta
        response_data = {
            'authorized': authorization['authorized'],
            'reason': authorization['reason'],
            'department': department,
            'color_pages': color_pages,
            'mono_pages': mono_pages
        }
        
        # Adicionar detalhes se disponíveis
        if 'details' in authorization:
            response_data.update(authorization['details'])
        
        if 'error' in authorization:
            response_data['error'] = authorization['error']
        
        # Log da operação
        if authorization['authorized']:
            logger.info(f"Impressão autorizada para {department}: {color_pages} color, {mono_pages} mono")
        else:
            logger.warning(f"Impressão negada para {department}: {authorization['reason']}")
        
        status_code = 200 if authorization['authorized'] else 402  # 402 Payment Required
        return jsonify(response_data), status_code
        
    except ValueError as e:
        return jsonify({
            'authorized': False,
            'reason': 'dados_invalidos',
            'message': 'Valores devem ser números válidos'
        }), 400
    except Exception as e:
        logger.error(f"Erro ao verificar autorização de impressão: {e}")
        return jsonify({
            'authorized': False,
            'reason': 'erro_sistema',
            'message': str(e)
        }), 500

@bp.route('/api/sync-script-balances', methods=['POST'])
@login_required
def sync_script_balances():
    """Endpoint para sincronizar saldos do PaperCut com properties do script"""
    try:
        # Buscar todas as contas estruturadas
        accounts_data = api.get_structured_accounts()
        
        results = []
        
        for dept_name, dept_data in accounts_data['departments'].items():
            color_account = f"{dept_name}\\Color"
            mono_account = f"{dept_name}\\Mono"
            color_balance = float(dept_data.get('color_balance', 0))
            mono_balance = float(dept_data.get('mono_balance', 0))
            
            try:
                # Informações para sincronização manual
                results.append({
                    'department': dept_name,
                    'color_account': color_account,
                    'mono_account': mono_account, 
                    'color_balance': color_balance,
                    'mono_balance': mono_balance,
                    'status': 'ready_for_sync',
                    'message': f'Saldos disponíveis: Color R$ {color_balance:.2f}, Mono R$ {mono_balance:.2f}'
                })
                
            except Exception as sync_error:
                results.append({
                    'department': dept_name,
                    'status': 'error',
                    'message': str(sync_error)
                })
        
        return jsonify({
            'status': 'success',
            'message': f'Saldos obtidos para {len(results)} departamentos',
            'data': {
                'departments': results,
                'instructions': [
                    'Use o script corrigido que tenta múltiplos métodos para obter saldos',
                    'Script agora permite impressões mesmo se não encontrar saldos',
                    'Monitore logs do PaperCut para verificar funcionamento'
                ]
            }
        })
        
    except Exception as e:
        logger.error(f"Erro ao sincronizar saldos: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

# ========== ROTAS PARA CHAVES SCRIPT.USER-DEFINED ==========

@bp.route('/api/script-accounts', methods=['GET'])
@login_required
def get_script_accounts():
    """Endpoint para listar saldos das chaves script.user-defined organizadas"""
    try:
        # Buscar dados dos departamentos cadastrados no banco
        db = get_db_session()
        try:
            departments_config = db.query(Department).all()
            
            departments = []
            for dept_config in departments_config:
                # Obter saldos das chaves script
                script_data = api.get_department_script_balances(dept_config.name)
                
                departments.append({
                    'name': dept_config.name,
                    'color_key': script_data.get('color_key'),
                    'mono_key': script_data.get('mono_key'),
                    'color_balance': float(script_data.get('color_balance', 0)),
                    'mono_balance': float(script_data.get('mono_balance', 0)),
                    'total_balance': float(script_data.get('color_balance', 0)) + float(script_data.get('mono_balance', 0)),
                    'monthly_color_quota': float(dept_config.monthly_color_quota),
                    'monthly_mono_quota': float(dept_config.monthly_mono_quota),
                    'last_quota_applied': dept_config.last_quota_applied.isoformat() if dept_config.last_quota_applied else None,
                    'source': 'script.user-defined'
                })
        finally:
            db.close()
        
        return jsonify({
            'status': 'success',
            'data': {
                'departments': departments,
                'source': 'script.user-defined'
            }
        })
    except Exception as e:
        logger.error(f"Erro ao obter contas script: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/script-departments/<department>/quotas', methods=['POST'])
@login_required
def set_script_department_quotas(department):
    """Define cotas atuais e mensais para um departamento usando chaves script.user-defined"""
    try:
        data = request.get_json()
        if not data or 'color' not in data or 'mono' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Dados inválidos. Forneça quotas de color e mono.'
            }), 400
        
        try:
            color = float(data['color'])
            mono = float(data['mono'])
            monthly_color = float(data.get('monthly_color', 0))
            monthly_mono = float(data.get('monthly_mono', 0))
        except (ValueError, TypeError):
            return jsonify({
                'status': 'error',
                'message': 'Valores devem ser números válidos'
            }), 400
        
        if color < 0 or mono < 0 or monthly_color < 0 or monthly_mono < 0:
            return jsonify({
                'status': 'error',
                'message': 'As cotas não podem ser negativas'
            }), 400
        
        # Atualizar saldos nas chaves script.user-defined
        result = api.set_department_script_quotas(department, color, mono)
        
        if result['success']:
            # Salvar/atualizar configuração de cota mensal no banco
            db = get_db_session()
            try:
                dept_config = db.query(Department).filter_by(name=department).first()
                if dept_config:
                    dept_config.monthly_color_quota = monthly_color
                    dept_config.monthly_mono_quota = monthly_mono
                    dept_config.updated_at = datetime.utcnow()
                else:
                    dept_config = Department(
                        name=department,
                        monthly_color_quota=monthly_color,
                        monthly_mono_quota=monthly_mono
                    )
                    db.add(dept_config)
                
                db.commit()
                
                return jsonify({
                    'status': 'success',
                    'message': f'Cotas script atualizadas para {department}',
                    'data': {
                        **result,
                        'monthly_config_saved': True,
                        'monthly_color_quota': monthly_color,
                        'monthly_mono_quota': monthly_mono,
                        'source': 'script.user-defined'
                    }
                })
            finally:
                db.close()
        else:
            return jsonify({
                'status': 'error',
                'message': result.get('error', 'Falha ao atualizar cotas script'),
                'data': result
            }), 500
            
    except Exception as e:
        logger.error(f"Erro ao definir cotas script: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/script-departments/<department>/add-value', methods=['POST'])
@login_required
def add_script_department_value(department):
    """Adiciona valor às chaves script.user-defined de um departamento"""
    try:
        data = request.get_json()
        if not data or ('color' not in data and 'mono' not in data):
            return jsonify({
                'status': 'error',
                'message': 'Forneça pelo menos um valor para color ou mono'
            }), 400
        
        try:
            color_add = float(data.get('color', 0))
            mono_add = float(data.get('mono', 0))
        except (ValueError, TypeError):
            return jsonify({
                'status': 'error',
                'message': 'Valores devem ser números válidos'
            }), 400
        
        if color_add < 0 or mono_add < 0:
            return jsonify({
                'status': 'error',
                'message': 'Valores adicionados não podem ser negativos'
            }), 400
        
        results = []
        all_success = True
        
        # Adicionar valor color se especificado
        if color_add > 0:
            color_key = f"{department}\\color"
            color_result = api.adjust_script_property_balance(
                color_key, 
                color_add, 
                f"Adição manual via web: R$ {color_add}"
            )
            results.append({
                'type': 'color',
                'key': f"script.user-defined.{color_key}",
                'added': color_add,
                'success': color_result['success'],
                'new_balance': color_result.get('new_value', 0)
            })
            if not color_result['success']:
                all_success = False
        
        # Adicionar valor mono se especificado
        if mono_add > 0:
            mono_key = f"{department}\\mono"
            mono_result = api.adjust_script_property_balance(
                mono_key, 
                mono_add, 
                f"Adição manual via web: R$ {mono_add}"
            )
            results.append({
                'type': 'mono',
                'key': f"script.user-defined.{mono_key}",
                'added': mono_add,
                'success': mono_result['success'],
                'new_balance': mono_result.get('new_value', 0)
            })
            if not mono_result['success']:
                all_success = False
        
        if all_success:
            return jsonify({
                'status': 'success',
                'message': f'Valores adicionados com sucesso para {department}',
                'data': {
                    'department': department,
                    'results': results,
                    'source': 'script.user-defined'
                }
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Falha ao adicionar alguns valores',
                'data': {
                    'department': department,
                    'results': results
                }
            }), 500
            
    except Exception as e:
        logger.error(f"Erro ao adicionar valor script: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/script-quotas/apply-monthly', methods=['POST'])
@login_required
def apply_monthly_script_quotas():
    """Aplica cotas mensais manualmente para todos os departamentos usando chaves script.user-defined"""
    try:
        # Importar aqui para evitar circular import
        from monthly_quota_scheduler import MonthlyQuotaScheduler
        
        scheduler = MonthlyQuotaScheduler()
        result = scheduler.apply_monthly_quotas()
        
        if result['status'] == 'success':
            return jsonify({
                'status': 'success',
                'message': f'Cotas mensais aplicadas: {result["success"]} sucessos, {result["errors"]} erros',
                'data': {
                    **result,
                    'source': 'script.user-defined'
                }
            })
        else:
            return jsonify({
                'status': 'error',
                'message': result.get('message', 'Erro desconhecido'),
                'data': result
            }), 500
            
    except Exception as e:
        logger.error(f"Erro ao aplicar cotas mensais script: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@bp.route('/api/accounts-hybrid')
@login_required
def get_hybrid_accounts():
    """Retorna contas compartilhadas com valores das chaves script.user-defined"""
    try:
        
        # Obter estrutura de contas compartilhadas tradicionais
        structured_accounts = api.get_structured_accounts()
        departments = []
        
        # Para cada departamento, buscar valores das chaves script
        for dept_name, dept_info in structured_accounts['departments'].items():
            # Buscar valores das chaves script.user-defined
            color_script_balance = api.get_script_property(f"{dept_name}\\color")
            mono_script_balance = api.get_script_property(f"{dept_name}\\mono")
            
            # Buscar configuração mensal do banco de dados
            db_session = get_db_session()
            try:
                dept_config = db_session.query(Department).filter_by(name=dept_name).first()
                monthly_color_quota = dept_config.monthly_color_quota if dept_config else 0
                monthly_mono_quota = dept_config.monthly_mono_quota if dept_config else 0
            finally:
                db_session.close()
            
            departments.append({
                'name': dept_name,
                'color_account': dept_info['color_account'],  # Nome da conta tradicional
                'mono_account': dept_info['mono_account'],    # Nome da conta tradicional
                'color_balance': color_script_balance,       # Valor da chave script
                'mono_balance': mono_script_balance,         # Valor da chave script
                'total_balance': color_script_balance + mono_script_balance,
                'monthly_color_quota': monthly_color_quota,
                'monthly_mono_quota': monthly_mono_quota
            })
        
        return jsonify({
            'status': 'success',
            'data': {
                'departments': departments,
                'total_departments': len(departments),
                'source': 'hybrid'
            }
        })
        
    except Exception as e:
        logger.error(f"Erro ao obter contas híbridas: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


