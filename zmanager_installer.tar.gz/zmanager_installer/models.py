"""
Modelos de banco de dados para o PaperCut Manager
"""

import os
from datetime import datetime, timezone, timedelta
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from flask_login import UserMixin

Base = declarative_base()

def get_current_time():
    """Retorna o datetime atual"""
    return datetime.now()

class User(UserMixin, Base):
    """Modelo para usuários do sistema"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    requires_password_change = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<User(username='{self.username}', email='{self.email}')>"

class Department(Base):
    __tablename__ = 'departments'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)
    monthly_color_quota = Column(Float, default=0)
    monthly_mono_quota = Column(Float, default=0)
    
    # NOVOS CAMPOS PARA CACHE
    cached_color_balance = Column(Float, default=0)
    cached_mono_balance = Column(Float, default=0)
    cache_updated_at = Column(DateTime, default=datetime.utcnow)
    cache_ttl_minutes = Column(Integer, default=5)  # 5 minutos de cache
    
    last_quota_applied = Column(DateTime)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Department(name='{self.name}', monthly_color={self.monthly_color_quota}, monthly_mono={self.monthly_mono_quota})>"

class QuotaHistory(Base):
    """Histórico de aplicação de cotas mensais"""
    __tablename__ = 'quota_history'
    
    id = Column(Integer, primary_key=True)
    department_name = Column(String(100), nullable=False)
    
    # Valores aplicados
    color_quota_applied = Column(Float, default=0.0)
    mono_quota_applied = Column(Float, default=0.0)
    
    # Saldos antes e depois da aplicação
    previous_color_balance = Column(Float, default=0.0)
    previous_mono_balance = Column(Float, default=0.0)
    final_color_balance = Column(Float, default=0.0)
    final_mono_balance = Column(Float, default=0.0)
    
    # Data de aplicação
    applied_at = Column(DateTime, default=datetime.utcnow)
    applied_month = Column(String(7), nullable=False)  # YYYY-MM format
    
    # Status
    success = Column(Boolean, default=True)
    error_message = Column(String(500), nullable=True)
    
    def __repr__(self):
        return f"<QuotaHistory(department='{self.department_name}', month='{self.applied_month}', success={self.success})>"

# Configuração do banco de dados
DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///papercut_manager.db')

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_tables():
    """Cria as tabelas no banco de dados"""
    Base.metadata.create_all(bind=engine)
    
    # Criar usuário admin padrão se não existir
    db = SessionLocal()
    try:
        from werkzeug.security import generate_password_hash
        
        admin_user = db.query(User).filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@zorteck.com.br',
                password_hash=generate_password_hash('Admin@SJP25'),
                is_admin=True
            )
            db.add(admin_user)
            db.commit()
            print("Usuário admin criado: admin / Admin@SJP25")
    except Exception as e:
        print(f"Erro ao criar usuário admin: {e}")
        db.rollback()
    finally:
        db.close()

def get_db_session():
    """Retorna uma sessão do banco de dados"""
    db = SessionLocal()
    try:
        return db
    finally:
        pass # Não fecha automaticamente, deve ser fechado manualmente