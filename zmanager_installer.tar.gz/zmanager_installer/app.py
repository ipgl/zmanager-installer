"""
Aplicação Flask principal para o PaperCut Manager
"""

from datetime import datetime
import os
import logging
import time
import json
import requests
from functools import wraps, lru_cache
from flask import Flask, render_template, redirect, url_for, request, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from routes import bp as papercut_bp
from auth_routes import auth_bp
from admin_routes import admin_bp
from config import Config
from models import User, get_db_session
import threading
from monthly_quota_scheduler import MonthlyQuotaScheduler

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ.get("SESSION_SECRET") or "dev-secret-key-change-in-production"
    app.config.from_object(Config)
    
    # Setup Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'info'
    
    @login_manager.user_loader
    def load_user(user_id):
        db = get_db_session()
        try:
            return db.query(User).get(int(user_id))
        except:
            return None
        finally:
            db.close()
    
    # Inicializar e iniciar o scheduler de cotas mensais
    app.scheduler = MonthlyQuotaScheduler()
    app.scheduler_thread = None
    app._scheduler_started = False
    
    def start_scheduler():
        """Inicia o scheduler em background"""
        try:
            # Verificar conexão com PaperCut primeiro
            connection_test = app.scheduler.api.test_connection(force=True)
            if connection_test['status'] == 'success':
                app.logger.info("Iniciando scheduler de cotas mensais...")
                app.scheduler_thread = app.scheduler.start()
                app._scheduler_started = True
            else:
                app.logger.warning(f"Adiando início do scheduler - Conexão PaperCut não disponível: {connection_test['message']}")
                # Tentar novamente após 1 minuto
                threading.Timer(60.0, start_scheduler).start()
        except Exception as e:
            app.logger.error(f"Erro ao iniciar scheduler: {e}")
            # Tentar novamente após 2 minutos em caso de erro
            threading.Timer(120.0, start_scheduler).start()
    
    # Usar @app.before_request para verificar se é o primeiro request
    @app.before_request
    def initialize_scheduler_on_first_request():
        """Inicia o scheduler no primeiro request"""
        if not app._scheduler_started and not app.scheduler.is_running():
            app.logger.info("Primeiro request detectado - iniciando scheduler...")
            start_scheduler()

    # Register blueprints
    app.register_blueprint(papercut_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp) 
    
    @app.route('/')
    @login_required
    def index():
        return render_template('accounts.html')
    
    # Adicionar rotas de API para o scheduler
    @app.route('/api/scheduler/status')
    @login_required
    def api_scheduler_status():
        """Retorna status do scheduler"""
        return jsonify({
            'running': app.scheduler.is_running(),
            'thread_alive': app.scheduler.thread.is_alive() if hasattr(app.scheduler, 'thread') and app.scheduler.thread else False,
            'started': app._scheduler_started
        })
    
    @app.route('/api/scheduler/start', methods=['POST'])
    @login_required
    def api_scheduler_start():
        """Inicia o scheduler manualmente"""
        if app.scheduler.is_running():
            return jsonify({'status': 'already_running'})
        
        app.scheduler_thread = app.scheduler.start()
        app._scheduler_started = True
        return jsonify({'status': 'started'})
    
    @app.route('/api/scheduler/stop', methods=['POST'])
    @login_required
    def api_scheduler_stop():
        """Para o scheduler manualmente"""
        app.scheduler.stop()
        return jsonify({'status': 'stopped'})
    
    @app.route('/api/scheduler/apply-now', methods=['POST'])
    @login_required
    def api_scheduler_apply_now():
        """Aplica cotas manualmente (para testes)"""
        result = app.scheduler.apply_monthly_quotas()
        return jsonify(result)

        
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal error: {error}")
        return render_template('500.html'), 500
    

    return app

app = create_app()

if __name__ == '__main__':
    logger.info("Iniciando Z Manager...")
    logger.info(f"Servidor rodando em: http://0.0.0.0:9090")
    
    # Iniciar scheduler também quando executado diretamente
    if not app.scheduler.is_running():
        try:
            app.scheduler_thread = app.scheduler.start()
            app._scheduler_started = True
        except Exception as e:
            logger.error(f"Erro ao iniciar scheduler: {e}")
    
    app.run(host='0.0.0.0', port=9090, debug=True)