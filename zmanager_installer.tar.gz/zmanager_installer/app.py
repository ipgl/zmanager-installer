"""
Aplicação Flask principal para o PaperCut Manager
"""

from datetime import datetime, time as dt_time
import schedule
import os
import logging
import time
import json
import requests
from functools import wraps, lru_cache
from flask import Flask, render_template, redirect, url_for, request, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from routes import bp as papercut_bp
from auth_routes import auth_bp
from admin_routes import admin_bp
from config import Config
from models import User, get_db_session
import threading
from monthly_quota_scheduler import MonthlyQuotaScheduler

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Nome do software para verificação de contrato
softwareName = 'Z Manager'

def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ.get("SESSION_SECRET") or "dev-secret-key-change-in-production"
    app.config.from_object(Config)
    
    # Setup Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'info'
    
    @login_manager.user_loader
    def load_user(user_id):
        db = get_db_session()
        try:
            return db.query(User).get(int(user_id))
        except:
            return None
        finally:
            db.close()
    
    # Configurações de contrato
    client_name = app.config.get('CLIENT_NAME')
    
    contract_headers = {
        'X-Parse-Application-Id': app.config.get('BACK4APP_APP_ID_CONT', ''),
        'X-Parse-REST-API-Key': app.config.get('BACK4APP_REST_KEY_CONT', ''),
        'Content-Type': 'application/json'
    }

    # Variável para controle do scheduler diário
    app.daily_scheduler_running = False
    app.daily_scheduler_thread = None

    # Inicializar e iniciar o scheduler de cotas mensais
    app.scheduler = MonthlyQuotaScheduler()
    app.scheduler_thread = None
    app._scheduler_started = False
    
    def start_scheduler():
        """Inicia o scheduler em background"""
        try:
            # Verificar conexão com PaperCut primeiro
            connection_test = app.scheduler.api.test_connection(force=True)
            if connection_test['status'] == 'success':
                app.logger.info("Iniciando scheduler de cotas mensais...")
                app.scheduler_thread = app.scheduler.start()
                app._scheduler_started = True
            else:
                app.logger.warning(f"Adiando início do scheduler - Conexão PaperCut não disponível: {connection_test['message']}")
                # Tentar novamente após 1 minuto
                threading.Timer(60.0, start_scheduler).start()
        except Exception as e:
            app.logger.error(f"Erro ao iniciar scheduler: {e}")
            # Tentar novamente após 2 minutos em caso de erro
            threading.Timer(120.0, start_scheduler).start()
    
    def daily_contract_check():
        """Verificação diária do contrato às 00:01"""
        try:
            app.logger.info("Executando verificação diária do contrato...")
            
            # Limpar cache da verificação de contrato
            if hasattr(app, 'check_contract_active_cached'):
                app.check_contract_active_cached.cache_clear()
            
            # Forçar nova verificação
            is_active = check_contract_active()
            app.contract_last_check = time.time()
            app.contract_active_status = is_active
            
            app.logger.info(f"Verificação diária do contrato concluída. Status: {'ATIVO' if is_active else 'INATIVO'}")
            
        except Exception as e:
            app.logger.error(f"Erro na verificação diária do contrato: {e}")

    def start_daily_scheduler():
        """Inicia o scheduler para verificação diária às 00:01"""
        if app.daily_scheduler_running:
            return
            
        def scheduler_loop():
            # Agendar verificação diária às 00:01
            schedule.every().day.at("00:01").do(daily_contract_check)
            
            app.logger.info("Scheduler diário do contrato iniciado - verificações às 00:01")
            app.daily_scheduler_running = True
            
            while app.daily_scheduler_running:
                try:
                    schedule.run_pending()
                    time.sleep(60)  # Verificar a cada minuto
                except Exception as e:
                    app.logger.error(f"Erro no scheduler diário: {e}")
                    time.sleep(300)  # Esperar 5 minutos em caso de erro
        
        # Iniciar thread do scheduler diário
        app.daily_scheduler_thread = threading.Thread(target=scheduler_loop, daemon=True)
        app.daily_scheduler_thread.start()

    def stop_daily_scheduler():
        """Para o scheduler diário"""
        app.daily_scheduler_running = False
        if app.daily_scheduler_thread and app.daily_scheduler_thread.is_alive():
            app.daily_scheduler_thread.join(timeout=5)
    
    # Usar @app.before_request para verificar se é o primeiro request
    @app.before_request
    def initialize_schedulers_on_first_request():
        """Inicia os schedulers no primeiro request"""
        # Scheduler de cotas mensais (existente)
        if not app._scheduler_started and not app.scheduler.is_running():
            app.logger.info("Primeiro request detectado - iniciando scheduler de cotas...")
            start_scheduler()
        
        # Scheduler diário do contrato (novo)
        if not app.daily_scheduler_running:
            app.logger.info("Iniciando scheduler diário do contrato...")
            start_daily_scheduler()

    def check_contract_active():
        """Verifica se o contrato está ativo"""
        try:
            api_url = app.config.get('BACK4APP_API_URL_CONT', 'https://parseapi.back4app.com')
            url = f"{api_url}/classes/Client"
            params = {
                'where': json.dumps({
                    'softwareName': softwareName,
                    'clientName': client_name
                })
            }
            
            response = requests.get(url, headers=contract_headers, params=params, timeout=10)
            
            if response.status_code == 200:
                results = response.json().get('results', [])
                if results:
                    return results[0].get('contractActive', False)
            
            return False
            
        except Exception as e:
            app.logger.error(f"Erro ao verificar contrato: {str(e)}")
            return False

    def validate_contract_config():
        """Valida se todas as configurações necessárias estão presentes"""
        required_configs = [
            'BACK4APP_APP_ID_CONT',
            'BACK4APP_REST_KEY_CONT', 
            'BACK4APP_API_URL_CONT',
            'CLIENT_NAME'
        ]
        
        missing_configs = []
        for config in required_configs:
            if not app.config.get(config):
                missing_configs.append(config)
        
        if missing_configs:
            app.logger.error(f"Configurações de contrato ausentes: {missing_configs}")
            return False
        
        return True

    def contract_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Rotas que não precisam de verificação de contrato
            exempt_routes = ['static', 'contrato_expirado', 'auth.login', 'auth.register', 
                           'auth.logout', 'api_check_contract']
            if request.endpoint in exempt_routes:
                return f(*args, **kwargs)
                
            # Verificação rápida - se já temos cache, usa ele
            if hasattr(app, 'contract_last_check'):
                # Verifica a cada 5 minutos no backend (para não sobrecarregar)
                current_time = time.time()
                if current_time - app.contract_last_check < 300:  # 5 minutos
                    if not app.contract_active_status:
                        return render_template('contrato_expirado.html', 
                                            cliente_nome=client_name,
                                            softwareName=softwareName), 403
                    return f(*args, **kwargs)
            
            # Verificação completa
            if not validate_contract_config():
                return render_template('contrato_expirado.html', 
                                    cliente_nome="Erro de configuração",
                                    softwareName=softwareName), 403
                
            is_active = check_contract_active()
            app.contract_last_check = time.time()
            app.contract_active_status = is_active
            
            if not is_active:
                return render_template('contrato_expirado.html', 
                                    cliente_nome=client_name,
                                    softwareName=softwareName), 403
            
            return f(*args, **kwargs)
        return decorated_function

    @lru_cache(maxsize=1)
    def check_contract_active_cached():
        """Verifica se o contrato está ativo com cache de 1 hora"""
        return check_contract_active()

    @app.route('/contrato_expirado')
    def contrato_expirado():
        try:
            url = f"{app.config['BACK4APP_API_URL_CONT']}/classes/Client"
            params = {
                'where': json.dumps({'softwareName': softwareName}),
                'limit': 1
            }
            response = requests.get(url, headers=contract_headers, params=params, timeout=5)
            if response.status_code == 200:
                results = response.json().get('results', [])
                cliente_nome = client_name
            else:
                cliente_nome = 'Não configurado'
        except:
            cliente_nome = 'Não configurado'
            
        return render_template('contrato_expirado.html', 
                             cliente_nome=cliente_nome,
                             softwareName=softwareName)

    @app.route('/api/check_contract')
    def api_check_contract():
        """API para verificar o status do contrato"""
        if not validate_contract_config():
            return jsonify({'active': False, 'message': 'Erro de configuração'})
        
        is_active = check_contract_active()
        return jsonify({
            'active': is_active,
            'client_name': client_name,
            'software_name': softwareName
        })

    @app.route('/api/check_contract_session')
    @login_required
    def api_check_contract_session():
        """API para verificar contrato mantendo a sessão"""
        if not validate_contract_config():
            return jsonify({'active': False}), 403
        
        is_active = check_contract_active()
        if not is_active:
            logout_user()  # Desloga o usuário se contrato estiver inativo
        
        return jsonify({'active': is_active})
    
    # Aplicar decorador de contrato a todas as rotas principais
    app.before_request(lambda: None)  # Placeholder para aplicar o decorador
    

    # Register blueprints
    app.register_blueprint(papercut_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp) 
    
    @app.route('/')
    @login_required
    @contract_required
    def index():
        return render_template('accounts.html')
    
    # Adicionar rotas de API para o scheduler
    @app.route('/api/scheduler/status')
    @login_required
    def api_scheduler_status():
        """Retorna status do scheduler"""
        return jsonify({
            'running': app.scheduler.is_running(),
            'thread_alive': app.scheduler.thread.is_alive() if hasattr(app.scheduler, 'thread') and app.scheduler.thread else False,
            'started': app._scheduler_started
        })
    
    @app.route('/api/scheduler/start', methods=['POST'])
    @login_required
    def api_scheduler_start():
        """Inicia o scheduler manualmente"""
        if app.scheduler.is_running():
            return jsonify({'status': 'already_running'})
        
        app.scheduler_thread = app.scheduler.start()
        app._scheduler_started = True
        return jsonify({'status': 'started'})
    
    @app.route('/api/scheduler/stop', methods=['POST'])
    @login_required
    def api_scheduler_stop():
        """Para o scheduler manualmente"""
        app.scheduler.stop()
        return jsonify({'status': 'stopped'})
    
    @app.route('/api/scheduler/apply-now', methods=['POST'])
    @login_required
    def api_scheduler_apply_now():
        """Aplica cotas manualmente (para testes)"""
        result = app.scheduler.apply_monthly_quotas()
        return jsonify(result)
    
    @app.route('/api/daily_scheduler/status')
    @login_required
    def api_daily_scheduler_status():
        """Retorna status do scheduler diário"""
        return jsonify({
            'running': app.daily_scheduler_running,
            'thread_alive': app.daily_scheduler_thread.is_alive() if app.daily_scheduler_thread else False,
            'next_check': '00:01 (diário)'
        })

    # Garantir que o scheduler diário seja parado ao encerrar o app
    @app.teardown_appcontext
    def shutdown_daily_scheduler(exception=None):
        """Para o scheduler diário ao encerrar a aplicação"""
        stop_daily_scheduler()

    @app.errorhandler(404)
    def not_found(error):
        return render_template('404.html'), 404
        
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal error: {error}")
        return render_template('500.html'), 500
    

    return app

app = create_app()

if __name__ == '__main__':
    logger.info("Iniciando Z Manager...")
    logger.info(f"Servidor rodando em: http://0.0.0.0:9090")
    
    # Iniciar scheduler também quando executado diretamente
    if not app.scheduler.is_running():
        try:
            app.scheduler_thread = app.scheduler.start()
            app._scheduler_started = True
        except Exception as e:
            logger.error(f"Erro ao iniciar scheduler: {e}")
    
    app.run(host='0.0.0.0', port=9090, debug=True)