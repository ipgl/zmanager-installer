"""
Configurações da aplicação PaperCut Quota Manager Web
"""

import os

class Config:
    """Configurações base da aplicação"""
    
    # Configurações Flask
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'msvt#fox'
    
    # Configurações do PaperCut
    PAPERCUT_SERVER_URL = os.environ.get('PAPERCUT_SERVER_URL') or 'http://localhost:9191/rpc/api/xmlrpc'
    PAPERCUT_AUTH_TOKEN = os.environ.get('PAPERCUT_AUTH_TOKEN') or 'Impressao@25'
    
    # Configurações de contrato
    CLIENT_NAME = os.getenv('CLIENT_NAME')
    BACK4APP_APP_ID_CONT = os.getenv('BACK4APP_APP_ID_CONT', '')
    BACK4APP_REST_KEY_CONT = os.getenv('BACK4APP_REST_KEY_CONT', '')
    BACK4APP_API_URL_CONT = os.getenv('BACK4APP_API_URL_CONT', 'https://parseapi.back4app.com')
    
    # Configurações de desenvolvimento
    DEBUG = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    
    # Configurações de CORS
    CORS_ORIGINS = ['*']  # Em produção, especificar domínios específicos
    
    # Configurações de logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    
    @staticmethod
    def build_papercut_url(host='localhost', port=9191, ssl=False):
        """Constrói URL do PaperCut dinamicamente"""
        protocol = 'https' if ssl else 'http'
        return f'{protocol}://{host}:{port}/rpc/api/xmlrpc'
    
    @staticmethod
    def get_papercut_config():
        """Retorna configurações do PaperCut como dicionário"""
        return {
            'server_url': Config.PAPERCUT_SERVER_URL,
            'auth_token': Config.PAPERCUT_AUTH_TOKEN,
        }

class DevelopmentConfig(Config):
    """Configurações para ambiente de desenvolvimento"""
    DEBUG = False

class ProductionConfig(Config):
    """Configurações para ambiente de produção"""
    DEBUG = True
    # Em produção, sempre usar HTTPS se não especificado
    PAPERCUT_SERVER_URL = os.environ.get('PAPERCUT_SERVER_URL') or Config.build_papercut_url('papercut.empresa.com', 9192, ssl=True)

class TestingConfig(Config):
    """Configurações para testes"""
    TESTING = True

# Mapeamento de configurações por ambiente
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}