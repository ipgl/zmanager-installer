"""
PaperCut API Client otimizado para gerenciamento de contas compartilhadas
"""

import xmlrpc.client
import logging
from functools import lru_cache
from datetime import datetime, timedelta
import socket

logger = logging.getLogger(__name__)

class PaperCutAPI:
    def __init__(self, server_url, auth_token):
        self.server_url = server_url
        self.auth_token = auth_token
        self._proxy = None
        self._last_connection_test = None
        self._connection_status = None
        
    @property
    def proxy(self):
        """Lazy initialization of XML-RPC proxy"""
        if self._proxy is None:
            try:
                # Create proxy without timeout parameter (not supported in all Python versions)
                self._proxy = xmlrpc.client.ServerProxy(
                    self.server_url,
                    allow_none=True
                )
                logger.info(f"Conectado ao servidor PaperCut em {self.server_url}")
            except Exception as e:
                logger.error(f"Falha ao conectar ao PaperCut: {e}")
                raise
        return self._proxy
    
    def test_connection(self, force=False):
        """Testa a conexão com cache de 1 minuto"""
        now = datetime.now()
        if not force and self._last_connection_test and (now - self._last_connection_test) < timedelta(minutes=1):
            return self._connection_status
        
        try:
            # Parse URL to get host and port for socket test
            import urllib.parse
            parsed = urllib.parse.urlparse(self.server_url)
            host = parsed.hostname or 'localhost'
            port = parsed.port or 9191
            
            # Test socket connection first
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()
            
            if result != 0:
                raise Exception(f"Não foi possível conectar ao servidor {host}:{port}")
            
            # Test XML-RPC call with minimal compatibility test
            try:
                # Try a simple ping to see if XML-RPC is responding
                response = self.proxy.system.listMethods()
                if response and hasattr(response, '__len__') and len(response) > 0:
                    message = 'Conexão ativa com PaperCut - XML-RPC funcionando'
                else:
                    message = 'Conexão ativa com PaperCut (resposta básica)'
            except Exception as api_error:
                # Just verify that we can reach the XML-RPC endpoint
                try:
                    # Minimal test - just see if we get any response
                    str(self.proxy)
                    message = 'Conexão estabelecida com PaperCut (teste básico)'
                except:
                    raise Exception("Falha na comunicação XML-RPC com o servidor")
            
            status = {
                'status': 'success',
                'message': message,
                'server': self.server_url,
                'timestamp': now.isoformat()
            }
            self._connection_status = status
            logger.info("Teste de conexão bem-sucedido")
            
        except Exception as e:
            error_msg = str(e)
            if "timed out" in error_msg.lower():
                error_msg = "Timeout na conexão - verifique se o servidor está acessível"
            elif "connection refused" in error_msg.lower():
                error_msg = "Conexão recusada - verifique se o PaperCut está rodando"
            elif "request-sent" in error_msg.lower():
                error_msg = "Conexão interrompida durante requisição - verifique a estabilidade da rede"
            elif "fault" in error_msg.lower() and "java.lang" in error_msg.lower():
                error_msg = "Erro na API do PaperCut - método incompatível ou token inválido"
            
            status = {
                'status': 'error',
                'message': error_msg,
                'server': self.server_url,
                'timestamp': now.isoformat()
            }
            self._connection_status = status
            logger.error(f"Falha no teste de conexão: {error_msg}")
        
        self._last_connection_test = now
        return status
    
    def list_shared_accounts(self, include_subaccounts=True):
        """Lista contas compartilhadas com tratamento de erros detalhado"""
        try:
            logger.info("Iniciando listagem de contas compartilhadas...")
            
            # Teste a conexão primeiro
            conn_test = self.test_connection()
            if conn_test['status'] != 'success':
                raise Exception(f"Conexão falhou: {conn_test['message']}")
            
            logger.info("Obtendo contas compartilhadas...")
            accounts = self.proxy.api.listSharedAccounts(self.auth_token, 0, -1)
            
            if not isinstance(accounts, list):
                raise Exception(f"Resposta inesperada do servidor: {accounts}")
            
            logger.info(f"Encontradas {len(accounts)} contas")
            
            if not include_subaccounts:
                accounts = [acc for acc in accounts if '\\' not in acc]
                logger.info(f"Filtradas {len(accounts)} contas principais")
            
            return accounts
            
        except xmlrpc.client.Fault as err:
            error_msg = f"Erro XML-RPC (code {err.faultCode}): {err.faultString}"
            logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Erro ao listar contas: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)
    
    def get_shared_account_balance(self, account_name):
        """Obtém o saldo de uma conta compartilhada"""
        try:
            balance = self.proxy.api.getSharedAccountProperty(
                self.auth_token,
                account_name,
                "balance")
            
            if balance is None:
                return 0.0
            
            try:
                return float(str(balance))
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            logger.error(f"Erro ao obter saldo da conta {account_name}: {str(e)}")
            return 0.0

    def set_shared_account_balance(self, account_name, balance):
        """Define o saldo de uma conta compartilhada"""
        try:
            success = self.proxy.api.setSharedAccountProperty(
                self.auth_token,
                account_name,
                "balance",
                str(float(balance)))
            
            if success:
                logger.info(f"Saldo da conta {account_name} atualizado para {balance}")
            
            return success
        except Exception as e:
            logger.error(f"Erro ao definir saldo para {account_name}: {str(e)}")
            return False
    
    def add_new_shared_account(self, account_name):
        """Cria uma nova conta compartilhada"""
        try:
            success = self.proxy.api.addNewSharedAccount(
                self.auth_token,
                account_name)
            
            if success:
                logger.info(f"Conta compartilhada criada: {account_name}")
            
            return success
        except Exception as e:
            logger.error(f"Erro ao criar conta {account_name}: {str(e)}")
            return False

    def get_structured_accounts(self):
        """Retorna contas organizadas por departamento"""
        accounts = self.list_shared_accounts()
        structured = {'departments': {}, 'other_accounts': []}
        
        for account in accounts:
            if '\\' in account:
                dept, acc_type = account.split('\\', 1)
                if dept not in structured['departments']:
                    structured['departments'][dept] = {
                        'name': dept,
                        'color_account': f"{dept}\\Color",
                        'mono_account': f"{dept}\\Mono",
                        'color_balance': 0,
                        'mono_balance': 0
                    }
                
                if acc_type.lower() == 'color':
                    structured['departments'][dept]['color_balance'] = self.get_shared_account_balance(account)
                elif acc_type.lower() == 'mono':
                    structured['departments'][dept]['mono_balance'] = self.get_shared_account_balance(account)
            else:
                structured['other_accounts'].append({
                    'name': account,
                    'balance': self.get_shared_account_balance(account)
                })
        
        return structured

    def set_department_quotas(self, department_name, color_quota, mono_quota):
        """Define cotas para um departamento, criando contas se necessário"""
        try:
            color_account = f"{department_name}\\Color"
            mono_account = f"{department_name}\\Mono"
            
            # Verifica e cria contas se não existirem
            all_accounts = self.list_shared_accounts()
            
            if color_account not in all_accounts:
                logger.info(f"Criando conta {color_account}...")
                if not self.add_new_shared_account(color_account):
                    raise Exception(f"Falha ao criar conta {color_account}")
            
            if mono_account not in all_accounts:
                logger.info(f"Criando conta {mono_account}...")
                if not self.add_new_shared_account(mono_account):
                    raise Exception(f"Falha ao criar conta {mono_account}")
            
            # Define os novos valores
            color_success = self.set_shared_account_balance(color_account, color_quota)
            mono_success = self.set_shared_account_balance(mono_account, mono_quota)
            
            if not color_success or not mono_success:
                raise Exception("Falha ao definir um ou mais saldos")
            
            # Obter valores atualizados
            color_balance = self.get_shared_account_balance(color_account)
            mono_balance = self.get_shared_account_balance(mono_account)
            
            return {
                'department': department_name,
                'color_success': color_success,
                'mono_success': mono_success,
                'color_balance': color_balance,
                'mono_balance': mono_balance,
                'success': True
            }
            
        except Exception as e:
            logger.error(f"Erro ao definir cotas para {department_name}: {str(e)}")
            return {
                'department': department_name,
                'success': False,
                'error': str(e)
            }

    def get_user_department(self, username):
        """Obtém o departamento de um usuário"""
        try:
            department = self.proxy.api.getUserProperty(
                self.auth_token,
                username,
                "department")
            return department if department else None
        except Exception as e:
            logger.error(f"Erro ao obter departamento do usuário {username}: {str(e)}")
            return None

    def set_user_department(self, username, department):
        """Define o departamento de um usuário"""
        try:
            success = self.proxy.api.setUserProperty(
                self.auth_token,
                username,
                "department",
                department)
            
            if success:
                logger.info(f"Departamento do usuário {username} atualizado para {department}")
            return success
        except Exception as e:
            logger.error(f"Erro ao definir departamento para {username}: {str(e)}")
            return False
    
    def adjust_shared_account_balance(self, account_name, adjustment, comment=""):
        """Ajusta o saldo de uma conta compartilhada (positivo adiciona, negativo subtrai)"""
        try:
            success = self.proxy.api.adjustSharedAccountAccountBalance(
                self.auth_token,
                account_name,
                adjustment,
                comment if comment else f"Ajuste automático: {adjustment}")
            
            if success:
                logger.info(f"Saldo da conta {account_name} ajustado em {adjustment}")
            
            return success
        except Exception as e:
            logger.error(f"Erro ao ajustar saldo da conta {account_name}: {str(e)}")
            return False
    
    def check_print_authorization(self, department, color_pages, mono_pages, color_cost_per_page=0.87, mono_cost_per_page=0.04):
        """Verifica se há saldo suficiente e autoriza impressão"""
        try:
            color_account = f"{department}\\Color"
            mono_account = f"{department}\\Mono"
            
            # Calcular custos
            color_total_cost = color_pages * color_cost_per_page
            mono_total_cost = mono_pages * mono_cost_per_page
            
            # Verificar saldos atuais
            color_balance = self.get_shared_account_balance(color_account) if color_pages > 0 else 0
            mono_balance = self.get_shared_account_balance(mono_account) if mono_pages > 0 else 0
            
            # Verificar se há saldo suficiente
            color_sufficient = color_pages == 0 or color_balance >= color_total_cost
            mono_sufficient = mono_pages == 0 or mono_balance >= mono_total_cost
            
            if not color_sufficient or not mono_sufficient:
                return {
                    'authorized': False,
                    'reason': 'saldo_insuficiente',
                    'details': {
                        'color_pages': color_pages,
                        'mono_pages': mono_pages,
                        'color_cost': color_total_cost,
                        'mono_cost': mono_total_cost,
                        'color_balance': color_balance,
                        'mono_balance': mono_balance,
                        'color_sufficient': color_sufficient,
                        'mono_sufficient': mono_sufficient
                    }
                }
            
            # Se chegou até aqui, há saldo suficiente - fazer débito
            debit_success = True
            debit_details = {}
            
            if color_pages > 0:
                color_debit = self.adjust_shared_account_balance(
                    color_account, 
                    -color_total_cost, 
                    f"Impressão: {color_pages} páginas color"
                )
                debit_details['color_debit'] = color_debit
                if not color_debit:
                    debit_success = False
            
            if mono_pages > 0:
                mono_debit = self.adjust_shared_account_balance(
                    mono_account, 
                    -mono_total_cost, 
                    f"Impressão: {mono_pages} páginas mono"
                )
                debit_details['mono_debit'] = mono_debit
                if not mono_debit:
                    debit_success = False
            
            return {
                'authorized': debit_success,
                'reason': 'debito_realizado' if debit_success else 'erro_debito',
                'details': {
                    'color_pages': color_pages,
                    'mono_pages': mono_pages,
                    'color_cost': color_total_cost,
                    'mono_cost': mono_total_cost,
                    'color_balance_before': color_balance,
                    'mono_balance_before': mono_balance,
                    'debit_success': debit_success,
                    **debit_details
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao verificar autorização de impressão: {str(e)}")
            return {
                'authorized': False,
                'reason': 'erro_sistema',
                'error': str(e)
            }

    # ========== MÉTODOS PARA CHAVES SCRIPT.USER-DEFINED ==========
    
    def get_script_property(self, property_name):
        """Obtém o valor de uma propriedade script.user-defined"""
        try:
            value = self.proxy.api.getConfigValue(
                self.auth_token,
                f"script.user-defined.{property_name}")
            
            if value is None:
                return 0.0
            
            # Converter para string se necessário
            value_str = str(value)
            
            # Verificar se é um número válido
            if value_str and value_str.replace('.', '').replace('-', '').isdigit():
                return float(value_str)
            
            return 0.0
        except Exception as e:
            logger.error(f"Erro ao obter propriedade {property_name}: {str(e)}")
            return 0.0

    def set_script_property(self, property_name, value):
        """Define o valor de uma propriedade script.user-defined"""
        try:
            success = self.proxy.api.setConfigValue(
                self.auth_token,
                f"script.user-defined.{property_name}",
                str(float(value)))
            
            if success:
                logger.info(f"Propriedade script.user-defined.{property_name} atualizada para {value}")
            
            return success
        except Exception as e:
            logger.error(f"Erro ao definir propriedade {property_name}: {str(e)}")
            return False

    def get_department_script_balances(self, department_name):
        """Obtém saldos das chaves script.user-defined de um departamento"""
        try:
            color_key = f"{department_name}\\color"
            mono_key = f"{department_name}\\mono"
            
            color_balance = self.get_script_property(color_key)
            mono_balance = self.get_script_property(mono_key)
            
            return {
                'department': department_name,
                'color_balance': color_balance,
                'mono_balance': mono_balance,
                'color_key': f"script.user-defined.{color_key}",
                'mono_key': f"script.user-defined.{mono_key}"
            }
        except Exception as e:
            logger.error(f"Erro ao obter saldos script para {department_name}: {str(e)}")
            return {
                'department': department_name,
                'color_balance': 0.0,
                'mono_balance': 0.0,
                'error': str(e)
            }

    def set_department_script_quotas(self, department_name, color_quota, mono_quota):
        """Define cotas para um departamento usando chaves script.user-defined"""
        try:
            color_key = f"{department_name}\\color"
            mono_key = f"{department_name}\\mono"
            
            # Define os novos valores
            color_success = self.set_script_property(color_key, color_quota)
            mono_success = self.set_script_property(mono_key, mono_quota)
            
            if not color_success or not mono_success:
                raise Exception("Falha ao definir uma ou mais propriedades script")
            
            # Obter valores atualizados para confirmação
            color_balance = self.get_script_property(color_key)
            mono_balance = self.get_script_property(mono_key)
            
            return {
                'department': department_name,
                'color_success': color_success,
                'mono_success': mono_success,
                'color_balance': color_balance,
                'mono_balance': mono_balance,
                'color_key': f"script.user-defined.{color_key}",
                'mono_key': f"script.user-defined.{mono_key}",
                'success': True
            }
            
        except Exception as e:
            logger.error(f"Erro ao definir cotas script para {department_name}: {str(e)}")
            return {
                'department': department_name,
                'success': False,
                'error': str(e)
            }

    def adjust_script_property_balance(self, property_name, adjustment, comment=""):
        """Ajusta o valor de uma propriedade script.user-defined (positivo adiciona, negativo subtrai)"""
        try:
            current_value = self.get_script_property(property_name)
            new_value = current_value + adjustment
            
            # Garantir que o valor não seja negativo
            if new_value < 0:
                new_value = 0
            
            success = self.set_script_property(property_name, new_value)
            
            if success:
                logger.info(f"Propriedade {property_name} ajustada de {current_value} para {new_value} (ajuste: {adjustment})")
                if comment:
                    logger.info(f"Comentário: {comment}")
            
            return {
                'success': success,
                'old_value': current_value,
                'new_value': new_value,
                'adjustment': adjustment
            }
        except Exception as e:
            logger.error(f"Erro ao ajustar propriedade {property_name}: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

    def get_all_departments_script_data(self):
        """Retorna dados de todas as chaves script organizadas por departamento"""
        try:
            # Para obter todos os departamentos, vamos usar uma abordagem baseada em padrões conhecidos
            # ou tentar obter de configurações existentes
            departments_data = {}
            
            # Lista de departamentos conhecidos (pode ser expandida)
            known_departments = ['escritorio', 'administracao', 'vendas', 'financeiro', 'sem-departamento']
            
            for dept in known_departments:
                dept_data = self.get_department_script_balances(dept)
                if dept_data['color_balance'] > 0 or dept_data['mono_balance'] > 0:
                    departments_data[dept] = dept_data
            
            return {
                'departments': departments_data,
                'total_departments': len(departments_data)
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter dados de departamentos script: {str(e)}")
            return {
                'departments': {},
                'total_departments': 0,
                'error': str(e)
            }

    def check_script_print_authorization(self, department, color_pages, mono_pages, color_cost_per_page=0.87, mono_cost_per_page=0.04):
        """Verifica se há saldo suficiente nas chaves script e autoriza impressão"""
        try:
            color_key = f"{department}\\color"
            mono_key = f"{department}\\mono"
            
            # Calcular custos
            color_total_cost = color_pages * color_cost_per_page
            mono_total_cost = mono_pages * mono_cost_per_page
            
            # Verificar saldos atuais nas chaves script
            color_balance = self.get_script_property(color_key) if color_pages > 0 else 0
            mono_balance = self.get_script_property(mono_key) if mono_pages > 0 else 0
            
            # Verificar se há saldo suficiente
            color_sufficient = color_pages == 0 or color_balance >= color_total_cost
            mono_sufficient = mono_pages == 0 or mono_balance >= mono_total_cost
            
            if not color_sufficient or not mono_sufficient:
                return {
                    'authorized': False,
                    'reason': 'saldo_insuficiente',
                    'details': {
                        'color_pages': color_pages,
                        'mono_pages': mono_pages,
                        'color_cost': color_total_cost,
                        'mono_cost': mono_total_cost,
                        'color_balance': color_balance,
                        'mono_balance': mono_balance,
                        'color_sufficient': color_sufficient,
                        'mono_sufficient': mono_sufficient,
                        'color_key': f"script.user-defined.{color_key}",
                        'mono_key': f"script.user-defined.{mono_key}"
                    }
                }
            
            # Se chegou até aqui, há saldo suficiente - fazer débito
            debit_success = True
            debit_details = {}
            
            if color_pages > 0:
                color_debit = self.adjust_script_property_balance(
                    color_key, 
                    -color_total_cost, 
                    f"Impressão: {color_pages} páginas color"
                )
                debit_details['color_debit'] = color_debit['success']
                debit_details['color_new_balance'] = color_debit.get('new_value', 0)
                if not color_debit['success']:
                    debit_success = False
            
            if mono_pages > 0:
                mono_debit = self.adjust_script_property_balance(
                    mono_key, 
                    -mono_total_cost, 
                    f"Impressão: {mono_pages} páginas mono"
                )
                debit_details['mono_debit'] = mono_debit['success']
                debit_details['mono_new_balance'] = mono_debit.get('new_value', 0)
                if not mono_debit['success']:
                    debit_success = False
            
            return {
                'authorized': debit_success,
                'reason': 'debito_realizado' if debit_success else 'erro_debito',
                'details': {
                    'color_pages': color_pages,
                    'mono_pages': mono_pages,
                    'color_cost': color_total_cost,
                    'mono_cost': mono_total_cost,
                    'color_balance_before': color_balance,
                    'mono_balance_before': mono_balance,
                    'debit_success': debit_success,
                    'color_key': f"script.user-defined.{color_key}",
                    'mono_key': f"script.user-defined.{mono_key}",
                    **debit_details
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao verificar autorização de impressão script: {str(e)}")
            return {
                'authorized': False,
                'reason': 'erro_sistema',
                'error': str(e)
            }
