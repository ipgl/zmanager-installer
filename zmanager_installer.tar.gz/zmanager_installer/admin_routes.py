
"""
Rotas de administração para gerenciamento de usuários
"""

from flask import Blueprint, jsonify, request, render_template
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, get_db_session
import logging
from datetime import timezone, timedelta

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')
logger = logging.getLogger(__name__)

def to_brasilia_time(dt):
    """Converte um datetime para o fuso horário de Brasília"""
    if dt is None:
        return None
    if dt.tzinfo is None:
        # Se não tem timezone, assume que é UTC
        dt = dt.replace(tzinfo=timezone.utc)
    
    brasilia_tz = timezone(timedelta(hours=-3))
    return dt.astimezone(brasilia_tz)

def admin_required(f):
    """Decorator para verificar se o usuário é admin"""
    from functools import wraps
    
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return jsonify({
                'status': 'error',
                'message': 'Acesso negado. Permissão de administrador necessária.'
            }), 403
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/users-page')
@login_required
@admin_required
def users_page():
    """Página HTML para gerenciamento de usuários"""
    return render_template('admin_users.html', current_user=current_user)

@admin_bp.route('/users', methods=['GET'])
@login_required
@admin_required
def get_users():
    """Lista todos os usuários do sistema"""
    try:
        db = get_db_session()
        try:
            users = db.query(User).order_by(User.created_at.desc()).all()
            
            users_data = []
            for user in users:
                # Converter para horário de Brasília
                last_login_brasilia = to_brasilia_time(user.last_login) if user.last_login else None
                created_at_brasilia = to_brasilia_time(user.created_at)
                
                users_data.append({
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'is_admin': user.is_admin,
                    'is_active': user.is_active,
                    'created_at': created_at_brasilia.isoformat() if created_at_brasilia else None,
                    'last_login': last_login_brasilia.isoformat() if last_login_brasilia else None,
                    'requires_password_change': getattr(user, 'requires_password_change', False)
                })
            
            return jsonify({
                'status': 'success',
                'data': users_data
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao buscar usuários: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>/toggle-admin', methods=['POST'])
@login_required
@admin_required
def toggle_user_admin(user_id):
    """Alterna o status de administrador de um usuário"""
    try:
        # Impedir que o admin padrão seja modificado
        if user_id == 1:  # ID do admin padrão
            return jsonify({
                'status': 'error',
                'message': 'Não é possível modificar o administrador padrão'
            }), 400
        
        db = get_db_session()
        try:
            user = db.query(User).get(user_id)
            if not user:
                return jsonify({
                    'status': 'error',
                    'message': 'Usuário não encontrado'
                }), 404
            
            # Alternar status de admin
            user.is_admin = not user.is_admin
            db.commit()
            
            return jsonify({
                'status': 'success',
                'message': f'Status de administrador {"ativado" if user.is_admin else "desativado"} para {user.username}',
                'data': {
                    'user_id': user.id,
                    'username': user.username,
                    'is_admin': user.is_admin
                }
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao alternar status de admin: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
@admin_required
def reset_user_password(user_id):
    """Reseta a senha de um usuário e força a troca no próximo login"""
    try:
        db = get_db_session()
        try:
            user = db.query(User).get(user_id)
            if not user:
                return jsonify({
                    'status': 'error',
                    'message': 'Usuário não encontrado'
                }), 404
            
            # Gerar senha temporária (poderia ser mais complexa)
            temp_password = "Temp123!"
            
            # Atualizar senha e marcar para troca obrigatória
            user.password_hash = generate_password_hash(temp_password)
            user.requires_password_change = True
            
            db.commit()
            
            return jsonify({
                'status': 'success',
                'message': f'Senha resetada para {user.username}',
                'data': {
                    'user_id': user.id,
                    'username': user.username,
                    'temporary_password': temp_password,  # Mostrar apenas uma vez
                    'requires_password_change': True
                }
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao resetar senha: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>/toggle-active', methods=['POST'])
@login_required
@admin_required
def toggle_user_active(user_id):
    """Alterna o status ativo/inativo de um usuário"""
    try:
        # Impedir que o admin padrão seja desativado
        if user_id == 1:  # ID do admin padrão
            return jsonify({
                'status': 'error',
                'message': 'Não é possível desativar o administrador padrão'
            }), 400
        
        db = get_db_session()
        try:
            user = db.query(User).get(user_id)
            if not user:
                return jsonify({
                    'status': 'error',
                    'message': 'Usuário não encontrado'
                }), 404
            
            # Alternar status ativo
            user.is_active = not user.is_active
            db.commit()
            
            return jsonify({
                'status': 'success',
                'message': f'Usuário {user.username} {"ativado" if user.is_active else "desativado"}',
                'data': {
                    'user_id': user.id,
                    'username': user.username,
                    'is_active': user.is_active
                }
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao alternar status ativo: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_user(user_id):
    """Exclui um usuário"""
    try:
        # Impedir que o admin padrão seja excluído
        if user_id == 1:  # ID do admin padrão
            return jsonify({
                'status': 'error',
                'message': 'Não é possível excluir o administrador padrão'
            }), 400
        
        # Impedir que o usuário atual se exclua
        if user_id == current_user.id:
            return jsonify({
                'status': 'error',
                'message': 'Não é possível excluir seu próprio usuário'
            }), 400
        
        db = get_db_session()
        try:
            user = db.query(User).get(user_id)
            if not user:
                return jsonify({
                    'status': 'error',
                    'message': 'Usuário não encontrado'
                }), 404
            
            username = user.username
            db.delete(user)
            db.commit()
            
            return jsonify({
                'status': 'success',
                'message': f'Usuário {username} excluído com sucesso'
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao excluir usuário: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@admin_bp.route('/users/create', methods=['POST'])
@login_required
@admin_required
def create_user():
    """Cria um novo usuário"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'status': 'error',
                'message': 'Dados não fornecidos'
            }), 400
        
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        is_admin = data.get('is_admin', False)
        
        if not username or not email or not password:
            return jsonify({
                'status': 'error',
                'message': 'Username, email e senha são obrigatórios'
            }), 400
        
        if len(password) < 6:
            return jsonify({
                'status': 'error',
                'message': 'Senha deve ter pelo menos 6 caracteres'
            }), 400
        
        db = get_db_session()
        try:
            # Verificar se username ou email já existem
            existing_user = db.query(User).filter(
                (User.username == username) | (User.email == email)
            ).first()
            
            if existing_user:
                return jsonify({
                    'status': 'error',
                    'message': 'Username ou email já estão em uso'
                }), 400
            
            # Criar novo usuário
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password),
                is_admin=is_admin,
                requires_password_change=False  # Não força troca para criação normal
            )
            
            db.add(new_user)
            db.commit()
            
            return jsonify({
                'status': 'success',
                'message': f'Usuário {username} criado com sucesso',
                'data': {
                    'id': new_user.id,
                    'username': new_user.username,
                    'email': new_user.email,
                    'is_admin': new_user.is_admin
                }
            })
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Erro ao criar usuário: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500