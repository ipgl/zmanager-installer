#!/bin/bash
# Z Manager Installer - Versão Corrigida
set -e

echo "=== Instalando Z Manager (Protegido) ==="

# Verificar root
if [ "$EUID" -ne 0 ]; then
    echo "Por favor, execute como root: sudo $0"
    exit 1
fi

# Verificar conectividade
echo "Verificando conectividade com a internet..."
if ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1; then
    echo "✅ Conectividade com internet OK"
    HAS_INTERNET=true
else
    echo "⚠️  Sem conectividade com a internet - modo offline"
    HAS_INTERNET=false
fi

# Instalar dependências do sistema
echo "Instalando dependências do sistema..."
apt update || echo "⚠️  Falha no apt update (pode ser normal sem internet)"

# Verificar Python
if ! command -v python3 &> /dev/null; then
    if [ "$HAS_INTERNET" = "true" ]; then
        apt install -y python3 python3-pip python3-venv
    else
        echo "❌ Python3 não instalado e sem internet"
        echo "   Instale manualmente: sudo apt install python3 python3-venv"
        exit 1
    fi
else
    echo "✅ Python3 já instalado"
fi

# Criar diretório de instalação
INSTALL_DIR="/opt/zmanager"
echo "Instalando em: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

# Copiar arquivos
echo "Copiando arquivos..."
cp -r . "$INSTALL_DIR/"
chown -R $SUDO_USER:$SUDO_USER "$INSTALL_DIR"

# Criar virtual environment
echo "Configurando ambiente Python..."
cd "$INSTALL_DIR"
python3 -m venv venv

# Instalar dependências Python
echo "Instalando dependências Python..."
if [ "$HAS_INTERNET" = "true" ]; then
    ./venv/bin/pip install --upgrade pip
    ./venv/bin/pip install flask flask-login sqlalchemy werkzeug requests schedule python-dotenv
else
    echo "⚠️  Modo offline - dependências não instaladas"
    echo "   Execute depois: $INSTALL_DIR/zmanager-control install-deps"
fi

# 🔒 COMPILAÇÃO FINAL E PROTEÇÃO - CORRIGIDA
echo "Aplicando proteção final ao código..."
cd "$INSTALL_DIR"

# Compilar qualquer arquivo .py restante e criar .pyc no mesmo diretório
for py_file in $(find . -name "*.py" -type f); do
    if [ -f "$py_file" ]; then
        # Compilar para criar .pyc
        ./venv/bin/python -c "import py_compile; py_compile.compile('$py_file', optimize=2)" 2>/dev/null || echo "⚠️  Não compilado: $py_file"
        # Criar cópia no mesmo diretório (compatibilidade)
        pyc_cache_file="${py_file}__pycache__/$(basename ${py_file%.py})*.pyc"
        if ls $pyc_cache_file 1>/dev/null 2>&1; then
            cp $(ls -t $pyc_cache_file | head -1) "${py_file}c" 2>/dev/null || true
        fi
    fi
done

# Remover arquivos .py originais (mantendo estrutura)
find . -name "*.py" -type f ! -path "./venv/*" ! -name "__init__.py" -delete 2>/dev/null || echo "⚠️  Alguns .py não removidos"

# Criar entry point PRINCIPAL CORRIGIDO
echo "Criando executável principal corrigido..."
cat > "$INSTALL_DIR/run_app.py" << 'EOF'
#!/usr/bin/env python3
import sys
import os
import importlib.util

# Adicionar diretório atual ao path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

def load_module_from_pyc(pyc_path):
    """Carrega módulo a partir de arquivo .pyc"""
    try:
        # Para Python 3.8+
        spec = importlib.util.spec_from_file_location("app", pyc_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    except Exception as e:
        print(f"Erro ao carregar {pyc_path}: {e}")
        return None

def main():
    print('🚀 Iniciando Z Manager...')
    
    # Tentar carregar o app de diferentes formas
    app_module = None
    
    # 1. Tentar importar normalmente (se .pyc estiver no __pycache__)
    try:
        from app import app
        app_module = app
        print('✅ Módulo carregado via import normal')
    except ImportError:
        # 2. Tentar carregar do .pyc no mesmo diretório
        pyc_path = os.path.join(SCRIPT_DIR, 'app.pyc')
        if os.path.exists(pyc_path):
            module = load_module_from_pyc(pyc_path)
            if module and hasattr(module, 'app'):
                app_module = module.app
                print('✅ Módulo carregado via .pyc direto')
        
    if not app_module:
        # 3. Tentar carregar do __pycache__
        import glob
        cache_pattern = os.path.join(SCRIPT_DIR, '__pycache__', 'app.*.pyc')
        cache_files = glob.glob(cache_pattern)
        if cache_files:
            # Pegar o mais recente
            latest_cache = sorted(cache_files)[-1]
            module = load_module_from_pyc(latest_cache)
            if module and hasattr(module, 'app'):
                app_module = module.app
                print('✅ Módulo carregado via __pycache__')
    
    if not app_module:
        print('❌ ERRO: Não foi possível carregar o módulo app')
        print('📁 Diretório:', SCRIPT_DIR)
        print('📋 Arquivos encontrados:')
        for f in os.listdir(SCRIPT_DIR):
            if 'app' in f:
                print(f'   - {f}')
        sys.exit(1)
    
    # Iniciar aplicação
    try:
        print('🌐 Servidor iniciando em http://0.0.0.0:9090')
        app_module.run(host='0.0.0.0', port=9090, debug=False)
    except Exception as e:
        print(f'❌ Erro ao executar app: {e}')
        sys.exit(1)

if __name__ == '__main__':
    main()
EOF

# Tornar executável
chmod +x "$INSTALL_DIR/run_app.py"

# Criar wrapper shell
cat > "$INSTALL_DIR/start_app.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
exec ./venv/bin/python run_app.py
EOF

chmod +x "$INSTALL_DIR/start_app.sh"

# Criar service file
echo "Configurando serviço automático..."
SERVICE_FILE="/etc/systemd/system/zmanager.service"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Z Manager - PaperCut Quota Management
After=network.target

[Service]
Type=simple
User=$SUDO_USER
Group=$SUDO_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/start_app.sh
Restart=always
RestartSec=10
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Recarregar e ativar serviço
echo "Ativando serviço..."
systemctl daemon-reload
systemctl enable zmanager.service

# Tentar iniciar o serviço
echo "Iniciando serviço..."
if systemctl start zmanager.service; then
    echo "✅ Serviço iniciado com sucesso"
    sleep 2
    systemctl status zmanager.service --no-pager
else
    echo "⚠️  Serviço não pôde ser iniciado automaticamente"
    echo "   Verifique as dependências com: journalctl -u zmanager.service -f"
fi

# Script de desinstalação
cat > "$INSTALL_DIR/uninstall.sh" <<'EOF'
#!/bin/bash
echo "=== Desinstalando Z Manager ==="
systemctl stop zmanager.service 2>/dev/null || true
systemctl disable zmanager.service 2>/dev/null || true
rm -f "/etc/systemd/system/zmanager.service" 2>/dev/null || true
rm -rf "/opt/zmanager" 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
echo "✅ Z Manager desinstalado!"
EOF

chmod +x "$INSTALL_DIR/uninstall.sh"

# Script de controle
cat > "$INSTALL_DIR/zmanager-control" <<'EOF'
#!/bin/bash
case "$1" in
    start)
        systemctl start zmanager.service
        ;;
    stop)
        systemctl stop zmanager.service
        ;;
    restart)
        systemctl restart zmanager.service
        ;;
    status)
        systemctl status zmanager.service
        ;;
    logs)
        journalctl -u zmanager.service -f
        ;;
    install-deps)
        echo "Instalando dependências..."
        cd /opt/zmanager
        ./venv/bin/pip install flask flask-login sqlalchemy werkzeug requests schedule python-dotenv
        echo "✅ Dependências instaladas"
        ;;
    debug)
        echo "=== Modo Debug ==="
        cd /opt/zmanager
        ./venv/bin/python run_app.py
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|status|logs|install-deps|debug}"
        exit 1
        ;;
esac
EOF

chmod +x "$INSTALL_DIR/zmanager-control"

echo ""
echo "=== Instalação concluída! ==="
echo "📁 Diretório: $INSTALL_DIR"
echo "🔧 Serviço: zmanager.service"
if [ "$HAS_INTERNET" = "false" ]; then
    echo "⚠️  ATENÇÃO: Instalação em modo offline"
    echo "   Instale as dependências: $INSTALL_DIR/zmanager-control install-deps"
fi
echo "📊 Status: systemctl status zmanager"
echo "🐛 Debug: $INSTALL_DIR/zmanager-control debug"
echo "🌐 Acesse: http://localhost:9090"