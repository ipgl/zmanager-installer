#!/bin/bash
# Z Manager Installer
set -e

echo "=== Instalando Z Manager ==="

# Verificar root
if [ "$EUID" -ne 0 ]; then
    echo "Por favor, execute como root: sudo $0"
    exit 1
fi

# Instalar dependências do sistema
echo "Instalando dependências do sistema..."
apt update
apt install -y python3 python3-pip python3-venv python3-full

# Criar diretório de instalação
INSTALL_DIR="/opt/zmanager"
echo "Instalando em: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

# Copiar arquivos
echo "Copiando arquivos..."
cp -r . "$INSTALL_DIR/"
chown -R $SUDO_USER:$SUDO_USER "$INSTALL_DIR"

# Criar virtual environment
echo "Configurando ambiente Python..."
cd "$INSTALL_DIR"
python3 -m venv venv

# Instalar dependências no virtual environment
echo "Instalando dependências Python..."
./venv/bin/pip install --upgrade pip
./venv/bin/pip install flask flask-login sqlalchemy werkzeug requests schedule python-dotenv

# Criar service file
echo "Configurando serviço automático..."
SERVICE_FILE="/etc/systemd/system/zmanager.service"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Z Manager - PaperCut Quota Management
After=network.target

[Service]
Type=simple
User=$SUDO_USER
Group=$SUDO_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/app.py
Restart=always
RestartSec=10
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Recarregar e ativar serviço
echo "Ativando serviço..."
systemctl daemon-reload
systemctl enable zmanager.service
systemctl start zmanager.service

# Criar script de desinstalação
cat > "$INSTALL_DIR/uninstall.sh" <<'EOF'
#!/bin/bash
echo "=== Desinstalando Z Manager ==="
systemctl stop zmanager.service
systemctl disable zmanager.service
rm -f "/etc/systemd/system/zmanager.service"
rm -rf "/opt/zmanager"
systemctl daemon-reload
echo "✅ Z Manager desinstalado!"
EOF

chmod +x "$INSTALL_DIR/uninstall.sh"

# Criar script de controle
cat > "$INSTALL_DIR/zmanager-control" <<'EOF'
#!/bin/bash
case "$1" in
    start)
        systemctl start zmanager.service
        ;;
    stop)
        systemctl stop zmanager.service
        ;;
    restart)
        systemctl restart zmanager.service
        ;;
    status)
        systemctl status zmanager.service
        ;;
    logs)
        journalctl -u zmanager.service -f
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
EOF

chmod +x "$INSTALL_DIR/zmanager-control"

echo "=== Instalação concluída! ==="
echo "📁 Diretório: $INSTALL_DIR"
echo "🔧 Serviço: zmanager.service"
echo "📊 Status: systemctl status zmanager"
echo "📋 Logs: journalctl -u zmanager -f"
echo "🗑️  Desinstalar: $INSTALL_DIR/uninstall.sh"
echo ""
echo "🌐 Acesse: http://localhost:5666"
echo "⚡ Controle: $INSTALL_DIR/zmanager-control [start|stop|restart|status|logs]"