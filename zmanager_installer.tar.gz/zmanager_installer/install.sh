#!/bin/bash
set -e

echo "=== Instalando Z Manager ==="

[ "$EUID" -ne 0 ] && echo "Execute como root: sudo $0" && exit 1

INSTALL_DIR="/opt/zmanager"
echo "Instalando em: $INSTALL_DIR"

# Parar e limpar anterior
systemctl stop zmanager.service 2>/dev/null || true
systemctl disable zmanager.service 2>/dev/null || true
rm -rf "$INSTALL_DIR" 2>/dev/null || true
mkdir -p "$INSTALL_DIR"

# Copiar
cp -r . "$INSTALL_DIR/"

# Configurar
USER=${SUDO_USER:-$(logname 2>/dev/null || echo root)}
mkdir -p "/var/log/zmanager"

# Instalar dependências Python
echo "📦 Instalando dependências Python..."
apt update
apt install -y python3 python3-pip python3-venv

# Criar venv e instalar pacotes
cd "$INSTALL_DIR"
python3 -m venv venv
./venv/bin/pip install --upgrade pip

if [ -f "requirements.txt" ]; then
    ./venv/bin/pip install -r requirements.txt
else
    # Instalar dependências manualmente
    ./venv/bin/pip install flask flask-login flask-sqlalchemy sqlalchemy werkzeug requests schedule python-dotenv
fi

echo "✅ Dependências instaladas"

# Verificar e configurar .env
if [ -f "$INSTALL_DIR/.env" ]; then
    echo "✅ Arquivo .env encontrado"
    # Mostrar variáveis importantes (mascaradas)
    echo "📋 Variáveis de ambiente carregadas:"
    grep -E "^(PAPERCUT_|BACK4APP_|CLIENT_NAME|SECRET_KEY)" "$INSTALL_DIR/.env" | while read line; do
        key=$(echo "$line" | cut -d'=' -f1)
        value=$(echo "$line" | cut -d'=' -f2-)
        if [ "${#value}" -gt 4 ]; then
            masked_value="$(echo "$value" | cut -c1-2)****$(echo "$value" | rev | cut -c1-2 | rev)"
        else
            masked_value="****"
        fi
        echo "   $key=$masked_value"
    done
else
    echo "⚠️  AVISO: Arquivo .env não encontrado"
    echo "💡 Crie o arquivo .env com as configurações necessárias:"
    echo "   sudo nano $INSTALL_DIR/.env"
fi

# Permissões
chown -R "$USER:$USER" "$INSTALL_DIR" "/var/log/zmanager"
chmod -R 755 "$INSTALL_DIR" "/var/log/zmanager"
chmod +x "$INSTALL_DIR/zmanager" 2>/dev/null || true
chmod +x "$INSTALL_DIR/zmanager-control" 2>/dev/null || true

# Criar script de execução se não houver executável
if [ ! -f "$INSTALL_DIR/zmanager" ]; then
    cat > "$INSTALL_DIR/run_app.py" << 'EOF'
#!/usr/bin/env python3
import sys
import os

# Adicionar paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

# Configurar logs
LOG_DIR = "/var/log/zmanager"
os.makedirs(LOG_DIR, exist_ok=True)

# Carregar .env manualmente
env_path = os.path.join(SCRIPT_DIR, '.env')
if os.path.exists(env_path):
    print("✅ Carregando .env...")
    with open(env_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()
else:
    print("⚠️  Arquivo .env não encontrado")

print("🚀 Iniciando Z Manager...")

try:
    from app import app
    
    # Iniciar scheduler
    try:
        from monthly_quota_scheduler import start_scheduler
        import threading
        scheduler_thread = threading.Thread(target=start_scheduler, daemon=True)
        scheduler_thread.start()
        print("✅ Scheduler iniciado")
    except Exception as e:
        print(f"⚠️  Scheduler não iniciado: {e}")
    
    print("🌐 Servidor rodando em http://0.0.0.0:9090")
    app.run(host='0.0.0.0', port=9090, debug=False, threaded=True)
    
except Exception as e:
    print(f"❌ Erro: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
EOF

    chmod +x "$INSTALL_DIR/run_app.py"
    
    # Usar run_app.py como executável principal
    EXEC_START="$INSTALL_DIR/venv/bin/python $INSTALL_DIR/run_app.py"
else
    EXEC_START="$INSTALL_DIR/zmanager"
fi

# Service file
cat > /etc/systemd/system/zmanager.service << EOF
[Unit]
Description=Z Manager
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$EXEC_START
Restart=always
RestartSec=10
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Ativar serviço
systemctl daemon-reload
systemctl enable zmanager.service

echo "Iniciando serviço..."
if systemctl start zmanager.service; then
    echo "✅ Serviço iniciado"
    sleep 2
    echo "=== Status ==="
    systemctl status zmanager.service --no-pager | head -6
else
    echo "❌ Falha ao iniciar"
    echo "💡 Debug: $INSTALL_DIR/zmanager-control debug"
fi

echo ""
echo "=== Instalação Concluída! ==="
echo "🌐 URL: http://localhost:9090"
echo "💡 Comandos: /opt/zmanager/zmanager-control {start|stop|restart|status|logs|debug}"
echo ""
echo "⚠️  IMPORTANTE: Verifique o arquivo .env em $INSTALL_DIR/.env"
echo "   Variáveis necessárias: BACK4APP_APP_ID_CONT, BACK4APP_REST_KEY_CONT, CLIENT_NAME"
