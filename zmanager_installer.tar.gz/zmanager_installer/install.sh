#!/bin/bash
# Z Manager Installer - Versão Protegida
set -e

echo "=== Instalando Z Manager (Protegido) ==="

# Verificar root
if [ "$EUID" -ne 0 ]; then
    echo "Por favor, execute como root: sudo $0"
    exit 1
fi

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "Instalando Python3..."
    apt update
    apt install -y python3 python3-pip python3-venv
fi

echo "✅ Python3 verificado"

# Criar diretório de instalação
INSTALL_DIR="/opt/zmanager"
echo "Instalando em: $INSTALL_DIR"

# Remover instalação anterior se existir
systemctl stop zmanager.service 2>/dev/null || true
systemctl disable zmanager.service 2>/dev/null || true
rm -rf "$INSTALL_DIR" 2>/dev/null || true

# Criar diretório
mkdir -p "$INSTALL_DIR"

# Copiar arquivos
echo "Copiando arquivos protegidos..."
cp -r . "$INSTALL_DIR/"

# Ajustar proprietário
if [ -n "$SUDO_USER" ]; then
    chown -R "$SUDO_USER:$SUDO_USER" "$INSTALL_DIR"
fi

# Configurar ambiente Python
echo "Configurando ambiente Python..."
cd "$INSTALL_DIR"
python3 -m venv venv

# Instalar dependências
echo "Instalando dependências Python..."
./venv/bin/pip install --upgrade pip
./venv/bin/pip install flask flask-login sqlalchemy werkzeug requests schedule python-dotenv

# Criar loader principal para código protegido
cat > "$INSTALL_DIR/run_protected.py" << 'EOF'
#!/usr/bin/env python3
"""
Loader para código protegido do Z Manager
"""
import sys
import os
import importlib.util
import glob

def load_protected_app():
    """Carrega a aplicação a partir de bytecode protegido"""
    
    # Adicionar diretório atual ao path
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, SCRIPT_DIR)
    
    # Tentar diferentes métodos de carregamento
    app_object = None
    
    # Método 1: Tentar carregar app.pyc diretamente
    app_pyc_path = os.path.join(SCRIPT_DIR, "app.pyc")
    if os.path.exists(app_pyc_path):
        try:
            spec = importlib.util.spec_from_file_location("app", app_pyc_path)
            app_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(app_module)
            app_object = getattr(app_module, 'app', None)
            if app_object:
                print("✅ Aplicação carregada de app.pyc")
                return app_object
        except Exception as e:
            print(f"⚠️  Erro ao carregar app.pyc: {e}")
    
    # Método 2: Procurar em __pycache__
    cache_dir = os.path.join(SCRIPT_DIR, "__pycache__")
    if os.path.exists(cache_dir):
        try:
            # Procurar por app.*.pyc no cache
            cache_files = glob.glob(os.path.join(cache_dir, "app.*.pyc"))
            if cache_files:
                latest_cache = sorted(cache_files)[-1]
                spec = importlib.util.spec_from_file_location("app", latest_cache)
                app_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(app_module)
                app_object = getattr(app_module, 'app', None)
                if app_object:
                    print("✅ Aplicação carregada do __pycache__")
                    return app_object
        except Exception as e:
            print(f"⚠️  Erro ao carregar do cache: {e}")
    
    # Método 3: Importação normal (se .py ainda existir)
    try:
        from app import app
        print("✅ Aplicação carregada via import normal")
        return app
    except ImportError as e:
        print(f"❌ Erro de importação: {e}")
    
    return None

def main():
    """Função principal"""
    print("🚀 Iniciando Z Manager (Código Protegido)...")
    
    # Carregar aplicação
    app = load_protected_app()
    
    if not app:
        print("❌ ERRO CRÍTICO: Não foi possível carregar a aplicação")
        print("📁 Conteúdo do diretório:")
        for item in os.listdir("."):
            if "app" in item or "py" in item:
                print(f"   - {item}")
        sys.exit(1)
    
    # Iniciar servidor
    try:
        print("🌐 Servidor iniciando em http://0.0.0.0:9090")
        print("💡 Use CTRL+C para parar o servidor")
        app.run(host='0.0.0.0', port=9090, debug=False)
    except Exception as e:
        print(f"❌ Erro ao executar aplicação: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
EOF

# Tornar executável
chmod +x "$INSTALL_DIR/run_protected.py"

# Criar wrapper shell
cat > "$INSTALL_DIR/start_app.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
export FLASK_ENV=production
exec ./venv/bin/python run_protected.py
EOF

chmod +x "$INSTALL_DIR/start_app.sh"

# Criar service file
SERVICE_FILE="/etc/systemd/system/zmanager.service"
echo "Configurando serviço..."

cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Z Manager - PaperCut Quota Management
After=network.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/start_app.sh
Restart=always
RestartSec=10
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Ajustar usuário do serviço se disponível
if [ -n "$SUDO_USER" ]; then
    echo "User=$SUDO_USER" >> "$SERVICE_FILE"
    echo "Group=$SUDO_USER" >> "$SERVICE_FILE"
fi

# Recarregar e ativar serviço
echo "Ativando serviço..."
systemctl daemon-reload
systemctl enable zmanager.service

# Iniciar serviço
echo "Iniciando serviço..."
if systemctl start zmanager.service; then
    echo "✅ Serviço iniciado com sucesso"
    sleep 2
    echo "=== Status do Serviço ==="
    systemctl status zmanager.service --no-pager | head -10 || true
else
    echo "⚠️  Serviço não pôde ser iniciado automaticamente"
fi

# Script de controle
cat > "$INSTALL_DIR/zmanager-control" << 'EOF'
#!/bin/bash
case "$1" in
    start)
        systemctl start zmanager.service
        ;;
    stop)
        systemctl stop zmanager.service
        ;;
    restart)
        systemctl restart zmanager.service
        ;;
    status)
        systemctl status zmanager.service
        ;;
    logs)
        journalctl -u zmanager.service -f
        ;;
    debug)
        cd /opt/zmanager
        ./venv/bin/python run_protected.py
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|status|logs|debug}"
        exit 1
        ;;
esac
EOF

chmod +x "$INSTALL_DIR/zmanager-control"

# Script de desinstalação
cat > "$INSTALL_DIR/uninstall.sh" << 'EOF'
#!/bin/bash
echo "=== Desinstalando Z Manager ==="
systemctl stop zmanager.service 2>/dev/null || true
systemctl disable zmanager.service 2>/dev/null || true
rm -f "/etc/systemd/system/zmanager.service" 2>/dev/null || true
rm -rf "/opt/zmanager" 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
echo "✅ Z Manager desinstalado!"
EOF

chmod +x "$INSTALL_DIR/uninstall.sh"

echo ""
echo "=== Instalação Concluída! ==="
echo "📁 Diretório: $INSTALL_DIR"
echo "🔧 Serviço: zmanager.service"
echo "🔒 Código: PROTEGIDO contra visualização"
echo "📊 Status: systemctl status zmanager.service"
echo "🐛 Debug: $INSTALL_DIR/zmanager-control debug"
echo "🌐 Acesse: http://localhost:9090"
echo ""
echo "⚠️  AVISO: O código fonte está protegido por bytecode"
